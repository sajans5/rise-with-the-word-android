# Build Rise With The Word APK from your Android phone

## You need
- Your Android phone and a browser
- A GitHub account
- The ZIP named `Rise_With_The_Word_Android_Studio_Project.zip` from this chat

## Step 1 — Create a private GitHub repository
1. Open https://github.com in your phone browser and sign in.
2. Create a new repository named `rise-with-the-word-android`.
3. Set it to **Private** and create it.

## Step 2 — Upload the project ZIP
1. Open the new repository.
2. Tap **Add file → Upload files**.
3. Upload `Rise_With_The_Word_Android_Studio_Project.zip` from your phone's Downloads folder.
4. Commit the upload to the main branch.

## Step 3 — Add the build workflow
1. In the repository, tap **Add file → Create new file**.
2. In the filename field, enter exactly:
   `.github/workflows/android-apk.yml`
3. Open the companion file `android-apk.yml` supplied with this guide, copy all its text, and paste it into GitHub's editor.
4. Commit the new file to the main branch.

## Step 4 — Start the build
1. Open the repository's **Actions** tab.
2. Select **Build Rise With The Word APK**.
3. Tap **Run workflow**, then confirm **Run workflow**.
4. Wait for the workflow to finish with a green check mark. The first build can take several minutes.

## Step 5 — Download and install
1. Open the completed workflow run.
2. Scroll to **Artifacts** and tap `Rise-With-The-Word-debug-APK`.
3. Download and extract the artifact ZIP on your phone.
4. Tap `app-debug.apk` to install it. Android may ask you to allow installation from your browser or file manager; only allow it for this file you built yourself.

## Important notes
- This creates a **debug APK for personal testing**, not a Play Store release.
- Keep the GitHub repository private because it contains your app source.
- Do not upload passwords, signing keys, or other secrets to the repository.
- If the build fails, open the failed workflow run and share the error text (hide any private details) so it can be fixed.
