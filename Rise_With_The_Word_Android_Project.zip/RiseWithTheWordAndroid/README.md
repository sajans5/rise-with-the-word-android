## Current project version: 4.1 — Bilingual reading references and saint-data audit

# Rise With The Word — version 3.0.0

### Malayalam offline Bible + daily Mass readings
The reading screen supports first reading, responsorial psalm, second reading, Gospel acclamation, Gospel, permitted alternatives, and separate Mass formularies (for example Vigil/Night/Dawn/Day). Each downloaded date record can include `sourceName`, `sourceUrl`, and `verified: true`; records without explicit source and verification are labelled unverified. Built-in starter references and the continuous Gospel plan are **not** represented as a complete official India lectionary.

For India, verify the liturgical date and readings against the current CCBI/diocesan Ordo and approved lectionary before marking a record verified. Lectionary text and some calendar publications may be copyrighted; include only text you have permission to distribute. See `docs/DAILY_READINGS_DATASET.md` and `content-feed-template/readings-full-template.json`.


## Malayalam Bible — Catholic 73-book catalogue (Version 3.0.0)
- Added a Malayalam Bible reader using the supplied `bible.json` dataset.
- Includes book/chapter browsing, previous/next chapter navigation, and Malayalam verse-text search (up to 50 results).
- Dataset validation: 66 books, 1,189 chapters, 31,105 non-empty verses. The file is bundled locally; reading and search do not need internet.
- The Malayalam index now lists the Catholic 73-book canon. The 66 existing books have offline text; seven deuterocanonical books are catalogue entries only, with an explanation in-app. This is not yet a complete 73-book Malayalam text edition.
- **Canon note:** this source has 66 books and does not include the additional Deuterocanonical books found in the Catholic 73-book canon. The existing English Douay–Rheims reader remains separate.
- **Source/credit:** [godlytalias/Bible-Database](https://github.com/godlytalias/Bible-Database), `Malayalam/bible.json`. Its README declares GNU GPL v3 and credits Wordproject for the extracted databases. Review and follow the upstream license requirements before distributing the app. The source project has noted that Malayalam verse typos may exist; this dataset has not received a verse-by-verse theological/editorial proofread.
- In the Bible tab, choose **മലയാളം** to open the offline Malayalam reader.

## Liturgical Readings Upgrade 2.8
- Added 30 offline Bible and Catholic learning quiz questions with explanations and Scripture/CCC references.
- Added 30 offline Catholic/Bible trivia facts.
- Added 20 original Bible-story summaries with Scripture references, lessons, and short prayers.
- Existing offline Bible, saints calendar, prayer tools, music controls, and AI tools are retained.
- Content remains educational; verify local liturgical observances against the approved diocesan calendar.

A self-contained Catholic Bible and prayer app. Everything runs inside the app (no browser, no other app needed).
The only optional network use is **Content Sync** (updates from your own GitHub page).

## How to build it from your phone (3 steps)
1. In your GitHub repository, upload **Rise_With_The_Word_Android_Studio_Project.zip** (this ZIP, same name, replace the old one) and the new **android-apk.yml** into `.github/workflows/` (replace the old file).
2. GitHub app → your repo → **Actions** → *Build Rise With The Word APK* → **Run workflow**.
3. When it turns green, open the run → **Artifacts** → download *Rise-With-The-Word-debug-APK* → install.
If the run turns red, open it, tap the red step, and send me the last 30 lines of the log.

## What is inside (all work offline)
| Area | What you get |
|---|---|
| Bible | Complete 73-book Douay–Rheims (public domain), search by word or reference (e.g. *John 3:16*), bookmarks, 4-colour highlights, private notes, text size, plans (30-day Gospel journey, John, Luke, Matthew, Acts, Psalms, starter week) |
| Daily Gospel | Today / previous / next day, liturgical colour, season, Year A/B/C and I/II |
| Liturgical calendar | Roman Rite 2026–2031 computed on the phone (Easter, Lent, Holy Week, Pentecost, Advent, movable feasts, transfers, colours). Tested against known Easter dates 2026–2031 |
| Saints | 340+ saint and feast records (verify against your diocesan calendar), by date and by name |
| Stories | 119 Bible stories (Genesis → Revelation): summary, lesson, prayer, and a button that opens the full passage from the Bible |
| Prayer | Rosary (all 4 sets, guided), Divine Mercy Chaplet, traditional prayers, Loreto/St Joseph/Humility litanies, 5 novenas, Stations of the Cross, morning/evening/sleep routines, prayer timer with Lectio Divina, offline synthesized devotional music and prayer tones |
| Personal | Streaks and weekly goal (optional), journal with export, private intentions, favourites, recents, reminders, local backup & restore |
| Discover | 45-question quiz, trivia, kids & family, seasonal challenges (Advent, Lent, Easter, Mary), search across everything |
| Sharing | Scripture cards/wallpapers (save or share), share text, family/prayer-group plans (local), parish card |
| Languages | English and Malayalam interface |

## Honest status — please read
* **I could not run the Android build or test on a phone.** The web screens and calendar were tested in a desktop browser; the Kotlin code was reviewed but not compiled. If the first build fails, send me the log and I will fix it.
* **Daily readings:** the app has the Sunday and solemnity **Gospel** references built in (Years A/B/C) plus full readings for Christmas, Epiphany, Easter, Pentecost, Holy Thursday, Good Friday, Ash Wednesday and a few solemnities. For other weekdays it shows a clearly-labelled *continuous Gospel plan* — **not** the Mass lectionary. Full readings for every day come from the `readings` pack (below). I did not invent readings. Verify the built-in table against your lectionary.
* **Saints & calendar** are starter data from the General Roman Calendar plus a few Kerala saints. Check against your diocesan ordo. Epiphany, Ascension and Corpus Christi dates differ by country — set them in *Me → Settings*.
* **Syro-Malabar / Syro-Malankara calendars are not included** (they must not be mixed with the Roman calendar). They need an authoritative source and can be added later as their own calendar.
* **Malayalam:** the interface and the main prayers (Sign of the Cross, Our Father, Hail Mary, Glory Be) are Malayalam; story/saint text is English until you add Malayalam via Content Sync (`title_ml`, `summary_ml`, …). **Have a native speaker or your parish priest review all Malayalam text before publishing.**
* **Not included because they need a server you would have to run and moderate:** user accounts and multi-device sync, a moderated community prayer wall, parish/diocese directory pages, QR/invitation links, reports and moderation tools. Instead the app offers a **local backup file** (move it between phones) and **share-text invitations**. Tell me if you want to add a server (e.g. Firebase) later.
* **Audio/music:** the Music & Tones screen generates simple instrumental melodies and chimes on the device using Web Audio. It works offline and does not bundle copyrighted recordings. This is synthesized ambient music, not recorded hymns or vocal worship songs; licensed recordings can be added later.
* This is a **debug APK** for testing. For the Play Store you will need a signed release build.

## Automatic content updates (stories, saints, readings, corrections)
1. Create a new public GitHub repo, upload the files from `content-feed-template/` (see its README.txt), turn on **Pages**.
2. In the app: **Me → Settings → Content feed** → paste `https://YOUR-USERNAME.github.io/REPO/manifest.json`.
3. To publish a change: edit a pack file and raise its `version` in `manifest.json`. The app checks when opened (at most every 12 h), downloads new packs, keeps them offline, and shows the last-sync time (**Me → Content Sync**).
Only https is accepted; packs are plain data (never code), size-limited, and may carry a SHA-256 checksum.

## Bible text licence
Original Douay–Rheims (public domain). Data from github.com/janvier-s/original-douay-rheims (CC0), pinned to commit `cd4439a1b5bbf2abe253d68b0896c3c60e8f27bc`. Psalms use Vulgate numbering; the app converts modern (lectionary) Psalm numbers automatically and shows the whole psalm.
Do not paste copyrighted lectionary or modern-translation text into packs unless you hold the licence.

## Folder map
`app/src/main/assets/` = the app (index.html, css/, js/). `js/saints.js` saints · `js/liturgy.js` calendar engine · `js/readings.js` readings · `js/stories.js` stories · `js/prayers.js` prayers · `js/learn.js` quiz/trivia/challenges.
`app/src/main/java/.../` = MainActivity (host + bridge), ContentSync, Reminders.


## New in 2.1
* **Learn the Faith** (27 topics from the Catechism and Canon Law), **Glossary** (45 terms), **Confession guide** and **Examination of conscience** (nothing is saved), **Help in Need** (14 situations with Scripture and a prayer), **Scripture by Topic** (18 topics), **Biblical & Church Timeline**, introductions to all 73 Bible books, chapter "read" tracking, a **Coming up** card on Home (computed from the calendar) and fasting/abstinence notes on Ash Wednesday, Good Friday and Fridays of Lent. Items that vary by country are marked "varies".
* **Feed address fix:** if you paste a website or folder address, the app adds `/manifest.json` for you, and shows a clear message if the address returns a web page.

## Hidden AI Assistant (Google Gemini) — replaces ChatGPT in 2.2
Unlock: **Me → Privacy → tap the version line 7 times**, then **Me → Settings → AI Assistant**: paste your own **Google AI Studio API key** (starts with `AIza`; create it at aistudio.google.com), keep the model `gemini-2.5-flash` (or change it), choose a daily limit.
An **Expand with AI** card then appears on every story, saint and calendar day. Choose Concise (~700), Detailed (~1,500) or Full chapter (~3,500 words). Gemini writes in the background using **Google Search grounding**, the result is saved in the built-in database for offline reading (Me → Settings → My expanded content), and you get a notification if the app is in the background.
* The key is kept only by the Android code, excluded from backups, and sent only to generativelanguage.googleapis.com. **Never put a key in the project or the content feed.** Any old ChatGPT/OpenAI key from version 2.1 is erased on first launch.
* Free-tier keys have rate limits and daily quotas; if you see a quota message, wait or use a paid plan.
* If a model rejects Google Search or the "thinking" setting, the app automatically retries without it and tells you.
* Calendar facts and the Douay–Rheims text are given to Gemini as authoritative; it is told never to invent quotes or miracles and to label tradition and legend. **It is still AI: read before you publish or teach.**

## Built-in database and automatic updates (new in 2.2)
* The app now has a private **SQLite database** on the phone. It stores downloaded content packs (with versions), the log of updates, and your saved AI expansions, all readable offline. Me → Content Sync shows what is inside.
* **Automatic updates:** after you set the content feed address, Android checks about every 12 hours **in the background, even when the app is closed** (only when online), and also when you open the app. New stories, saints, readings, calendar corrections, quiz questions and trivia go straight into the database. Android may delay background checks to save battery.
* Content you already downloaded with version 2.0/2.1 is moved into the database automatically.


## New in 2.3 — social media and Wallpaper Studio
**Your channels** (taken from your original app): YouTube `@risewiththeword`, Instagram `rise.withtheword`, Facebook `risewiththeword1`. The tagline is now **EVERY DAY WITH GOD'S WORD** (from your new artwork).
* **Stay Connected** (Home, Discover, Me): your three channels open **inside the app** in a protected viewer that only allows YouTube, Facebook and Instagram (no outside browser).
* **Latest videos:** the app reads your channel's public YouTube feed (no API key), keeps the list in the built-in database, plays videos inside the app, and can notify you of new uploads (background check about every 12 h; switch off in Settings → Social).
* **Videos linked to content:** add a `videos` pack to your content feed to show a "Watch our video" button on a story (`"story:s4": "VIDEO_ID"`), a saint (`"saint:10-18|St Luke"`) or a day (`"day:2026-10-18"`). A `social` pack can change handles and links without a new APK (see `content-feed-template`).
* **Sharing** adds your YouTube and Instagram handles (can be switched off). Scripture cards carry `@risewiththeword`.
* **Limits:** Facebook, Instagram and YouTube may refuse their *sign-in* pages inside an app, so subscribing/liking may not work in the viewer. Settings → Social → "Open links in the real apps" hands those links to the YouTube/Facebook/Instagram apps instead. If videos do not load, enter your YouTube channel ID (starts with UC) in Settings → Social.

**Wallpaper Studio** (Discover / Me): 
* Two **ready-made wallpapers** (your artwork, built in, work offline).
* **Create with AI** using your Gemini key: **Chibi** (cute Pixar-style, uses your two artworks as style references) or **Epic** (cinematic painting), for a Bible story, the saint of the day, or your own idea. The AI draws the picture with no text; the app then adds **RISE WITH THE WORD**, the tagline and an optional verse in sharp gold lettering.
* **Save to Photos, Share, or Set as home / lock / both** screens. Artwork is kept in the built-in database ("My wallpapers").
* Notes: image creation uses your Google quota (default model `gemini-2.5-flash-image`, changeable in Settings); availability depends on your Google account and region. AI pictures can contain mistakes (hands, faces, details): check each before sharing, and keep the depiction of Jesus and the saints reverent.


## 2.3.1 hotfix + Saints expansion
* **Build fix:** a Kotlin comment contained the text `/*`, which Kotlin treats as the start of a nested comment, so the compiler failed ("Unresolved reference toast", "Unclosed comment"). Fixed, and every Kotlin file was re-checked for balanced comments, braces and quotes.
* **Saints:** now 284 entries sorted by feast day (Discover → Saint of the Day → *All saints by feast day*): filter by month or category (Martyr, Doctor, Pope, Apostle, Marian, India/Kerala...), search by name, biography or patronage, full **profile page** (life dates, patronage, "also on this day", prayer, share, AI expansion), and a **Find a patron saint** finder (students, mothers, the sick, travellers, hopeless causes...). New saints are marked "Saint (Roman Martyrology)" and never change the liturgical day. Life dates and patronages are traditional and may be incomplete: please verify.


## 2.4 — friendlier, accessible, internet-powered
**Your screenshot fixes**
* **HTTP 404 on Content Sync:** the address used `github.com/...`, which GitHub does not serve as a file. The app now converts GitHub addresses by itself (it tries `raw.githubusercontent.com` on `main` and `master`, then GitHub Pages), and Me → Content Sync has an **Easy setup**: type your GitHub name and repository name and tap one button. Error messages are now plain ("Not found (404)…", "No internet…").
* **Status bar over the top of the screen:** the page is now inside a container that respects the status bar, navigation bar and keyboard on Android 15.

**Easier to use** (Me → Settings → *Easier to use*, and a Welcome guide on first launch)
* **Easy mode** (big buttons, simpler Home), four text sizes, **high-contrast** theme, bold text, extra spacing, reduced motion, larger buttons, focus outlines, labelled buttons.
* **Read aloud** (🔊 on reading screens) with the phone's own voice, English and Malayalam if the voice is installed (Android Settings → Text-to-speech).
* New Home: greeting, one big **Today's Gospel** button, eight large shortcuts, a **Search & Ask** box.

**Internet and Google search, built in** (needs a free Google Gemini key: aistudio.google.com → Get API key)
* **Ask the Web:** any question → Gemini with **Google Search** → a Catholic answer with Bible and Catechism references and sources; saved offline under *My questions*. Visible to everyone (no hidden unlock any more).
* **Trusted Catholic websites** open inside the app (Vatican, Catechism, Vatican News, USCCB, New Advent, EWTN, Catholic Answers, CBCI, Franciscan Media, Aleteia, Wikipedia). Only this fixed list is allowed.
* **Content that adds itself:** once a key is saved, the app queues the next four days of **daily reflections**, the **saint of the day** and **Today in the Church** (news from Vatican News and Catholic sources, India included). Android writes them in the background into the built-in database, even when the app is closed (about every 12 hours on a network, plus when you open the app). Turn off in Settings → *Internet & automatic content*. No one has to add content by hand.
* **Limits:** free Gemini keys have quotas; AI text can contain errors (labelled "AI-written", with sources). Background work may be delayed by Android battery saving. News is only as good as the web search results: check important items.

**Catholic Guide** (Home → Catholic Guide)
* **Ask & Answer:** 42 answers to popular questions (Bible and Tradition, Mary and the saints, sacraments, worship, morals, salvation and the afterlife, Church authority, Indian Catholic life), each with Scripture text from the offline Bible, Catechism/Canon Law references, sharing and "explain more with the web".
* **Problem Solver:** 15 real-life situations (anxiety, doubt, guilt, family, marriage, illness, money, addiction, anger, loneliness, grief, temptation, decisions, fear of death, dry prayer) with understanding, practical steps, prayer, Scripture, sacraments and saints. A crisis banner gives India's **112** and **Tele-MANAS 14416** (please check availability in your state).
* **Latin phrases** (37), **sacraments in detail**, councils, apparitions, funerals, vocations, Liturgy of the Hours, adoration, and the **Indian Catholic heritage**: the Church in India, St Thomas, history, shrines, devotions and customs. The Syro-Malabar and Syro-Malankara Churches are described, not mixed into the Roman calendar.
* Everything follows the Bible and the teaching of the Church. Where practice differs (country, rite, diocese) the text says so. Please have your parish priest review the content before you present it as official guidance.


## Update notes (offline content and display)
- Fixed Bible chapter-range labels so chapter-only references no longer display a fake ending verse such as `16:9999`.
- Expanded the offline Bible quiz and Catholic trivia collection.
- Added additional saint catalogue entries. These are short index biographies; they are not 3,500-word biographies. Use the Gemini expansion feature for long-form biographies and verify historical details before publishing.
- Added subtle interface motion and a reduced-motion accessibility fallback.
- Music remains synthesized locally; recorded hymns are not bundled because audio licensing must be confirmed.


## Version 3.1.0 — source integration groundwork

- Added a POC Malayalam Bible integration status and dataset contract. POC text is **not bundled** until an authorized offline-redistribution dataset is supplied.
- Added Liturgical-Calendar API integration notes. Its calendar metadata is not the same as the Mass Lectionary text, and generic calendar data must not be described as an approved Indian Ordo without verification.
- Existing Malayalam 66-book text and the 73-book Catholic catalogue remain separate; the seven deuterocanonical entries still have no Malayalam text in this build.
- Android version updated to 3.1.0. A full Android APK build has not been run in this environment.


## Version 3.7 — lawful Bible data pipeline

This version adds a coverage auditor for normalized Bible datasets, expands the importer to recognise common redistribution licence classes (with stricter manual-review handling for restrictive licences), documents a candidate Malayalam IRV CC BY-SA 4.0 source, and updates source status. The Malayalam IRV source has not been downloaded or bundled in this release; its Catholic 73-book completeness is not assumed. POC Bible text/audio remain excluded. See `docs/BIBLE_DATA_SOURCES_AND_LICENCES.md`.

## Version 4.0 — Ordo date scaffold
See `VERSION_4.0_ORDO_DATE_SCAFFOLD.md`. The 2026–2027 India Roman Rite pack now has a record for every date, with all reading fields blank and clearly marked pending verification. Run `python tools/generate_ordo_scaffold.py` to regenerate it. This is a scaffold, not a completed lectionary.

## Version 4.6 progress tools
Run `python3 tools/project_progress.py` to regenerate the factual data snapshot at `content-feed-template/project-progress-v4.6.json`. The snapshot intentionally reports blank liturgical scaffolds and missing Malayalam text separately rather than treating catalogue records as complete content. See `VERSION_4.6_PROGRESS_AND_AUDIT_FIX.md`.


## Version 5.0 — supplied Catholic artwork pack

See `VERSION_5.0_CATHOLIC_ART_PACK.md`. Ten newly supplied images have been added as offline assets and are catalogued in the Image Packs browser.

## Version 5.0.0 — supplied Catholic artwork pack

Ten supplied images have been added for offline use, together with Image Packs categories, a featured Home gallery, branded launcher icons, and metadata with hashes. See `VERSION_5.0_CATHOLIC_ART_PACK.md`. This does not complete missing Malayalam Bible text or the official lectionary.


## Version 5.4 — Calendar, daily readings, and saints package
The app bundles liturgical data schemas/templates, source and licensing checklist, and a content-verification status card on Calendar and Daily Gospel screens. These additions improve integration and transparency; they do not add a complete approved India lectionary or verified India Ordo. See `VERSION_5.4_CALENDAR_READINGS_SAINTS_PACKAGE.md` and `app/src/main/assets/content/liturgical/`.
