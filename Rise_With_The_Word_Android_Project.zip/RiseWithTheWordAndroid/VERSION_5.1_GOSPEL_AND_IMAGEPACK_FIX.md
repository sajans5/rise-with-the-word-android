# v5.1 — Visible Image Packs and Gospel Range Correction

## Changes
- Image Packs is now the first card in Discover's visual feature gallery, so it is visible without scrolling to the bottom.
- Added an explicit Gospel reference for 22 October 2026: Luke 12:49–53, not the whole chapter of Matthew 12.

## Important limitation
This is not a complete official Indian Roman Rite lectionary. The built-in readings file still contains starter references and a continuous-reading fallback for dates without verified data. Do not label those fallback readings as the Mass Gospel. Populate every date only from a licensed, source-attributed, regionally verified lectionary feed. Check local Indian Ordo, optional memorials, solemnities and transferred celebrations before release.

## Catechism textbooks
The bundled Classes 1–12 JSON contains original supplementary guides, not the full official Kerala/diocesan Catechism textbooks. Do not copy complete textbooks into the app without permission or a redistribution licence. Integrate authorized files or link to the issuing diocesan/KRLCBC source, and keep the original study guides as supplementary material.

## Bible
The English Douay–Rheims build pipeline is intended to generate all 73 books. Malayalam data must be audited book-by-book; the presence of a book in the catalogue is not proof that its full text is bundled. Only use translations whose licences allow offline redistribution, and include their attribution and licence terms.
