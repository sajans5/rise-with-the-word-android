/* RWTW calendar/readings/saints data-package status. Never marks unverified data official. */
(function (W) {
  'use strict';
  W.RWTW_LITURGICAL_CONTENT_STATUS = {
    version: '1.0.0',
    get: function () {
      return {
        calendar: 'India-specific Ordo rows verified: 0',
        readings: 'Official daily reading records verified: 0',
        saints: 'Existing saints content requires source review',
        note: 'This app calculates a Roman Rite calendar and includes starter reading references. Verify dates and readings against the approved CCBI/diocesan Ordo. Bible reading plans are not Mass readings.'
      };
    },
    card: function () {
      var x = this.get();
      return '<div class="card"><h3>Calendar &amp; content verification</h3>' +
        '<p><b>Calendar:</b> ' + x.calendar + '</p>' +
        '<p><b>Daily readings:</b> ' + x.readings + '</p>' +
        '<p><b>Saints:</b> ' + x.saints + '</p>' +
        '<p class="small muted">' + x.note + '</p>' +
        '<p class="small"><a href="https://www.ccbi.in/post/liturgical-calendar-ordo-for-the-year-2026-2027" target="_blank" rel="noopener">Check CCBI Ordo 2026–2027</a></p></div>';
    }
  };
})(window);
