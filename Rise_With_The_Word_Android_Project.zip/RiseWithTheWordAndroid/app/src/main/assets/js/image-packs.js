/* Offline image-pack browser. Only catalogued bundled assets are shown; no network calls. */
(function(){
  'use strict';
  var W=window,A=W.RWTW,SC=A.screens,AC=A.actions,esc=A.esc;
  var CATALOG={categories:[],assets:[]};
  try { /* Static catalog is embedded here so file:// WebView does not need fetch(). */
    CATALOG=window.RWTW_IMAGE_PACKS||CATALOG;
  } catch(e){}
  var items=[
    {id:'feature-home',path:'images/feature/home-hero.jpg',category:'feature-art',title:'Welcome Home',alt:'Catholic faith guide artwork for the home screen'},
    {id:'feature-bible',path:'images/feature/bible-reader.jpg',category:'feature-art',title:'Bible Reader',alt:'Devotional artwork representing Bible reading'},
    {id:'feature-calendar',path:'images/feature/liturgy-calendar.jpg',category:'liturgical-seasons',title:'Liturgical Calendar',alt:'Artwork representing the liturgical calendar'},
    {id:'feature-prayer',path:'images/feature/prayer-chapel.jpg',category:'prayer-rosary',title:'Prayer Chapel',alt:'Peaceful chapel-themed devotional artwork'},
    {id:'feature-saints',path:'images/feature/saints-gallery.jpg',category:'saints-feasts',title:'Saints Gallery',alt:'Artwork representing saints and feast days'},
    {id:'feature-catechism',path:'images/feature/catechism-study.jpg',category:'catechism',title:'Catechism Study',alt:'Artwork representing Catholic learning and study'},
    {id:'wallpaper-heroes',path:'images/wallpapers/rwtw1.jpg',category:'wallpapers',title:'Heroes of the Bible',alt:'Portrait-format Bible-themed wallpaper'},
    {id:'wallpaper-sunset',path:'images/wallpapers/rwtw2.jpg',category:'wallpapers',title:'The Sermon at Sunset',alt:'Portrait-format devotional wallpaper showing a sunset scene'},
    {id:'rwtw-logo',path:'images/brand/rwtw-logo.png',category:'brand',title:'Rise With The Word Logo',alt:'Gold-framed cross, open Bible, dove and Rise With The Word title',square:true},
    {id:'rwtw-catholic-faith-guide',path:'images/feature/catholic-faith-guide.jpg',category:'faith-guide',title:'Discover the Catholic Faith',alt:'Catholic faith guide artwork with Scripture, tradition, sacraments, saints and prayer',poster:true},
    {id:'rwtw-saint-of-the-day',path:'images/feature/saint-of-the-day.jpg',category:'saints-feasts',title:'Saint of the Day',alt:'Saints and devotional artwork for daily saint discovery',poster:true},
    {id:'rwtw-bible-library',path:'images/feature/bible-library.jpg',category:'bible-library',title:'Bible Library',alt:'Bible library feature illustration',poster:true},
    {id:'rwtw-daily-gospel',path:'images/feature/daily-gospel.jpg',category:'daily-gospel',title:'Daily Gospel',alt:'Jesus teaching the people with an open Bible in the foreground',poster:true},
    {id:'rwtw-prayer-centre',path:'images/feature/prayer-centre.jpg',category:'prayer-rosary',title:'Prayer Centre',alt:'Prayer and Rosary themed church artwork',poster:true},
    {id:'rwtw-sacraments',path:'images/feature/sacraments.jpg',category:'sacraments',title:'The Sacraments',alt:'Illustrated overview of the seven Catholic sacraments',poster:true},
    {id:'rwtw-catechism-faith-guide',path:'images/feature/catechism-faith-guide.jpg',category:'catechism',title:'Catholic Catechism and Faith Guide',alt:'Catechism and Catholic faith learning artwork',poster:true},
    {id:'rwtw-liturgical-calendar',path:'images/feature/liturgical-calendar.jpg',category:'liturgical-seasons',title:'Catholic Liturgical Calendar',alt:'Church seasons including Advent, Lent, Christmas, Holy Week and Easter',poster:true},
    {id:'rwtw-saints-calendar',path:'images/feature/saints-calendar.jpg',category:'saints-feasts',title:'Saints and Feast Calendar',alt:'Saints, feast days and devotional calendar artwork',poster:true},
    {id:'reference-1',path:'images/refs/ref1.jpg',category:'reference-art',title:'Wallpaper Style Reference 1',alt:'Style reference image for wallpaper creation'},
    {id:'reference-2',path:'images/refs/ref2.jpg',category:'reference-art',title:'Wallpaper Style Reference 2',alt:'Style reference image for wallpaper creation'},
    {id:'owner-welcome-onboarding',path:'images/feature/welcome-onboarding.jpg',category:'welcome',title:'Welcome to Rise With The Word',alt:'Welcome illustration with Jesus, children, a Bible and the tagline Every Day With God’s Word',poster:true},
    {id:'owner-ai-bible-story',path:'images/feature/ai-bible-story-generator.jpg',category:'ai-studios',title:'AI Bible Story Generator',alt:'Illustration of choosing a Bible passage and creating a story with reflection, prayer and lesson',poster:true},
    {id:'owner-ai-image',path:'images/feature/ai-image-generator.jpg',category:'ai-studios',title:'AI Image Generator',alt:'Illustration showing multiple Christian image styles and a generation studio',poster:true},
    {id:'owner-wallpaper-studio',path:'images/feature/wallpaper-studio.jpg',category:'wallpapers',title:'Chibi Wallpaper Studio',alt:'Illustration showing Bible story, Jesus, Mother Mary and saint wallpaper categories',poster:true},
    {id:'owner-catholic-qa',path:'images/feature/catholic-qa.jpg',category:'faith-guide',title:'Catholic Faith Questions & Answers',alt:'Catholic questions and answers supported by Bible and Catechism references',poster:true},
    {id:'owner-prayer-centre',path:'images/feature/prayer-centre.jpg',category:'prayer-rosary',title:'Catholic Prayer Centre',alt:'Daily prayer, Holy Rosary, Divine Mercy Chaplet and novenas',poster:true},
    {id:'owner-bible-study',path:'images/feature/bible-study.jpg',category:'bible-library',title:'Catholic Bible Study',alt:'Bible chapter summaries, verse explanations, cross references and study notes',poster:true},
    {id:'owner-saints-explorer',path:'images/feature/saints-explorer.jpg',category:'saints-feasts',title:'Saint of the Day and Saints Explorer',alt:'Saint biographies, feast days and saint calendar artwork',poster:true},
    {id:'owner-mass-calendar',path:'images/feature/mass-calendar.jpg',category:'liturgical-seasons',title:'Catholic Mass and Liturgical Calendar',alt:'Liturgical year, seasons and daily Mass reading artwork',poster:true},
    {id:'owner-catholic-ai-research',path:'images/feature/catholic-ai-research.jpg',category:'faith-guide',title:'Catholic AI Research and Search',alt:'Catholic questions, Bible references, Catechism and trusted-source search artwork',poster:true}
  ];
  var cats=[['all','All images'],['brand','Brand'],['welcome','Welcome'],['wallpapers','Wallpapers'],['ai-studios','AI Studios'],['feature-art','Feature art'],['faith-guide','Catholic faith'],['bible-library','Bible Library & Study'],['daily-gospel','Daily Gospel'],['saints-feasts','Saints & feasts'],['prayer-rosary','Prayer & Rosary'],['sacraments','Sacraments'],['catechism','Catechism'],['liturgical-seasons','Liturgical seasons'],['reference-art','Style references']];
  var active='all';
  function card(x){return '<article class="image-pack-card '+(x.poster?'poster ':'')+(x.square?'square':'')+'"><img loading="lazy" src="'+esc(x.path)+'" alt="'+esc(x.alt)+'"><strong>'+esc(x.title)+'</strong><small>'+esc(cats.filter(function(c){return c[0]===x.category;})[0]?.[1]||'Image pack')+'</small></article>';}
  SC.imagepacks=function(){var shown=items.filter(function(x){return active==='all'||x.category===active;});var h='<p class="muted">Browse the artwork already bundled with the app. These images work offline.</p><div class="image-pack-filter" role="group" aria-label="Filter image packs">'+cats.map(function(c){return '<button class="chip '+(active===c[0]?'on':'')+'" data-act="imagePackFilter" data-v="'+c[0]+'" aria-pressed="'+(active===c[0]?'true':'false')+'">'+c[1]+'</button>';}).join('')+'</div><div class="image-pack-grid">'+shown.map(card).join('')+'</div><div class="card"><h3>More image packs can be added</h3><p>Next additions can include scene-by-scene Bible story sets, Old and New Testament character collections, children’s activity illustrations, and Scripture-card backgrounds.</p><p class="small muted">New packs should include creator/source, reuse licence, image dimensions, file hash and descriptive alt text. Unverified reference images must not be redistributed.</p></div>';return {title:'Image Packs',html:h};};
  AC.imagePackFilter=function(el){active=el.getAttribute('data-v')||'all';A.refresh();};
  function addTile(name,tile){var original=SC[name];if(!original)return;SC[name]=function(){var o=original.apply(null,arguments),i=o.html.lastIndexOf('</div>');if(i>=0)o.html=o.html.slice(0,i)+tile+o.html.slice(i);else o.html+=tile;return o;};}
  var tile='<button class="tile" data-act="go" data-arg="imagepacks"><span class="ico" aria-hidden="true">🖼️</span><b>Image Packs</b><span>Browse '+items.length+' offline artworks by category</span></button>';
  addTile('discover',tile);addTile('me',tile);
})();
