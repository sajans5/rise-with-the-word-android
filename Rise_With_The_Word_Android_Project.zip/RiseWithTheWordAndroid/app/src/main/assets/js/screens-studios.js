/* Feature studio landing screens based on artwork supplied for Rise With The Word.
   These link to existing app capabilities; they do not pretend remote AI is available offline. */
(function () {
  'use strict';
  var W = window, A = W.RWTW, SC = A.screens, AC = A.actions, esc = A.esc;
  function art(file, alt) {
    return '<img class="studio-hero-art" loading="lazy" src="images/feature/' + file + '" alt="' + esc(alt) + '">';
  }
  function goCard(icon, title, sub, route) {
    return '<button class="tile" data-act="go" data-arg="' + route + '"><span class="ico">' + icon + '</span><b>' + esc(title) + '</b><span>' + esc(sub) + '</span></button>';
  }

  /* Story studio: start from a bundled, reference-linked story, then use its existing AI expansion control. */
  SC.aiStoryStudio = function () {
    var stories = Array.isArray(W.RWTW_STORIES) ? W.RWTW_STORIES : [];
    var h = art('ai-bible-story-generator.jpg', 'AI Bible Story Generator: choose a Bible passage, explore its context, reflection and prayer.');
    h += '<div class="banner">Choose a Bible story below. Open its page to read the Scripture reference and use the existing AI expansion control when the optional Gemini feature is configured. AI-written material needs review before teaching.</div>';
    if (!stories.length) h += '<p class="muted">The offline story list is not ready yet. Try again after content has loaded.</p>';
    h += '<input id="studioStorySearch" type="search" placeholder="Search Bible stories" aria-label="Search Bible stories">';
    h += '<div id="studioStoryList" class="list">' + stories.slice(0, 80).map(function (s) {
      return '<button class="item" data-act="studioOpenStory" data-id="' + esc(s.id) + '"><b>' + esc(s.title || 'Bible story') + '</b><span>' + esc(s.ref || 'Scripture reference') + '</span><span>' + esc(s.summary || '') + '</span></button>';
    }).join('') + '</div>';
    h += '<p class="small muted">AI generation requires a configured provider connection. The bundled Scripture and story summaries remain available offline.</p>';
    return { title: 'AI Bible Story Generator', html: h, after: function () {
      var input = A.$('#studioStorySearch'), list = A.$('#studioStoryList');
      if (input && list) input.addEventListener('input', function () {
        var q = input.value.toLowerCase();
        list.innerHTML = stories.filter(function (s) { return ((s.title || '') + ' ' + (s.ref || '') + ' ' + (s.summary || '')).toLowerCase().indexOf(q) >= 0; }).slice(0, 80).map(function (s) {
          return '<button class="item" data-act="studioOpenStory" data-id="' + esc(s.id) + '"><b>' + esc(s.title || 'Bible story') + '</b><span>' + esc(s.ref || 'Scripture reference') + '</span><span>' + esc(s.summary || '') + '</span></button>';
        }).join('') || '<p class="muted">No matching stories found.</p>';
      });
    }};
  };
  AC.studioOpenStory = function (el) { A.go('story', el.getAttribute('data-id')); };

  /* Image-generation landing screen links to the existing native wallpaper/image generation workflow. */
  SC.aiImageStudio = function () {
    var h = art('ai-image-generator.jpg', 'AI Image Generator with cinematic, anime, chibi, illustration and icon style examples.');
    h += '<div class="card"><h3>Create Christian artwork</h3><p>Choose a style and scene in the existing generator. New image generation needs the optional Gemini image capability and an internet connection; the local gallery and bundled artworks remain available offline.</p><div class="row"><button class="btn block" data-act="go" data-arg="wallpaper">Open image generator</button><button class="btn alt block" data-act="go" data-arg="imagepacks">Browse offline images</button></div></div>';
    h += '<div class="grid">' + goCard('📱', 'Wallpaper Studio', 'Create and save phone wallpapers', 'wallpaper') + goCard('🖼️', 'Offline Image Packs', 'Browse artwork already on this phone', 'imagepacks') + '</div>';
    return { title: 'AI Image Generator', html: h };
  };

  /* Q&A landing page points to the existing Catholic guide, topic library and web search. */
  SC.catholicQA = function () {
    var h = art('catholic-qa.jpg', 'Catholic faith questions and answers, with Scripture and Catechism references.');
    h += '<div class="banner">Explore Catholic teaching using Scripture, the Catechism and trusted Church sources. Online searches require a connection. Check important or personal pastoral questions with a qualified Catholic pastor.</div>';
    h += '<div class="grid">' + goCard('🧭', 'Catholic Guide', 'Answers and practical guidance', 'guide') + goCard('📚', 'Learn the Faith', 'Browse Catholic teaching topics', 'faith') + goCard('🌐', 'Ask the Web', 'Search trusted online sources', 'ask') + goCard('📖', 'Bible', 'Read and search Scripture', 'bible') + goCard('🕯️', 'Prayer Centre', 'Traditional prayers and devotions', 'pray') + goCard('📅', 'Liturgical Calendar', 'Seasons, feasts and daily readings', 'calendar') + '</div>';
    return { title: 'Catholic Faith Q&A', html: h };
  };

  /* Make the owner-supplied welcome art part of the actual setup screen. */
  if (SC.welcome) {
    var oldWelcome = SC.welcome;
    SC.welcome = function () {
      var o = oldWelcome();
      o.html = art('welcome-onboarding.jpg', 'Welcome to Rise With The Word, with Jesus and children gathered around Scripture.') + o.html;
      return o;
    };
  }

  /* Add new visual cards after the original screen definitions have loaded. */
  var oldDiscover = SC.discover;
  SC.discover = function () {
    var o = oldDiscover();
    var featured = '<button class="imagepacks-highlight" data-act="go" data-arg="imagepacks" aria-label="Open Image Packs, the offline artwork gallery"><img loading="lazy" src="images/feature/wallpaper-studio.jpg" alt="Bible-themed wallpaper and image pack examples"><span><b>Image Packs</b><small>Browse all bundled artwork offline</small></span><strong aria-hidden="true">›</strong></button>';
    var cards = [
      ['ai-bible-story-generator.jpg','AI Bible Story Generator','aiStoryStudio'],
      ['ai-image-generator.jpg','AI Image Generator','aiImageStudio'],
      ['wallpaper-studio.jpg','Chibi Wallpaper Studio','wallpaper'],
      ['catholic-qa.jpg','Catholic Faith Q&A','catholicQA'],
      ['prayer-centre.jpg','Prayer Centre','pray'],
      ['bible-study.jpg','Bible Study','bible'],
      ['saints-explorer.jpg','Saints & Feast Days','saints'],
      ['mass-calendar.jpg','Mass & Liturgical Calendar','calendar'],
      ['catholic-ai-research.jpg','Catholic AI Research & Search','ask']
    ];
    var gallery = '<h3 class="section-heading">New feature studios</h3><div class="feature-gallery" aria-label="New feature studios">' + cards.map(function (f) {
      return '<button class="feature-card" data-act="go" data-arg="' + f[2] + '"><img loading="lazy" src="images/feature/' + f[0] + '" alt=""><span>' + esc(f[1]) + '</span></button>';
    }).join('') + '</div>';
    o.html = featured + gallery + o.html;
    return o;
  };

  /* Direct access from Home too, so Image Packs is not buried in Discover. */
  var oldHome = SC.home;
  SC.home = function () {
    var o = oldHome();
    var direct = '<button class="imagepacks-highlight" data-act="go" data-arg="imagepacks" aria-label="Open offline Image Packs"><img loading="lazy" src="images/feature/wallpaper-studio.jpg" alt=""><span><b>Image Packs</b><small>Offline devotional artwork and wallpapers</small></span><strong aria-hidden="true">›</strong></button>';
    o.html = direct + o.html;
    return o;
  };
})();
