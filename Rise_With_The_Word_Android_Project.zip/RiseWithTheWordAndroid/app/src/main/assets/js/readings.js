/* Daily readings.
   Priority for a given date:
     1. A synced "readings" pack (official full readings): window.RWTW_PACKS.readings[YYYY-MM-DD]
     2. Built-in table: Gospel citations for Sundays and major solemnities (+ full readings for a few fixed days)
     3. Fallback: a continuous Gospel reading plan (clearly labelled - NOT the Mass lectionary)
   The built-in table is a starter. Please verify it against your national lectionary,
   and use Content Sync to deliver complete readings for every day. */
window.RWTW_READINGS = (function () {
  var OT = { // Gospel for Sundays in Ordinary Time, by cycle and Sunday number
    A: { 2: 'Jn 1:29-34', 3: 'Mt 4:12-23', 4: 'Mt 5:1-12a', 5: 'Mt 5:13-16', 6: 'Mt 5:17-37', 7: 'Mt 5:38-48', 8: 'Mt 6:24-34', 9: 'Mt 7:21-27', 10: 'Mt 9:9-13', 11: 'Mt 9:36-10:8', 12: 'Mt 10:26-33', 13: 'Mt 10:37-42', 14: 'Mt 11:25-30', 15: 'Mt 13:1-23', 16: 'Mt 13:24-43', 17: 'Mt 13:44-52', 18: 'Mt 14:13-21', 19: 'Mt 14:22-33', 20: 'Mt 15:21-28', 21: 'Mt 16:13-20', 22: 'Mt 16:21-27', 23: 'Mt 18:15-20', 24: 'Mt 18:21-35', 25: 'Mt 20:1-16a', 26: 'Mt 21:28-32', 27: 'Mt 21:33-43', 28: 'Mt 22:1-14', 29: 'Mt 22:15-21', 30: 'Mt 22:34-40', 31: 'Mt 23:1-12', 32: 'Mt 25:1-13', 33: 'Mt 25:14-30' },
    B: { 2: 'Jn 1:35-42', 3: 'Mk 1:14-20', 4: 'Mk 1:21-28', 5: 'Mk 1:29-39', 6: 'Mk 1:40-45', 7: 'Mk 2:1-12', 8: 'Mk 2:18-22', 9: 'Mk 2:23-3:6', 10: 'Mk 3:20-35', 11: 'Mk 4:26-34', 12: 'Mk 4:35-41', 13: 'Mk 5:21-43', 14: 'Mk 6:1-6', 15: 'Mk 6:7-13', 16: 'Mk 6:30-34', 17: 'Jn 6:1-15', 18: 'Jn 6:24-35', 19: 'Jn 6:41-51', 20: 'Jn 6:51-58', 21: 'Jn 6:60-69', 22: 'Mk 7:1-8,14-15,21-23', 23: 'Mk 7:31-37', 24: 'Mk 8:27-35', 25: 'Mk 9:30-37', 26: 'Mk 9:38-43,45,47-48', 27: 'Mk 10:2-16', 28: 'Mk 10:17-30', 29: 'Mk 10:35-45', 30: 'Mk 10:46-52', 31: 'Mk 12:28b-34', 32: 'Mk 12:38-44', 33: 'Mk 13:24-32' },
    C: { 2: 'Jn 2:1-11', 3: 'Lk 1:1-4; 4:14-21', 4: 'Lk 4:21-30', 5: 'Lk 5:1-11', 6: 'Lk 6:17,20-26', 7: 'Lk 6:27-38', 8: 'Lk 6:39-45', 9: 'Lk 7:1-10', 10: 'Lk 7:11-17', 11: 'Lk 7:36-8:3', 12: 'Lk 9:18-24', 13: 'Lk 9:51-62', 14: 'Lk 10:1-12,17-20', 15: 'Lk 10:25-37', 16: 'Lk 10:38-42', 17: 'Lk 11:1-13', 18: 'Lk 12:13-21', 19: 'Lk 12:32-48', 20: 'Lk 12:49-53', 21: 'Lk 13:22-30', 22: 'Lk 14:1,7-14', 23: 'Lk 14:25-33', 24: 'Lk 15:1-32', 25: 'Lk 16:1-13', 26: 'Lk 16:19-31', 27: 'Lk 17:5-10', 28: 'Lk 17:11-19', 29: 'Lk 18:1-8', 30: 'Lk 18:9-14', 31: 'Lk 19:1-10', 32: 'Lk 20:27-38', 33: 'Lk 21:5-19' }
  };
  var ADVENT = { A: ['Mt 24:37-44', 'Mt 3:1-12', 'Mt 11:2-11', 'Mt 1:18-24'], B: ['Mk 13:33-37', 'Mk 1:1-8', 'Jn 1:6-8,19-28', 'Lk 1:26-38'], C: ['Lk 21:25-28,34-36', 'Lk 3:1-6', 'Lk 3:10-18', 'Lk 1:39-45'] };
  var LENT = { A: ['Mt 4:1-11', 'Mt 17:1-9', 'Jn 4:5-42', 'Jn 9:1-41', 'Jn 11:1-45'], B: ['Mk 1:12-15', 'Mk 9:2-10', 'Jn 2:13-25', 'Jn 3:14-21', 'Jn 12:20-33'], C: ['Lk 4:1-13', 'Lk 9:28b-36', 'Lk 13:1-9', 'Lk 15:1-3,11-32', 'Jn 8:1-11'] };
  var PASSION = { A: 'Mt 26:14-27:66', B: 'Mk 14:1-15:47', C: 'Lk 22:14-23:56' };
  var EASTER = { A: ['Lk 24:13-35', 'Jn 10:1-10', 'Jn 14:1-12', 'Jn 14:15-21', 'Jn 17:1-11a'], B: ['Lk 24:35-48', 'Jn 10:11-18', 'Jn 15:1-8', 'Jn 15:9-17', 'Jn 17:11b-19'], C: ['Jn 21:1-19', 'Jn 10:27-30', 'Jn 13:31-33a,34-35', 'Jn 14:23-29', 'Jn 17:20-26'] };
  var DIVINE_MERCY = { A: { first: 'Acts 2:42-47', second: '1 Pt 1:3-9' }, B: { first: 'Acts 4:32-35', second: '1 Jn 5:1-6' }, C: { first: 'Acts 5:12-16', second: 'Rv 1:9-11a,12-13,17-19' } };
  var SPECIAL = { // by cycle
    ascension: { A: 'Mt 28:16-20', B: 'Mk 16:15-20', C: 'Lk 24:46-53' }, trinity: { A: 'Jn 3:16-18', B: 'Mt 28:16-20', C: 'Jn 16:12-15' },
    corpus: { A: 'Jn 6:51-58', B: 'Mk 14:12-16,22-26', C: 'Lk 9:11b-17' }, heart: { A: 'Mt 11:25-30', B: 'Jn 19:31-37', C: 'Lk 15:3-7' },
    king: { A: 'Mt 25:31-46', B: 'Jn 18:33b-37', C: 'Lk 23:35-43' }, family: { A: 'Mt 2:13-15,19-23', B: 'Lk 2:22-40', C: 'Lk 2:41-52' },
    baptism: { A: 'Mt 3:13-17', B: 'Mk 1:7-11', C: 'Lk 3:15-16,21-22' }, transfig: { A: 'Mt 17:1-9', B: 'Mk 9:2-10', C: 'Lk 9:28b-36' }
  };
  // Full readings that do not depend on the Sunday cycle (keyed by 'MM-DD' of the fixed solemnity or by special name)
  var FIXED = {
    // Explicit date override reviewed for the Roman Rite weekday lectionary.
    // The app must still compare regional calendars and transferred celebrations.
    '10-22': { gospel: 'Lk 12:49-53', note: 'Thursday of the 29th Week in Ordinary Time · weekday cycle II' },
    '12-25': { first: 'Is 52:7-10', psalm: 'Ps 98:1-6', second: 'Heb 1:1-6', gospel: 'Jn 1:1-18', note: 'Mass during the Day' },
    '01-01': { first: 'Nm 6:22-27', psalm: 'Ps 67:2-3,5,6,8', second: 'Gal 4:4-7', gospel: 'Lk 2:16-21' },
    '12-08': { first: 'Gn 3:9-15,20', psalm: 'Ps 98:1-4', second: 'Eph 1:3-6,11-12', gospel: 'Lk 1:26-38' },
    '08-15': { first: 'Rv 11:19a; 12:1-6a,10ab', psalm: 'Ps 45:10-12,16', second: '1 Cor 15:20-27', gospel: 'Lk 1:39-56', note: 'Mass during the Day' },
    '11-01': { first: 'Rv 7:2-4,9-14', psalm: 'Ps 24:1-6', second: '1 Jn 3:1-3', gospel: 'Mt 5:1-12a' },
    '03-19': { first: '2 Sm 7:4-5a,12-14a,16', psalm: 'Ps 89:2-5,27,29', second: 'Rom 4:13,16-18,22', gospel: 'Mt 1:16,18-21,24a' },
    '03-25': { first: 'Is 7:10-14; 8:10', psalm: 'Ps 40:7-11', second: 'Heb 10:4-10', gospel: 'Lk 1:26-38' },
    '06-29': { first: 'Acts 12:1-11', psalm: 'Ps 34:2-9', second: '2 Tm 4:6-8,17-18', gospel: 'Mt 16:13-19', note: 'Mass during the Day' },
    '06-24': { first: 'Is 49:1-6', psalm: 'Ps 139:1-3,13-15', second: 'Acts 13:22-26', gospel: 'Lk 1:57-66,80', note: 'Mass during the Day' },
    '02-02': { gospel: 'Lk 2:22-40' }, '05-31': { gospel: 'Lk 1:39-56' }, '09-14': { gospel: 'Jn 3:13-17' }, '11-09': { gospel: 'Jn 2:13-22' },
    '12-26': { gospel: 'Mt 10:17-22' }, '12-27': { gospel: 'Jn 20:2-8' }, '12-28': { gospel: 'Mt 2:13-18' }
  };
  var TITLE = [ // regex on the day title -> reading
    [/^The Epiphany/, { first: 'Is 60:1-6', psalm: 'Ps 72:1-2,7-8,10-13', second: 'Eph 3:2-3a,5-6', gospel: 'Mt 2:1-12' }],
    [/^Pentecost Sunday/, { first: 'Acts 2:1-11', psalm: 'Ps 104:1,24,29-31,34', second: '1 Cor 12:3b-7,12-13', gospel: 'Jn 20:19-23', note: 'Mass during the Day' }],
    [/^Easter Sunday/, { first: 'Acts 10:34a,37-43', psalm: 'Ps 118:1-2,16-17,22-23', second: 'Col 3:1-4', gospel: 'Jn 20:1-9', note: 'Mass during the Day' }],
    [/^Holy Thursday/, { first: 'Ex 12:1-8,11-14', psalm: 'Ps 116:12-13,15-18', second: '1 Cor 11:23-26', gospel: 'Jn 13:1-15' }],
    [/^Good Friday/, { first: 'Is 52:13-53:12', psalm: 'Ps 31:2,6,12-13,15-17,25', second: 'Heb 4:14-16; 5:7-9', gospel: 'Jn 18:1-19:42' }],
    [/^Ash Wednesday/, { first: 'Jl 2:12-18', psalm: 'Ps 51:3-6,12-14,17', second: '2 Cor 5:20-6:2', gospel: 'Mt 6:1-6,16-18' }],
    [/^Second Sunday after Christmas/, { gospel: 'Jn 1:1-18' }]
  ];

  // Continuous Gospel plan used when no official reading is available
  var GOSPELS = [['mk', 'Mark', 16], ['mt', 'Matthew', 28], ['lk', 'Luke', 24], ['jn', 'John', 21]];
  function planGospel(dt) {
    var total = 89, start = new Date(2026, 0, 1, 12), n = Math.round((new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), 12) - start) / 86400000);
    n = ((n % total) + total) % total;
    for (var i = 0; i < GOSPELS.length; i++) { if (n < GOSPELS[i][2]) return { ref: GOSPELS[i][1] + ' ' + (n + 1), code: GOSPELS[i][0], chapter: n + 1 }; n -= GOSPELS[i][2]; }
  }

  function forDay(day) {
    var packs = (window.RWTW_PACKS && window.RWTW_PACKS.readings) || {};
    if (packs[day.key]) {
      var packed = Object.assign({}, packs[day.key]);
      // A pack is not automatically official: only a record with an explicit source
      // and verification flag can be labelled verified.
      var verified = packed.verified === true && !!packed.sourceName;
      packed.source = 'pack';
      packed.label = verified ? ('Verified readings · ' + packed.sourceName) : 'Downloaded readings · source not verified';
      packed.verified = verified;
      return packed;
    }
    var c = day.cycle.sunday, w = day.week, t = day.title || '', md = day.md;
    var r = null, label = 'Built-in Gospel reference \u2013 verify with your local lectionary';
    for (var i = 0; i < TITLE.length; i++) if (TITLE[i][0].test(t)) { r = TITLE[i][1]; break; }
    if (!r && day.key === '2026-10-22') r = FIXED['10-22'];
    if (!r && day.rank !== 'T' && md && FIXED[md] && (day.rank === 'S' || day.rank === 'F')) r = FIXED[md];
    if (!r && /Baptism of the Lord/.test(t)) r = { gospel: SPECIAL.baptism[c] };
    if (!r && /Holy Family/.test(t)) r = { gospel: SPECIAL.family[c] };
    if (!r && /^The Ascension/.test(t)) r = { gospel: SPECIAL.ascension[c] };
    if (!r && /Holy Trinity/.test(t)) r = { gospel: SPECIAL.trinity[c] };
    if (!r && /Body and Blood/.test(t)) r = { gospel: SPECIAL.corpus[c] };
    if (!r && /Sacred Heart/.test(t)) r = { gospel: SPECIAL.heart[c] };
    if (!r && /King of the Universe/.test(t)) r = { gospel: SPECIAL.king[c] };
    if (!r && /Transfiguration/.test(t)) r = { gospel: SPECIAL.transfig[c] };
    if (!r && /^Palm Sunday/.test(t)) r = { gospel: PASSION[c], note: 'The Passion of the Lord' };
    if (!r && day.dow === 0) {
      if (day.season === 'advent' && w >= 1 && w <= 4) r = { gospel: ADVENT[c][w - 1] };
      else if (day.season === 'lent' && w >= 1 && w <= 5) r = { gospel: LENT[c][w - 1] };
      else if (day.season === 'easter') {
        if (w === 2) r = { first: DIVINE_MERCY[c].first, second: DIVINE_MERCY[c].second, gospel: 'Jn 20:19-31', note: 'Sunday of Divine Mercy' };
        else if (w >= 3 && w <= 7) r = { gospel: EASTER[c][w - 3] };
      } else if (day.season === 'ordinary' && OT[c][w]) r = { gospel: OT[c][w] };
    }
    if (r) return Object.assign({ source: 'builtin', label: label, verified: false }, r);
    // Never present an entire Gospel chapter as that day's Mass Gospel.
    // Until a source-verified daily lectionary entry is available, state the gap clearly.
    return { source: 'unavailable', label: 'Official Mass Gospel not yet verified for this date', verified: false, gospel: null };
  }
  return { forDay: forDay, planGospel: planGospel };
})();
