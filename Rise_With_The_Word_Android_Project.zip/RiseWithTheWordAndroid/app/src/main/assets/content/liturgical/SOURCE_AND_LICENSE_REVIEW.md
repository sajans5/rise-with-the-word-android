# Source & License Review Checklist

## Calendar engine
Candidate: https://github.com/Liturgical-Calendar/LiturgicalCalendarAPI
- [ ] Pin a reviewed immutable commit/tag.
- [ ] Read and include its actual `LICENSE` and required notices from that exact revision.
- [ ] Keep code license separate from calendar-data provenance and ecclesiastical approval.
- [ ] Configure the correct country/diocese options only after confirming the project's supported identifiers.
- [ ] Review Indian proper celebrations against the applicable approved Ordo.

The project's public listing identifies Apache-2.0; this is a candidate assessment, not legal advice or a substitute for verifying the exact source revision.

## Daily readings
- [ ] Prefer references (book/chapter/verses) and resolve them against the app's independently licensed Bible dataset.
- [ ] Do not scrape or bundle the full text of readings from a website unless its terms expressly permit this app use.
- [ ] Obtain written permission/licence for any copyrighted translation or lectionary text intended for offline redistribution.
- [ ] Record the translation, publisher, licence URL, scope, territory, expiry, and attribution.
- [ ] Check whether the approved lectionary for India uses the same readings/citations as the chosen calendar source.

USCCB pages are US-jurisdiction guidance, not a determination of Indian copyright law:
- https://www.usccb.org/offices/new-american-bible/permissions
- https://www.usccb.org/committees/divine-worship/policies/copyright-permissions-requirements

## Saints biographies
- [ ] Write original biographies from reliable sources rather than copying copyrighted encyclopedias or devotional sites.
- [ ] Record sources per saint; distinguish historical evidence from tradition.
- [ ] Verify date, rank, title, patronage, nationality, and spelling against authoritative Catholic sources.
- [ ] Include a last-reviewed date and reviewer.
- [ ] Do not label biographies official or exhaustive unless this is demonstrably true.

## Distribution
- [ ] Bundle third-party license texts and notices.
- [ ] Add a source manifest and checksums for imported datasets.
- [ ] Confirm every asset's licence includes offline redistribution and commercial app distribution if relevant.
- [ ] Ask qualified counsel / rights holders if terms conflict or are ambiguous.
