# Integration Plan

## Recommended app data model
1. `CalendarDay`: ISO date, season, liturgical color, primary celebration, rank, jurisdiction, source ID, review status.
2. `ReadingAssignment`: ISO date, Mass option, reading role, Scripture reference, cycle/year, source ID, review status. Keep full text out unless separately licensed.
3. `Saint`: stable ID, canonical name, feast date(s), title, biography, biography language, sources, reviewed date, reviewer.
4. `SourceRecord`: URL/title, publisher, version/commit, retrieved date, licence, attribution, jurisdiction, checksum.

## Import order
1. Import the calendar engine and license notices at a pinned revision.
2. Generate calendar records for target years.
3. Overlay verified India-specific celebrations and diocesan proper dates.
4. Import reviewed reading citations; link citations to the offline Bible database only after verifying book/verse coverage.
5. Import saints records with source references and review status.
6. Run validation and compare selected solemnities, Easter-related dates, Advent, Holy Week, and local patronal feasts against the approved Ordo.
7. Add automated tests for dates and reference resolution.
8. Build APK in GitHub Actions and verify the artifact exists; inspect the build log and app behavior before release.

## User interface safety
If local data is incomplete, display a transparent message such as “Calendar data is being verified for your region” rather than showing guessed readings as official. Provide a way to choose region/diocese when supported.
