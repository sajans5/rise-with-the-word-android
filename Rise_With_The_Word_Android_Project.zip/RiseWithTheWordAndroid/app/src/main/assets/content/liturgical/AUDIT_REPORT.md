# Audit Report — Calendar, Daily Readings & Saints

Date: 2026-10-23
Repository checked: `sajans5/rise-with-the-word-android`
Workflow file SHA returned by GitHub connector: `440a4ce6371facda2a8310dbbcf0bf2619fd06ee`
Latest known workflow run inspected: [run #64](https://github.com/sajans5/rise-with-the-word-android/actions/runs/39998133993)

## Executive status
- **Calendar content:** not yet proven complete for India. The open-source Liturgical Calendar API can calculate the General Roman Calendar and supports national/diocesan calendars, but India-specific proper celebrations must be configured and validated.
- **Daily readings:** this package provides citation/reference records only. It does not claim to contain an approved Indian lectionary or full reading texts. Official readings vary by calendar and sometimes by permitted Mass choice.
- **Saints:** this package supplies a content schema and editorial checklist, not a verified complete saints database. Feast dates, ranks, biographies, and patronage claims require source-level review.
- **Licensing:** calendar calculation code is Apache-2.0 according to the project listing. Confirm the actual repository's `LICENSE` and preserve notices in the distributed build. Reading text and Bible translation licensing is separate. Do not assume an API's MIT/Apache license automatically licenses the underlying source texts.
- **Build:** run #64 failed before Gradle build because the job tried to make a missing `project/RiseWithTheWordAndroid/gradlew` executable. The `Build debug APK` step was skipped, so that run did **not** produce an APK. Current workflow file on GitHub has since shown a Gradle CLI build step, but that updated workflow has not been shown to complete successfully in the inspected run. Do not treat this package as built or uploaded to GitHub.

## Source review
1. Liturgical Calendar API: https://github.com/Liturgical-Calendar/LiturgicalCalendarAPI
   - Project description says it generates the Roman Catholic liturgical calendar and can produce national/diocesan data.
   - The project listing identifies Apache License 2.0. Verify `LICENSE` at the exact commit you vendor.
   - This is a calendar engine, not a ready-made verified India Ordo and not a full lectionary.
2. USCCB copyright guidance: https://www.usccb.org/offices/new-american-bible/permissions and https://www.usccb.org/committees/divine-worship/policies/copyright-permissions-requirements
   - USCCB/NABRE/US Lectionary guidance is specific to those texts and jurisdictions. It is useful evidence that liturgical readings and Bible translations can be copyrighted, but it does not automatically determine Indian rights.
3. CBCI / local Indian authorities
   - Obtain or identify the applicable approved Indian calendar/Ordo and lectionary sources before claiming local correctness. Record source edition, date retrieved, jurisdiction, and review status for each import.

## Release blockers
- No authoritative India-specific calendar data file with provenance was supplied for this package.
- No complete per-date reading-reference map was supplied or verified.
- No complete saints dataset was supplied or verified.
- No license evidence for any underlying reading translation was included.
- Latest known build run did not produce an APK; a fresh successful CI run is required.
