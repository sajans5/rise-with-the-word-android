# Rise With The Word — Calendar, Daily Readings & Saints Package
Package version: 1.0.0
Prepared: 2026-10-23
Status: **integration-ready scaffold; not a verified complete content database**

## What this package is
A structured starter package for the app's Roman Rite calendar, daily Mass-reading references, and saints content. It includes data schemas, CSV templates, source/licensing notes, and a local validator. It deliberately does **not** bundle copied lectionary readings or claim a complete India-specific Ordo.

## Contents
- `AUDIT_REPORT.md` — source, completeness, licensing, and current CI status.
- `data/calendar_template.csv` — one row per date / celebration, ready for reviewed calendar data.
- `data/daily_readings_template.csv` — reading references only (not full copyrighted readings).
- `data/saints_template.csv` — saint records with provenance and review fields.
- `schemas/*.schema.json` — JSON contracts for app import.
- `data/sample_calendar_record.json`, `data/sample_readings_record.json`, `data/sample_saint_record.json` — examples only; not a complete calendar.
- `tools/validate_package.py` — validates CSVs for required fields, duplicate keys, date format, and obvious missing provenance.
- `SOURCE_AND_LICENSE_REVIEW.md` — attribution and licensing gate.
- `INTEGRATION_PLAN.md` — safe app integration steps.

## Important
This package is not a replacement for the official liturgical calendar/Ordo of the Catholic Bishops' Conference of India (CBCI), the relevant Indian regional conference/diocese, or the approved local lectionary. A universal Roman calendar API is a starting point only; India-specific proper celebrations and local observances must be reviewed.

Daily readings are represented as **references** (for example, `Luke 12: ...`) rather than copied full texts. Connect the references to the app's lawfully licensed offline Bible database, or link users to an authorized provider. A Bible and a Lectionary are not interchangeable.

## Validate
From this folder:
```bash
python tools/validate_package.py
```
The template CSVs are expected to warn about placeholder rows and missing review completion until populated with verified records.
