#!/usr/bin/env python3
"""Lightweight structural validator for RWTW CSV template files."""
import csv, re, sys
from pathlib import Path
from datetime import date

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "calendar": ("data/calendar_template.csv", ["date","calendar_id","jurisdiction","source_id","review_status"]),
    "readings": ("data/daily_readings_template.csv", ["date","calendar_id","mass_option","reading_role","source_id","review_status"]),
    "saints": ("data/saints_template.csv", ["saint_id","canonical_name","source_urls","review_status"]),
}
errors, warnings = [], []
for label, (rel, required) in FILES.items():
    with (ROOT / rel).open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            errors.append(f"{label}: missing header")
            continue
        missing = set(required) - set(reader.fieldnames)
        if missing:
            errors.append(f"{label}: missing columns: {sorted(missing)}")
            continue
        seen = set()
        for n, row in enumerate(reader, 2):
            key = row.get("date") if label != "saints" else row.get("saint_id")
            if not key or key.startswith("REPLACE") or key.endswith("-placeholder"):
                warnings.append(f"{label} row {n}: placeholder/empty key")
            if key in seen:
                errors.append(f"{label} row {n}: duplicate key {key}")
            seen.add(key)
            if label != "saints" and row.get("date"):
                try: date.fromisoformat(row["date"])
                except ValueError: errors.append(f"{label} row {n}: invalid ISO date {row['date']}")
            if row.get("review_status") not in {"needs_review","reviewed","approved","rejected"}:
                warnings.append(f"{label} row {n}: review_status missing/unknown")
            if label == "saints" and (not row.get("source_urls") or not row.get("source_urls").strip()):
                warnings.append(f"saints row {n}: source URL missing")
            if label == "readings" and not row.get("scripture_reference","").strip():
                warnings.append(f"readings row {n}: Scripture reference empty")
            if label == "calendar" and not row.get("celebration_name","").strip():
                warnings.append(f"calendar row {n}: celebration name empty")
print("RWTW package validation")
print(f"Errors: {len(errors)} | Warnings: {len(warnings)}")
for item in errors: print("ERROR:", item)
for item in warnings: print("WARNING:", item)
if errors: sys.exit(1)
print("Structural validation passed (this does NOT verify liturgical correctness, completeness, or licences).")
