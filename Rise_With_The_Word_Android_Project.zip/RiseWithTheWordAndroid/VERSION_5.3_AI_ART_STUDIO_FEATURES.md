# Version 5.3 — AI Art Studios and Visible Image Packs

## Included
- Added 10 project-owner-supplied artworks for welcome/onboarding, AI Bible Story Generator, AI Image Generator, Chibi Wallpaper Studio, Catholic Faith Q&A, Prayer Centre, Bible Study, Saints Explorer, Mass/Liturgical Calendar and Catholic AI Research.
- Added a welcome illustration to the existing setup screen.
- Added AI Bible Story Generator landing screen backed by existing story list and story detail/AI-expansion action.
- Added AI Image Generator landing screen linking to the existing native-backed wallpaper generation workflow.
- Added Catholic Faith Q&A landing screen pointing to current Catholic Guide, topic pages, Bible and search screens.
- Added the nine new feature cards in Discover and a prominent Image Packs banner both on Home and at the top of Discover.
- Added images to the offline Image Packs catalogue with descriptive alt text, dimensions, SHA-256, and owner-supplied provenance metadata.

## Important limits
- This is source/UI integration, not proof that every feature in reference mockups is already implemented. AI image generation needs the configured Gemini/native bridge and internet access. AI story expansion uses existing AI controls.
- Full authorised Malayalam 73-book Bible, official dated India Roman Rite lectionary, and complete authorised Catechism textbooks remain data-integration work.
- Internet availability does not itself grant redistribution rights. Bible translations, official textbooks, lectionary text, music, and third-party illustrations require license terms that cover the intended use. User-provided images are included for this project; retain the owner's provenance/permission record for external redistribution.

## Validation
The packaging script verifies JavaScript syntax, HTML script ordering, catalogue JSON, all image paths, file hashes, and ZIP integrity. Gradle/APK build and on-device UI/accessibility checks still need to be run by GitHub Actions and a real Android device.
