# v5.2 — Lectionary accuracy safeguard

- Removed the automatic continuous-Gospel fallback from the Daily Mass readings screen.
- If a date has no source-backed reading reference, the app now states that the official reading has not been verified instead of presenting a whole chapter as the Mass Gospel.
- Existing verified/source-attributed content packs and built-in starter references still display, with their verification status.

## Important
This is a safety/accuracy improvement, not a complete lectionary dataset. Populate each date with verified Indian Roman Rite readings and source metadata before claiming complete daily Mass readings. A personal continuous Bible plan should be a separate feature. Full official Catechism textbooks and Malayalam Bible additions still require lawful redistribution permission and validation.
