# Rise With The Word v1.7 — implementation status

## Added to supplied project
- Saint of the Day screen and searchable starter list of selected Catholic fixed-date celebrations.
- Five-year calendar view for 2027–2031 with calculated Easter, Ash Wednesday, Palm Sunday, Paschal Triduum, Ascension, Pentecost, Trinity Sunday and Corpus Christi dates, plus selected fixed-date celebrations.
- Content Sync screen with not-configured and error states, local manifest caching scaffold, and no upload of personal notes.
- New bottom navigation links for Saints, Calendar, and Sync. Existing project assets and reader screens retained.

## Not yet complete
- Saint data is a starter list, not the complete daily Roman sanctoral or local diocesan calendar.
- Liturgical calendar is a planning view, not an approved authoritative calendar; local transfer rules, local celebrations and all daily readings need verified data.
- Full Bible story library from Genesis through Revelation still needs to be authored/verified and added.
- Content sync is not live: RWTW_SYNC_URL is intentionally empty until a trusted HTTPS manifest and publisher exist. Current code checks/caches a manifest only; it does not import new content into screens.
- Account sync, cloud backup, community moderation and audio licensing are not included.
- APK build and device behaviour have not been verified by this packaging step. Run GitHub Actions and test before distribution.
