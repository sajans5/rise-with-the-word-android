# Rise With The Word v1.9 — story library expansion

## Included
- Expanded the story library from 17 to 35 concise Bible story retellings.
- Added Scripture references, summaries, story text, lesson, and short prayer for each new entry.
- Kept the v1.8 in-app story reader, search, save, and share controls.
- Replaced the unrelated lamb illustration on the homepage's Daniel card with a lion symbol.
- Made the featured Daniel and Moses cards open their corresponding story readers directly.

## Not yet complete
- These are selected story summaries, not every Bible story from Genesis through Revelation.
- Scripture references and retellings need editorial review before public release.
- Custom illustrations are not bundled for every story; symbols are used to avoid misleading imagery.
- The complete daily saint calendar, authoritative five-year liturgical calendar, live content publishing/sync, and personal cloud sync remain incomplete.
- The Android build and device behaviour for v1.9 have not been verified during packaging. Run GitHub Actions and test before distribution.
