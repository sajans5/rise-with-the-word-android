# Rise With The Word — Android project

A native Android app shell for the Rise With The Word channel. The Android app packages the existing channel-themed interface locally, so the Gospel, Bible Stories, Prayer Corner, and Home screens work without needing a website host. External YouTube, Instagram, and Facebook links open outside the app.

## Build an APK in Android Studio

1. Install Android Studio and the Android SDK Platform 35.
2. Extract this project ZIP.
3. In Android Studio, choose **Open** and select the `RiseWithTheWordAndroid` folder.
4. Allow Gradle sync to finish.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show the generated APK location. For a shareable release, use **Build → Generate Signed Bundle / APK** and create a signing key.

## Included

- `app/src/main/java/.../MainActivity.kt` — Android activity and WebView wrapper.
- `app/src/main/assets/index.html` — channel-themed app screens.
- `app/src/main/assets/manifest.json` and `sw.js` — reused starter assets.
- Android launcher icon, app theme, and Gradle configuration.

## Important

This ZIP is the Android Studio source project, not a precompiled APK. An Android SDK and Gradle build environment are required to produce the installable `.apk` file. The app uses the existing interface and current sample Gospel reflection; it does not yet fetch live YouTube uploads or automatically update daily liturgical readings.
