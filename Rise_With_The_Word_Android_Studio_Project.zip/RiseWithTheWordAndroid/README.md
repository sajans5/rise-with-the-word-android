# Rise With The Word — version 2.0.0

A self-contained Catholic Bible and prayer app. Everything runs inside the app (no browser, no other app needed).
The only optional network use is **Content Sync** (updates from your own GitHub page).

## How to build it from your phone (3 steps)
1. In your GitHub repository, upload **Rise_With_The_Word_Android_Studio_Project.zip** (this ZIP, same name, replace the old one) and the new **android-apk.yml** into `.github/workflows/` (replace the old file).
2. GitHub app → your repo → **Actions** → *Build Rise With The Word APK* → **Run workflow**.
3. When it turns green, open the run → **Artifacts** → download *Rise-With-The-Word-debug-APK* → install.
If the run turns red, open it, tap the red step, and send me the last 30 lines of the log.

## What is inside (all work offline)
| Area | What you get |
|---|---|
| Bible | Complete 73-book Douay–Rheims (public domain), search by word or reference (e.g. *John 3:16*), bookmarks, 4-colour highlights, private notes, text size, plans (30-day Gospel journey, John, Luke, Matthew, Acts, Psalms, starter week) |
| Daily Gospel | Today / previous / next day, liturgical colour, season, Year A/B/C and I/II |
| Liturgical calendar | Roman Rite 2026–2031 computed on the phone (Easter, Lent, Holy Week, Pentecost, Advent, movable feasts, transfers, colours). Tested against known Easter dates 2026–2031 |
| Saints | 220+ General Roman Calendar and Indian/Kerala saints, by date and by name |
| Stories | 110 Bible stories (Genesis → Revelation): summary, lesson, prayer, and a button that opens the full passage from the Bible |
| Prayer | Rosary (all 4 sets, guided), Divine Mercy Chaplet, traditional prayers, Loreto/St Joseph/Humility litanies, 5 novenas, Stations of the Cross, morning/evening/sleep routines, prayer timer with Lectio Divina |
| Personal | Streaks and weekly goal (optional), journal with export, private intentions, favourites, recents, reminders, local backup & restore |
| Discover | 45-question quiz, trivia, kids & family, seasonal challenges (Advent, Lent, Easter, Mary), search across everything |
| Sharing | Scripture cards/wallpapers (save or share), share text, family/prayer-group plans (local), parish card |
| Languages | English and Malayalam interface |

## Honest status — please read
* **I could not run the Android build or test on a phone.** The web screens and calendar were tested in a desktop browser; the Kotlin code was reviewed but not compiled. If the first build fails, send me the log and I will fix it.
* **Daily readings:** the app has the Sunday and solemnity **Gospel** references built in (Years A/B/C) plus full readings for Christmas, Epiphany, Easter, Pentecost, Holy Thursday, Good Friday, Ash Wednesday and a few solemnities. For other weekdays it shows a clearly-labelled *continuous Gospel plan* — **not** the Mass lectionary. Full readings for every day come from the `readings` pack (below). I did not invent readings. Verify the built-in table against your lectionary.
* **Saints & calendar** are starter data from the General Roman Calendar plus a few Kerala saints. Check against your diocesan ordo. Epiphany, Ascension and Corpus Christi dates differ by country — set them in *Me → Settings*.
* **Syro-Malabar / Syro-Malankara calendars are not included** (they must not be mixed with the Roman calendar). They need an authoritative source and can be added later as their own calendar.
* **Malayalam:** the interface and the main prayers (Sign of the Cross, Our Father, Hail Mary, Glory Be) are Malayalam; story/saint text is English until you add Malayalam via Content Sync (`title_ml`, `summary_ml`, …). **Have a native speaker or your parish priest review all Malayalam text before publishing.**
* **Not included because they need a server you would have to run and moderate:** user accounts and multi-device sync, a moderated community prayer wall, parish/diocese directory pages, QR/invitation links, reports and moderation tools. Instead the app offers a **local backup file** (move it between phones) and **share-text invitations**. Tell me if you want to add a server (e.g. Firebase) later.
* **Audio/music:** no copyrighted audio is bundled. The prayer timer uses a soft built-in chime. Licensed music can be added to the project later.
* This is a **debug APK** for testing. For the Play Store you will need a signed release build.

## Automatic content updates (stories, saints, readings, corrections)
1. Create a new public GitHub repo, upload the files from `content-feed-template/` (see its README.txt), turn on **Pages**.
2. In the app: **Me → Settings → Content feed** → paste `https://YOUR-USERNAME.github.io/REPO/manifest.json`.
3. To publish a change: edit a pack file and raise its `version` in `manifest.json`. The app checks when opened (at most every 12 h), downloads new packs, keeps them offline, and shows the last-sync time (**Me → Content Sync**).
Only https is accepted; packs are plain data (never code), size-limited, and may carry a SHA-256 checksum.

## Bible text licence
Original Douay–Rheims (public domain). Data from github.com/janvier-s/original-douay-rheims (CC0), pinned to commit `cd4439a1b5bbf2abe253d68b0896c3c60e8f27bc`. Psalms use Vulgate numbering; the app converts modern (lectionary) Psalm numbers automatically and shows the whole psalm.
Do not paste copyrighted lectionary or modern-translation text into packs unless you hold the licence.

## Folder map
`app/src/main/assets/` = the app (index.html, css/, js/). `js/saints.js` saints · `js/liturgy.js` calendar engine · `js/readings.js` readings · `js/stories.js` stories · `js/prayers.js` prayers · `js/learn.js` quiz/trivia/challenges.
`app/src/main/java/.../` = MainActivity (host + bridge), ContentSync, Reminders.


## v2.4 content and visual direction
See `FEATURE_STATUS_v2.4.md` and `app/src/main/assets/content/CONTENT_PACK_README.md`.
