# Rise With The Word Android App — Version 1.5.0

A free Android app package for Rise With The Word. The UI and a starter set of 80 Scripture passages are stored as local assets. The APK build adds the complete 73-book Catholic-canon Original Douay–Rheims text, including the Catholic deuterocanonical books, so the Bible reader and full-text search work offline after installation.

## What's new
- Full offline reader for all 73 books of the Catholic canon, chapters and verses.
- Complete Bible search by word, phrase, book, chapter or verse reference. Search is debounced and capped at 40 displayed matches for a more responsive interface.
- Increase/decrease Scripture reading text size; navigate previous/next chapters.
- Save/share individual Bible verses to Android's share sheet and the local Saved list.
- Offline daily verse that rotates from a bundled 80-passage curated collection, with optional free online refresh when connectivity is available.
- Seven-day reading plan with locally saved progress.
- Selected lookup passages are tagged by theme and include Catholic deuterocanonical readings.
- No paid APIs, subscriptions, accounts, location, contacts, camera or microphone permissions.

## Scripture source and license
The full text is the Original Douay–Rheims Bible (1582 New Testament / 1609–1610 Old Testament). The source repository identifies its text/data as CC0 1.0 Universal/public domain: https://github.com/janvier-s/original-douay-rheims. The build pins the source commit `cd4439a1b5bbf2abe253d68b0896c3c60e8f27bc` for reproducibility. The builder includes the 73 Catholic-canon books and excludes the source's three appendix books (3 Esdras, 4 Esdras and the Prayer of Manasses). The source uses historic Douay–Rheims spellings and Vulgate-oriented book/Psalm numbering, with explanatory modern aliases in the reader.

## Important: use the matching GitHub Actions workflow
The project ZIP deliberately does not store the large full-Bible dataset. The workflow downloads the pinned CC0 dataset at build time, converts it to a compact app asset using `tools/build_bible.py`, and then builds the APK. This means the installed APK has the full Bible offline, although the first GitHub build needs internet access. Use the companion `android-apk.yml` workflow provided with this release. The ZIP's top-level project folder is `RiseWithTheWordAndroid`.

## Offline / online behaviour
The home page, daily offline verse collection, full Bible reader, search, saved items and reading plan are local assets and run without internet. Online refresh of the daily verse, current Catholic liturgical readings, and social/channel links require a connection. The external daily-verse provider is optional; failure leaves the offline verse visible.
