# Rise With The Word — version 2.3.0

A self-contained Catholic Bible and prayer app. Everything runs inside the app (no browser, no other app needed).
Optional network features are **Content Sync** (your GitHub content feed) and **AI expansion** (your configured AI service). Bible reading, prayers, saved expansions and core content work offline.

## How to build it from your phone (3 steps)
1. In your GitHub repository, upload **Rise_With_The_Word_Android_Studio_Project.zip** (this ZIP, same name, replace the old one) and the new **android-apk.yml** into `.github/workflows/` (replace the old file).
2. GitHub app → your repo → **Actions** → *Build Rise With The Word APK* → **Run workflow**.
3. When it turns green, open the run → **Artifacts** → download *Rise-With-The-Word-debug-APK* → install.
If the run turns red, open it, tap the red step, and send me the last 30 lines of the log.

## What is inside (all work offline)
| Area | What you get |
|---|---|
| Bible | Complete 73-book Douay–Rheims (public domain), search by word or reference (e.g. *John 3:16*), bookmarks, 4-colour highlights, private notes, text size, plans (30-day Gospel journey, John, Luke, Matthew, Acts, Psalms, starter week) |
| Daily Gospel | Today / previous / next day, liturgical colour, season, Year A/B/C and I/II |
| Liturgical calendar | Roman Rite 2026–2031 computed on the phone (Easter, Lent, Holy Week, Pentecost, Advent, movable feasts, transfers, colours). Tested against known Easter dates 2026–2031 |
| Saints | 220+ General Roman Calendar and Indian/Kerala saints, by date and by name |
| Stories | 110 Bible stories (Genesis → Revelation): summary, lesson, prayer, and a button that opens the full passage from the Bible |
| Prayer | Rosary (all 4 sets, guided), Divine Mercy Chaplet, traditional prayers, Loreto/St Joseph/Humility litanies, 5 novenas, Stations of the Cross, morning/evening/sleep routines, prayer timer with Lectio Divina |
| Personal | Streaks and weekly goal (optional), journal with export, private intentions, favourites, recents, reminders, local backup & restore |
| Discover | 45-question quiz, trivia, kids & family, seasonal challenges (Advent, Lent, Easter, Mary), search across everything |
| Sharing | Scripture cards/wallpapers (save or share), share text, family/prayer-group plans (local), parish card |
| Languages | English and Malayalam interface |

## Honest status — please read
* **I could not run the Android build or test on a phone.** The web screens and calendar were tested in a desktop browser; the Kotlin code was reviewed but not compiled. If the first build fails, send me the log and I will fix it.
* **Daily readings:** the app has the Sunday and solemnity **Gospel** references built in (Years A/B/C) plus full readings for Christmas, Epiphany, Easter, Pentecost, Holy Thursday, Good Friday, Ash Wednesday and a few solemnities. For other weekdays it shows a clearly-labelled *continuous Gospel plan* — **not** the Mass lectionary. Full readings for every day come from the `readings` pack (below). I did not invent readings. Verify the built-in table against your lectionary.
* **Saints & calendar** are starter data from the General Roman Calendar plus a few Kerala saints. Check against your diocesan ordo. Epiphany, Ascension and Corpus Christi dates differ by country — set them in *Me → Settings*.
* **Syro-Malabar / Syro-Malankara calendars are not included** (they must not be mixed with the Roman calendar). They need an authoritative source and can be added later as their own calendar.
* **Malayalam:** the interface and the main prayers (Sign of the Cross, Our Father, Hail Mary, Glory Be) are Malayalam; story/saint text is English until you add Malayalam via Content Sync (`title_ml`, `summary_ml`, …). **Have a native speaker or your parish priest review all Malayalam text before publishing.**
* **Not included because they need a server you would have to run and moderate:** user accounts and multi-device sync, a moderated community prayer wall, parish/diocese directory pages, QR/invitation links, reports and moderation tools. Instead the app offers a **local backup file** (move it between phones) and **share-text invitations**. Tell me if you want to add a server (e.g. Firebase) later.
* **Audio/music:** no copyrighted audio is bundled. The prayer timer uses a soft built-in chime. Licensed music can be added to the project later.
* This is a **debug APK** for testing. For the Play Store you will need a signed release build.

## Automatic content updates (stories, saints, readings, corrections)
1. Create a new public GitHub repo, upload the files from `content-feed-template/` (see its README.txt), turn on **Pages**.
2. In the app: **Me → Settings → Content feed** → paste `https://YOUR-USERNAME.github.io/REPO/manifest.json`.
3. To publish a change: edit a pack file and raise its `version` in `manifest.json`. The app checks when opened (at most every 12 h), downloads new packs, keeps them offline, and shows the last-sync time (**Me → Content Sync**).
Only https is accepted; packs are plain data (never code), size-limited, and may carry a SHA-256 checksum.

## Bible text licence
Original Douay–Rheims (public domain). Data from github.com/janvier-s/original-douay-rheims (CC0), pinned to commit `cd4439a1b5bbf2abe253d68b0896c3c60e8f27bc`. Psalms use Vulgate numbering; the app converts modern (lectionary) Psalm numbers automatically and shows the whole psalm.
Do not paste copyrighted lectionary or modern-translation text into packs unless you hold the licence.

## Folder map
`app/src/main/assets/` = the app (index.html, css/, js/). `js/saints.js` saints · `js/liturgy.js` calendar engine · `js/readings.js` readings · `js/stories.js` stories · `js/prayers.js` prayers · `js/learn.js` quiz/trivia/challenges.
`app/src/main/java/.../` = MainActivity (host + bridge), ContentSync, Reminders.


## New in 2.1
* **Learn the Faith** (27 topics from the Catechism and Canon Law), **Glossary** (45 terms), **Confession guide** and **Examination of conscience** (nothing is saved), **Help in Need** (14 situations with Scripture and a prayer), **Scripture by Topic** (18 topics), **Biblical & Church Timeline**, introductions to all 73 Bible books, chapter "read" tracking, a **Coming up** card on Home (computed from the calendar) and fasting/abstinence notes on Ash Wednesday, Good Friday and Fridays of Lent. Items that vary by country are marked "varies".
* **Feed address fix:** if you paste a website or folder address, the app adds `/manifest.json` for you, and shows a clear message if the address returns a web page.

## AI improvements in 2.3
* The AI expansion screen can use the Rise With The Word Cloudflare Worker, using Google Gemini only. The Gemini API key stays in Cloudflare and is not embedded in the APK.
* The app sends the selected story/saint/liturgical context to `/story`, displays returned sources, and stores completed expansions locally for offline reading. A separate direct-Gemini mode also exists for users who explicitly configure a key in the app; the recommended Worker mode keeps the key on Cloudflare.
* Settings includes the Worker endpoint and a lightweight health check that does not consume generation tokens.
* `cloudflare-worker/worker.js` is the matching server implementation. It accepts the app's contextual request fields (`topic`, `context`, `instructions`, `language`, `wordCount`), enforces the `AI_RATE_LIMIT` binding, and calls Google Gemini only.
* Before using the updated app, deploy the bundled Worker code to your Cloudflare Worker. Keep `GEMINI_API_KEY` as a Cloudflare secret and keep `AI_RATE_LIMIT` configured to 5 requests per 60 seconds. The limiter is a protective throttle, not a strict global spending cap; API provider quotas and billing still apply.

## Hidden AI Assistant (Google Gemini)
Unlock: **Me → Privacy → tap the version line 7 times**, then **Me → Settings → AI Assistant**: paste your own **Google AI Studio API key** (starts with `AIza`; create it at aistudio.google.com), keep the model `gemini-2.5-flash` (or change it), choose a daily limit.
An **Expand with AI** card then appears on every story, saint and calendar day. Choose Concise (~700), Detailed (~1,500) or Full chapter (~3,500 words). Gemini writes in the background using **Google Search grounding**, the result is saved in the built-in database for offline reading (Me → Settings → My expanded content), and you get a notification if the app is in the background.
* The key is kept only by the Android code, excluded from backups, and sent only to generativelanguage.googleapis.com. **Never put a key in the project or the content feed.** Legacy AI-provider credentials from older versions are cleared on first launch.
* Free-tier keys have rate limits and daily quotas; if you see a quota message, wait or use a paid plan.
* If a model rejects Google Search or the "thinking" setting, the app automatically retries without it and tells you.
* Calendar facts and the Douay–Rheims text are given to Gemini as authoritative; it is told never to invent quotes or miracles and to label tradition and legend. **It is still AI: read before you publish or teach.**

## Built-in database and automatic updates (new in 2.2)
* The app now has a private **SQLite database** on the phone. It stores downloaded content packs (with versions), the log of updates, and your saved AI expansions, all readable offline. Me → Content Sync shows what is inside.
* **Automatic updates:** after you set the content feed address, Android checks about every 12 hours **in the background, even when the app is closed** (only when online), and also when you open the app. New stories, saints, readings, calendar corrections, quiz questions and trivia go straight into the database. Android may delay background checks to save battery.
* Content you already downloaded with version 2.0/2.1 is moved into the database automatically.
