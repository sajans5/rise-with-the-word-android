# Rise With The Word Android App — Version 1.3.0

A free Android project for Rise With The Word, with colorful inspirational Bible illustrations, navy/purple/gold branding, online daily verse retrieval, Catholic reading links, story search, saved reflections, sharing, and optional local prayer reminders.

## Included artwork and resources
- Six illustration assets: Jesus teaching, child with Bible, prayer, lamb near a cross, sunset path, and open Bible.
- Wide banners for the home hero, prayer section, and hope imagery.
- Category icons for Gospel, Bible stories, prayer, YouTube, daily verse, and saints.
- App icon artwork and Android launcher icon PNGs at multiple densities.
- Updated HTML interface with illustrations and icons integrated.

## Build
Upload this ZIP to the existing private GitHub repository as `Rise_With_The_Word_Android_Studio_Project.zip`, replacing the previous project ZIP, then run the existing GitHub Actions workflow. Keep the `Fix Java compatibility` step. The workflow uploads the debug APK artifact.

## Online and privacy notes
The app requests internet access to retrieve a daily verse from a free online service and to open Catholic readings and channel pages. Saved items remain local. No camera, microphone, contacts, or location access is requested. Online services can be unavailable; the UI includes refresh and failure messaging.
