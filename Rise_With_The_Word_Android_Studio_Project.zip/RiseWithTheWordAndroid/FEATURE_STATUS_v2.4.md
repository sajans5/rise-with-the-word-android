# Rise With The Word v2.4 — content and visual direction

## Included
- Added a reusable editorial content pack with home copy, daily Gospel layout, ten reflections, four prayer cards, and editorial guidelines.
- Improved the Bible Stories introduction with a warmer, clearer editorial promise.
- Improved story-reader typography and section hierarchy for the summary, lesson, and prayer.
- Added a generated promotional UI design reference under `design-reference/`.

## Not yet complete
- The JSON content pack is not wired into the app screens automatically; the new stories landing copy and reader hierarchy are active, while reflections/prayer cards are supplied as reusable source content.
- The visual reference is a concept mockup, not a live-app screenshot and not a set of individual story illustrations.
- Stories remain concise retellings; this update does not satisfy the requested 3,500-word chapter length for every story.
- No APK has been compiled or tested in this packaging step.
