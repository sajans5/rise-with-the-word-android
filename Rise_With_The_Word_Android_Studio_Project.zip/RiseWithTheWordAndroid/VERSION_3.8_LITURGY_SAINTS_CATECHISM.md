# Version 3.8 — Liturgy, Saints & Catechism Expansion

## Calendar reading references
The calendar's highlighted date list now shows the available first reading, responsorial psalm, second reading, Gospel acclamation, and Gospel references for each exact YYYY-MM-DD date when those fields exist in the current offline reading engine or a dated content pack. A reading-plan fallback is explicitly labelled as not being the official Mass lectionary. Built-in references are not marked verified unless a downloaded pack has both `verified: true` and a source name.

## Important liturgical accuracy note
The calendar engine computes the General Roman Rite and has regional options. It is not a substitute for the approved India/diocesan Ordo. The present built-in reading table is partial and must not be represented as a complete, authoritative daily lectionary. The correct next data step is to add date-keyed reading references verified against the applicable Indian/diocesan Ordo, with local transfers and solemnities checked. Calendar calculation APIs can help calculate dates and precedence, but calendar calculations alone do not provide a complete licensed lectionary text.

## Saints
Added 30 original saint summaries with Scripture references, virtues, and source notes. These are labelled as informational saint profiles rather than inserted as General Roman Calendar memorials, so they do not silently change liturgical precedence. Local feast observance and ranks should be verified against the relevant Ordo.

## Catechism
Added 24 original supplementary topics covering the Trinity, Christ, sacraments, prayer, moral life, social teaching, liturgical year, Mary and saints, Scripture and Tradition, digital ethics, vocation, mission, and more. Topics are searchable and open offline. These are not official KRLCBC textbook chapters and do not reproduce copyrighted textbooks.

## Validation
JavaScript syntax checks, data parsing, and ZIP integrity checks are performed for this source package. Android Gradle build/device testing remains separate and must still be completed.
