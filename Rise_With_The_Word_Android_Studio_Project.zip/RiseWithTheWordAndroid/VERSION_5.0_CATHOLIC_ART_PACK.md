# Version 5.0 — Catholic artwork and usability upgrade

## Added in this update
- Bundled all ten artworks supplied for Rise With The Word: brand logo, Catholic faith guide, Saint of the Day, Bible Library, Daily Gospel, Prayer Centre, Sacraments, Catechism & Faith Guide, Liturgical Calendar, and Saints/Feast Calendar.
- Added image catalogue metadata: category, title, descriptive alt text, supplied source note, reuse caution, dimensions, SHA-256 and offline status.
- Updated the Image Packs screen with 13 category filters and full portrait poster previews to avoid cropping text embedded in artwork.
- Added a six-image featured art strip on Home and expanded the Discover feature gallery.
- Set the supplied logo as the app icon source and refreshed launcher icon PNGs.
- Version name 5.0.0 / version code 34.
- Retained the English Bible startup script include so GitHub Actions' generated `bible-full-data.js` loads before `bible.js`.

## Automated checks completed
- JavaScript syntax checks (all app JS files).
- Image catalogue JSON parses.
- All catalogue asset paths resolve to files in the project.
- SHA-256 values and image dimensions recalculated.
- ZIP integrity check completed after packaging.

## Still incomplete / needs verification
- The seven deuterocanonical books in the Malayalam catalogue still need full licensed Malayalam text.
- Official Roman Rite India lectionary readings need source-backed completeness and device validation. The app should not label a continuous Bible plan as the official Mass lectionary.
- Run GitHub Actions and install the resulting APK for TalkBack, Malayalam typography, large text, offline asset and navigation tests.
- Confirm ownership/reuse permission for the supplied images before distributing publicly or commercially.
