# AI Story Studio backend

This Cloudflare Worker is a secure middle layer between the app and the OpenAI Responses API. It enables web search and returns a researched story plus source links.

## Setup
1. Create a Cloudflare Worker and paste `index.js`, then deploy.
2. Add a Worker secret named `OPENAI_API_KEY`. Never put the key in the app or a repository.
3. Optionally set Worker variable `OPENAI_MODEL`; default is `gpt-5.5`.
4. Configure the deployed HTTPS Worker URL in Rise With The Word → Me → Settings → AI Story Studio.
5. The app sends `POST {worker-url}/story` with `{ "topic":"Joseph forgives his brothers", "language":"English", "wordCount":3500 }`.

## Safety and cost
OpenAI API usage is separate from a ChatGPT subscription and may cost money. A parent/guardian should manage API account setup, billing, usage limits and the secret. This starter has no authentication or rate limiting; do not expose it for unrestricted public use without adding both. Set usage limits and monitor usage.

## Editorial
The output is an original retelling, not Scripture text. Review source links, Scripture references, Catholic context and historical claims before publishing.
