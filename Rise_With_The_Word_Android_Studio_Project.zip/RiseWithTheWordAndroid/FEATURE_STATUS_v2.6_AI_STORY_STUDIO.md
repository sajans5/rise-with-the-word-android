# v2.6 — AI Story Studio integration scaffold

## Added
- Discover tile and dedicated AI Story Studio screen.
- Topic, language, and story length selectors up to 3,500 words.
- Configurable HTTPS endpoint, generated story display, source links, word count, and local save/delete.
- Cloudflare Worker example using the OpenAI Responses API with required web search.
- Content Security Policy permits HTTPS requests.

## Not live yet
- Worker is not deployed and no API key is included. Deploy it and set the secret before generating stories.
- API use may incur charges; have a parent/guardian manage account and billing.
- Starter Worker has no authentication/rate limiting; add protections before unrestricted public use.
- APK has not been compiled or tested in this packaging step.
