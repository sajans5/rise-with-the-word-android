# Version 3.9 — India Ordo Reading Import & Audit

## Added
- A date-keyed JSON template for the CCBI 2026–2027 Ordo cycle (29 Nov 2026–27 Nov 2027).
- `tools/audit_lectionary_pack.py`, checking date keys, required metadata, per-date source traceability, missing dates, and reading-reference field types.
- An explicit workflow for preparing and auditing a reference pack before bundling it offline.

## Why the template has no readings yet
The CCBI has announced the 2026–2027 Ordo on its official website. The date-by-date references have not yet been transcribed and checked for this project, so this template intentionally contains `dates: {}` rather than invented readings. It will report 0/364 dates until records are populated.

## Record format
Each `dates[YYYY-MM-DD]` entry may include `celebration`, `rank`, `color`, `first`, `psalm`, `second`, `gospelAcclamation`, `gospel`, and (where applicable) `alternatives` or `massOptions`. Mark `verified: true` only after checking the applicable approved Ordo, and provide source name, URL, and page/section note. References are not the same as reproducing the full lectionary text.

A `verified` flag is a human review assertion, not independent proof. A diocesan calendar can transfer or rank celebrations differently; check the relevant local Ordo before treating a pack as authoritative for a particular diocese.

## Run audit
```bash
python tools/audit_lectionary_pack.py content-feed-template/readings-india-2026-2027.json --start 2026-11-29 --end 2027-11-27
```

## Official source
CCBI, “Liturgical Calendar (ORDO) for the year 2026–2027”: https://www.ccbi.in/post/liturgical-calendar-ordo-for-the-year-2026-2027

## Limitations
This update does not add complete official readings or the lectionary text. It has not been Android Gradle/device tested. Continue showing the app's existing “not verified” labels until entries are manually checked.
