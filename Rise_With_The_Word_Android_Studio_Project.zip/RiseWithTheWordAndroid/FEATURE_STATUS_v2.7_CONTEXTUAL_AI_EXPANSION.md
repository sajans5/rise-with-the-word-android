# v2.7 — Contextual AI Expansion

## Added
- Bible story screen: “Expand full story with AI” button.
- Saint cards: “Discover the full saint biography” button.
- Daily liturgy / readings screen: “Explore this day’s liturgy with AI” button.
- Contextual requests use the configured HTTPS backend `/expand` endpoint; no separate chatbot screen is opened.
- Responses appear inline below the button, include source links when returned, and are cached locally for reopening/offline reading.
- The existing `/story` endpoint and AI Story Studio remain available.
- Prompts distinguish Scripture, historical evidence, Catholic teaching, tradition, and interpretation; liturgy output warns that commentary is not an official Ordo.

## Setup and limitations
- Requires a deployed AI backend and a valid server-side `OPENAI_API_KEY` secret.
- API usage may incur charges. A parent/guardian should manage any account and billing.
- The included Cloudflare Worker still uses permissive CORS and has no authentication or rate limiting. Do not expose it publicly in production until abuse protection is added.
- JavaScript syntax checks and ZIP integrity checks passed. An Android APK build and live API call were not run in this environment.
