# Version 3.4 — Offline saint profile integration

- Integrated the extended saint dataset into the app's liturgical saint registry, so new profiles can appear in the existing All Saints list, saint search, and saint detail pages without a network connection.
- Existing saints are de-duplicated by feast month/day and normalized name where the names match exactly.
- Extended records include editorial biographies, Scripture references, virtues, and a note to verify local observance against the applicable diocesan Ordo.
- Fixed catechism completion toggle to replace the current detail route rather than calling the tab-only root navigation method.

Content caveats: the added saint dataset is editorial material, not an official liturgical calendar. Local memorials and feast dates must be checked against the current diocesan Ordo. This upgrade does not add official lectionary readings or copyrighted catechism textbook chapters.

Validation: JavaScript syntax and JSON parsing checks are run during packaging; this is not a substitute for an Android Gradle build or device testing.
- Removed a stale script reference to `bible-full-data.js`, which is not present in this project package. The Bible layer already handles the full-text dataset being unavailable; this avoids a needless missing-file request. It does not add missing Bible translations.
