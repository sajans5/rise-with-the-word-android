package com.risewiththeword.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to Google Gemini (generativelanguage.googleapis.com) so the app can write long, researched expansions
 * with Google Search grounding.
 * - The API key is kept only here, in private app storage. The web page can set it but never read it.
 * - Requests go only to https://generativelanguage.googleapis.com.
 */
object GeminiClient {
    private const val PREFS = "rwtw_gemini"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun setKey(ctx: Context, key: String) { prefs(ctx).edit().putString("key", key.trim()).apply() }
    fun hasKey(ctx: Context) = !prefs(ctx).getString("key", "").isNullOrEmpty()
    fun setModel(ctx: Context, m: String) { prefs(ctx).edit().putString("model", m.trim()).apply() }
    private fun model(ctx: Context) = prefs(ctx).getString("model", null)?.takeIf { it.isNotBlank() && !it.startsWith("gpt") } ?: "gemini-2.5-flash"

    private fun post(key: String, model: String, body: String): Pair<Int, String> {
        val c = (URL(BASE + model + ":generateContent").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 20000; readTimeout = 280000
            setRequestProperty("x-goog-api-key", key)
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            return Pair(code, stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "")
        } finally { c.disconnect() }
    }

    private fun errorMessage(code: Int, text: String): String {
        val m = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
        return when (code) {
            400 -> m ?: "The request was rejected (400)."
            401, 403 -> "Google rejected the API key or this model is not allowed for it. ${m ?: ""}".trim()
            429 -> "Gemini quota or rate limit reached. Wait a little or check your Google AI Studio plan."
            else -> m ?: "HTTP $code"
        }
    }

    /** Returns JSON: {job, ok, text, sources[], searched, model, incomplete} or {job, ok:false, error}. */
    fun generate(ctx: Context, job: String, instructions: String, input: String, maxTokens: Int, search: Boolean): String {
        val res = JSONObject().put("job", job)
        val key = prefs(ctx).getString("key", "") ?: ""
        if (key.isEmpty()) return res.put("ok", false).put("error", "No API key saved").toString()
        val model = model(ctx)
        // Some models reject Google Search or the thinking setting: step down one feature at a time.
        val attempts = if (search) listOf(Pair(true, true), Pair(true, false), Pair(false, true), Pair(false, false)) else listOf(Pair(false, true), Pair(false, false))
        var lastErr = ""
        try {
            for ((useSearch, useThinking) in attempts) {
                val gen = JSONObject().put("maxOutputTokens", maxTokens.coerceIn(20, 32000)).put("temperature", 0.7)
                if (useThinking) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 1024))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instructions))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", input)))))
                    .put("generationConfig", gen)
                if (useSearch) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
                val (code, text) = post(key, model, body.toString())
                if (code in 200..299) return parse(res, text, model, useSearch)
                lastErr = errorMessage(code, text)
                if (code != 400) return res.put("ok", false).put("error", lastErr).toString()
            }
        } catch (e: Exception) {
            return res.put("ok", false).put("error", e.message ?: "Network error").toString()
        }
        return res.put("ok", false).put("error", lastErr).toString()
    }

    private fun parse(res: JSONObject, text: String, model: String, searched: Boolean): String {
        val o = JSONObject(text)
        val cands = o.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val block = o.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
            return res.put("ok", false).put("error", "Gemini returned no answer" + (if (block.isNotEmpty()) " (blocked: $block)." else ".")).toString()
        }
        val cand = cands.getJSONObject(0)
        val sb = StringBuilder()
        val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.optBoolean("thought", false)) continue
            sb.append(p.optString("text"))
        }
        val sources = JSONArray(); val seen = HashSet<String>()
        val chunks = cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        if (chunks != null) for (i in 0 until chunks.length()) {
            val w = chunks.getJSONObject(i).optJSONObject("web") ?: continue
            val uri = w.optString("uri")
            if (uri.startsWith("https://") && seen.add(uri)) sources.put(JSONObject().put("title", w.optString("title")).put("url", uri))
        }
        val out = sb.toString().trim()
        val finish = cand.optString("finishReason")
        if (out.isEmpty()) return res.put("ok", false).put("error", "No text returned" + (if (finish.isNotEmpty()) " ($finish). Try a shorter length or another model." else ".")).toString()
        return res.put("ok", true).put("text", out).put("sources", sources).put("searched", searched).put("model", model)
            .put("incomplete", finish == "MAX_TOKENS").toString()
    }
}
