package com.risewiththeword.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * In-app viewer for YOUR social pages and videos, so nothing opens in an outside browser.
 * Only the websites of YouTube, Facebook and Instagram are allowed; every other link is blocked.
 * Extras: "url" (page to open), "video" (11-character YouTube video id), "title".
 * Note: Google/Facebook/Instagram may refuse to show their sign-in pages inside a WebView.
 */
class WebViewerActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: LinearLayout
    private lateinit var holder: FrameLayout
    private var trusted = false
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    companion object {
        private val hosts = listOf(
            "youtube.com", "youtu.be", "youtube-nocookie.com", "ytimg.com", "googlevideo.com", "gstatic.com", "google.com", "googleapis.com",
            "facebook.com", "fb.com", "fbcdn.net", "instagram.com", "cdninstagram.com"
        )
        private val trustedHosts = listOf(
            "vatican.va", "vaticannews.va", "usccb.org", "newadvent.org", "ewtn.com", "catholic.com", "cbci.in",
            "catholicculture.org", "franciscanmedia.org", "aleteia.org", "wikipedia.org", "wikimedia.org"
        )
        fun allowedTrusted(url: String): Boolean {
            val u = try { Uri.parse(url) } catch (_: Exception) { return false }
            if (u.scheme != "https") return false
            val h = u.host?.lowercase() ?: return false
            return trustedHosts.any { h == it || h.endsWith(".$it") }
        }
        fun allowed(url: String): Boolean {
            val u = try { Uri.parse(url) } catch (_: Exception) { return false }
            if (u.scheme != "https") return false
            val h = u.host?.lowercase() ?: return false
            return hosts.any { h == it || h.endsWith(".$it") }
        }
        val videoId = Regex("^[A-Za-z0-9_-]{11}$")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = intent.getStringExtra("title") ?: "Rise With The Word"
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.rgb(23, 20, 44)); setPadding(12, 8, 12, 8)
        }
        val close = Button(this).apply { text = "\u2715  Close"; setOnClickListener { finish() } }
        val label = TextView(this).apply { text = title; setTextColor(Color.rgb(255, 212, 106)); textSize = 16f; setPadding(20, 0, 0, 0); maxLines = 1 }
        bar.addView(close); bar.addView(label)
        holder = FrameLayout(this)
        web = WebView(this)
        holder.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(23, 20, 44)) }
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(holder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom); insets
        }
        setContentView(root)

        with(web.settings) {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = false; allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = false
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return true
                if (allowed(url) || (trusted && allowedTrusted(url))) return false
                Toast.makeText(this@WebViewerActivity, "That link is outside the app and was blocked.", Toast.LENGTH_SHORT).show()
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                customView = view; customCallback = callback
                bar.visibility = View.GONE; web.visibility = View.GONE
                holder.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            override fun onHideCustomView() { leaveFullscreen(bar) }
        }
        trusted = intent.getBooleanExtra("trusted", false)
        val vid = intent.getStringExtra("video")
        val url = intent.getStringExtra("url")
        if (vid != null && videoId.matches(vid)) {
            val html = "<html><body style='margin:0;background:#000'><iframe style='position:absolute;inset:0;width:100%;height:100%;border:0' " +
                "src='https://www.youtube.com/embed/$vid?autoplay=1&playsinline=1&rel=0' " +
                "allow='autoplay; fullscreen; encrypted-media; picture-in-picture' allowfullscreen></iframe></body></html>"
            web.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
        } else if (url != null && (allowed(url) || (trusted && allowedTrusted(url)))) {
            web.loadUrl(url)
        } else { Toast.makeText(this, "This address cannot be opened here.", Toast.LENGTH_LONG).show(); finish() }
    }

    private fun leaveFullscreen(bar: View) {
        customView?.let { holder.removeView(it) }
        customView = null; customCallback?.onCustomViewHidden(); customCallback = null
        bar.visibility = View.VISIBLE; web.visibility = View.VISIBLE
    }

    @Deprecated("Deprecated Android callback retained for compatibility")
    override fun onBackPressed() {
        if (customView != null) { customCallback?.onCustomViewHidden(); return }
        if (web.canGoBack()) web.goBack() else finish()
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
