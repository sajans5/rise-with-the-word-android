package com.risewiththeword.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Calls the Rise With The Word Cloudflare Worker. Provider keys stay on the server,
 * not in the APK. The app sends only the selected devotional topic and its source context.
 */
object WorkerClient {
    private const val PREFS = "rwtw_worker"
    const val DEFAULT_ENDPOINT = "https://rise-word-ai.sajanscrypto.workers.dev/story"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun endpoint(ctx: Context): String =
        prefs(ctx).getString("endpoint", DEFAULT_ENDPOINT)?.trim().orEmpty().ifBlank { DEFAULT_ENDPOINT }

    fun setEndpoint(ctx: Context, value: String) {
        prefs(ctx).edit().putString("endpoint", value.trim()).apply()
    }

    fun enabled(ctx: Context): Boolean = endpoint(ctx).startsWith("https://")

    private fun read(c: HttpURLConnection): String {
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        return stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
    }

    private fun connection(url: String, method: String): HttpURLConnection {
        require(url.startsWith("https://")) { "Only HTTPS Worker addresses are allowed." }
        return (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15000
            readTimeout = 280000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "RiseWithTheWord/2.3")
        }
    }

    /** Lightweight GET health check against the Worker root; no AI tokens are consumed. */
    fun test(ctx: Context, job: String): String {
        val out = JSONObject().put("job", job)
        return try {
            val endpoint = endpoint(ctx).trimEnd('/')
            val base = endpoint.removeSuffix("/story")
            val c = connection(base, "GET")
            try {
                val text = read(c)
                val json = JSONObject(text)
                val ready = c.responseCode in 200..299 && json.optBoolean("ready", false)
                out.put("ok", ready)
                    .put("text", if (ready) "AI service is reachable. Generate a short test story to verify provider access." else "")
                    .put("model", "Cloudflare Worker")
                    .put("healthCheck", true)
                    .put("searched", false)
                    .put("error", if (ready) "" else "Worker health check failed (HTTP ${c.responseCode}).")
                    .toString()
            } finally { c.disconnect() }
        } catch (e: Exception) {
            out.put("ok", false).put("error", e.message ?: "Could not reach the Worker.").toString()
        }
    }

    /**
     * Worker request schema: topic, context, instructions, language, wordCount.
     * The matching worker implementation is bundled in cloudflare-worker/worker.js.
     */
    fun generate(
        ctx: Context,
        job: String,
        title: String,
        instructions: String,
        context: String,
        language: String,
        wordCount: Int
    ): String {
        val out = JSONObject().put("job", job)
        val endpoint = endpoint(ctx).trim().removeSuffix("/")
        if (!endpoint.startsWith("https://") || !endpoint.endsWith("/story")) {
            return out.put("ok", false).put("error", "Worker URL must be HTTPS and end in /story.").toString()
        }
        if (title.isBlank() || title.length > 300) {
            return out.put("ok", false).put("error", "The topic is missing or too long.").toString()
        }
        return try {
            val body = JSONObject()
                .put("topic", title.take(300))
                .put("context", context.take(16000))
                .put("instructions", instructions.take(6000))
                .put("language", if (language == "ml" || language.equals("Malayalam", true)) "Malayalam" else "English")
                .put("wordCount", wordCount.coerceIn(500, 3500))
            val c = connection(endpoint, "POST").apply {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            try {
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val text = read(c)
                val response = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
                if (code !in 200..299) {
                    val msg = when (code) {
                        400 -> response.optString("error", "The Worker rejected the request. Check the request fields.")
                        429 -> "The AI service is busy. Please wait a minute before trying again."
                        502 -> response.optString("error", "Gemini generation failed. Check the Worker logs, Gemini API access, and quota.")
                        503 -> response.optString("error", "AI request protection is not available. Check the Worker binding.")
                        else -> response.optString("error", "Worker returned HTTP $code.")
                    }
                    out.put("ok", false).put("error", msg).put("httpStatus", code).toString()
                } else {
                    val content = response.optString("content", response.optString("text", "")).trim()
                    if (content.isEmpty()) {
                        out.put("ok", false).put("error", "The AI service returned an empty answer.").toString()
                    } else {
                        val sourcesIn = response.optJSONArray("sources") ?: JSONArray()
                        val sources = JSONArray()
                        for (i in 0 until sourcesIn.length()) {
                            val s = sourcesIn.optJSONObject(i) ?: continue
                            val url = s.optString("url", "")
                            if (url.startsWith("https://") || url.startsWith("http://")) {
                                sources.put(JSONObject().put("title", s.optString("title", "Source")).put("url", url))
                            }
                        }
                        out.put("ok", true)
                            .put("text", content)
                            .put("sources", sources)
                            .put("model", response.optString("provider", "Rise With The Word AI"))
                            .put("searched", sources.length() > 0)
                            .put("incomplete", false)
                            .put("provider", response.optString("provider", ""))
                            .put("fallbackUsed", response.optBoolean("fallbackUsed", false))
                            .toString()
                    }
                }
            } finally { c.disconnect() }
        } catch (e: Exception) {
            out.put("ok", false).put("error", e.message ?: "Network request failed.").toString()
        }
    }
}
