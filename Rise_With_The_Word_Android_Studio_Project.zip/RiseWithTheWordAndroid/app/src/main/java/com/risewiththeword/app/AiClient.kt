package com.risewiththeword.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to the OpenAI Responses API (ChatGPT) so the app can write long, researched expansions.
 * - The API key is kept only here, in private app storage. The web page can set it but never read it.
 * - Requests go only to https://api.openai.com.
 */
object AiClient {
    private const val PREFS = "rwtw_ai"
    private const val URL_RESPONSES = "https://api.openai.com/v1/responses"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun setKey(ctx: Context, key: String) { prefs(ctx).edit().putString("key", key.trim()).apply() }
    fun hasKey(ctx: Context) = !prefs(ctx).getString("key", "").isNullOrEmpty()
    fun setModel(ctx: Context, m: String) { prefs(ctx).edit().putString("model", m.trim()).apply() }
    private fun model(ctx: Context) = prefs(ctx).getString("model", null)?.takeIf { it.isNotBlank() } ?: "gpt-4.1"

    private fun post(key: String, body: String): Pair<Int, String> {
        val c = (URL(URL_RESPONSES).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 20000; readTimeout = 280000
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally { c.disconnect() }
    }

    private fun errorMessage(code: Int, text: String): String {
        val m = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
        return when (code) {
            401 -> "The API key was rejected. Check the key in Settings."
            429 -> "OpenAI says the rate limit or quota was reached. Check your billing and spending limit. ${m ?: ""}".trim()
            else -> m ?: "HTTP $code"
        }
    }

    /** Returns a JSON string: {job, ok, text, sources[], searched, model, incomplete} or {job, ok:false, error}. */
    fun generate(ctx: Context, job: String, instructions: String, input: String, maxTokens: Int, search: Boolean): String {
        val res = JSONObject().put("job", job)
        val key = prefs(ctx).getString("key", "") ?: ""
        if (key.isEmpty()) return res.put("ok", false).put("error", "No API key saved").toString()
        val model = model(ctx)
        try {
            var tool: String? = if (search) "web_search" else null
            var lastErr = ""
            repeat(3) {
                val body = JSONObject().put("model", model).put("instructions", instructions).put("input", input)
                    .put("max_output_tokens", maxTokens.coerceIn(20, 16000)).put("store", false)
                if (tool != null) body.put("tools", JSONArray().put(JSONObject().put("type", tool)))
                val (code, text) = post(key, body.toString())
                if (code in 200..299) return parse(res, text, model, tool != null)
                lastErr = errorMessage(code, text)
                // Some models/accounts reject one search tool name: fall back to the other, then to no search.
                if (code == 400 && tool == "web_search") tool = "web_search_preview"
                else if (code == 400 && tool == "web_search_preview") tool = null
                else return res.put("ok", false).put("error", lastErr).toString()
            }
            return res.put("ok", false).put("error", lastErr).toString()
        } catch (e: Exception) {
            return res.put("ok", false).put("error", e.message ?: "Network error").toString()
        }
    }

    private fun parse(res: JSONObject, text: String, model: String, searched: Boolean): String {
        val o = JSONObject(text)
        val status = o.optString("status")
        val sb = StringBuilder()
        val sources = JSONArray(); val seen = HashSet<String>()
        val output = o.optJSONArray("output") ?: JSONArray()
        for (i in 0 until output.length()) {
            val item = output.getJSONObject(i)
            if (item.optString("type") != "message") continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.getJSONObject(j)
                if (part.optString("type") != "output_text") continue
                sb.append(part.optString("text"))
                val ann = part.optJSONArray("annotations") ?: continue
                for (k in 0 until ann.length()) {
                    val a = ann.getJSONObject(k)
                    if (a.optString("type") == "url_citation") {
                        val url = a.optString("url").substringBefore("?utm_source")
                        if (url.startsWith("https://") && seen.add(url)) sources.put(JSONObject().put("title", a.optString("title")).put("url", url))
                    }
                }
            }
        }
        val out = sb.toString().trim()
        if (out.isEmpty()) {
            val why = o.optJSONObject("incomplete_details")?.optString("reason") ?: ""
            return res.put("ok", false).put("error", "No text returned" + (if (why.isNotEmpty()) " ($why). Try a shorter length or another model." else ".")).toString()
        }
        return res.put("ok", true).put("text", out).put("sources", sources).put("searched", searched).put("model", model)
            .put("incomplete", status == "incomplete").toString()
    }
}
