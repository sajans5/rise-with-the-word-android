package com.risewiththeword.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * The app's built-in database (SQLite, stored privately on the phone, works offline).
 *  packs     - downloaded content packs (stories, saints, readings, calendar, quiz, trivia) with their versions
 *  ai_cache  - AI-expanded stories / saints / days, so they can be read offline
 *  sync_log  - history of automatic updates
 */
class ContentDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "rwtw_content.db", null, 3) {
    private val appCtx = ctx.applicationContext

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE packs (name TEXT PRIMARY KEY, version TEXT, body TEXT, bytes INTEGER, updated INTEGER)")
        db.execSQL("CREATE TABLE ai_cache (k TEXT PRIMARY KEY, body TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE sync_log (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, status TEXT, message TEXT)")
        createImages(db)
        createQueue(db)
    }

    private fun createQueue(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS auto_queue (k TEXT PRIMARY KEY, title TEXT, instr TEXT, input TEXT, max INTEGER, search INTEGER, ts INTEGER)")
    }

    private fun createImages(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS images (id TEXT PRIMARY KEY, title TEXT, style TEXT, ts INTEGER, thumb TEXT, data BLOB)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { if (oldVersion < 2) createImages(db); if (oldVersion < 3) createQueue(db) }

    // ---- packs ----
    fun putPack(name: String, version: String, body: String) {
        val v = ContentValues().apply { put("name", name); put("version", version); put("body", body); put("bytes", body.length); put("updated", System.currentTimeMillis()) }
        writableDatabase.insertWithOnConflict("packs", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getPack(name: String): String {
        readableDatabase.rawQuery("SELECT body FROM packs WHERE name=?", arrayOf(name)).use { c -> if (c.moveToFirst()) return c.getString(0) ?: "" }
        // one-time migration from the version-2.0 file storage
        val f = File(File(appCtx.filesDir, "content"), "$name.json")
        if (f.exists()) { val t = f.readText(Charsets.UTF_8); putPack(name, "0", t); f.delete(); return t }
        return ""
    }

    fun packVersion(name: String): String? {
        readableDatabase.rawQuery("SELECT version FROM packs WHERE name=?", arrayOf(name)).use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    // ---- AI cache ----
    fun aiPut(k: String, body: String) {
        val v = ContentValues().apply { put("k", k); put("body", body); put("ts", System.currentTimeMillis()) }
        writableDatabase.insertWithOnConflict("ai_cache", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun aiDelete(k: String) { writableDatabase.delete("ai_cache", "k=?", arrayOf(k)) }
    fun aiAll(): JSONObject {
        val o = JSONObject()
        readableDatabase.rawQuery("SELECT k, body FROM ai_cache ORDER BY ts DESC", null).use { c ->
            while (c.moveToNext()) { try { o.put(c.getString(0), JSONObject(c.getString(1))) } catch (_: Exception) { } }
        }
        return o
    }

    // ---- automatic content queue ----
    fun aiHas(k: String): Boolean {
        val found = readableDatabase.rawQuery("SELECT 1 FROM ai_cache WHERE k=?", arrayOf(k)).use { c -> c.moveToFirst() }
        return found
    }
    fun queueAdd(k: String, title: String, instr: String, input: String, max: Int, search: Boolean) {
        val v = ContentValues().apply { put("k", k); put("title", title); put("instr", instr); put("input", input); put("max", max); put("search", if (search) 1 else 0); put("ts", System.currentTimeMillis()) }
        writableDatabase.insertWithOnConflict("auto_queue", null, v, SQLiteDatabase.CONFLICT_IGNORE)
        writableDatabase.execSQL("DELETE FROM auto_queue WHERE ts < ?", arrayOf<Any>(System.currentTimeMillis() - 10L * 24 * 3600 * 1000))
    }
    fun queuePending(limit: Int): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        readableDatabase.rawQuery("SELECT k, title, instr, input, max, search FROM auto_queue ORDER BY ts ASC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) out.add(JSONObject().put("k", c.getString(0)).put("title", c.getString(1)).put("instr", c.getString(2)).put("input", c.getString(3)).put("max", c.getInt(4)).put("search", c.getInt(5)))
        }
        return out
    }
    fun queueDone(k: String) { writableDatabase.delete("auto_queue", "k=?", arrayOf(k)) }
    fun queueCount(): Int {
        val n = readableDatabase.rawQuery("SELECT COUNT(*) FROM auto_queue", null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
        return n
    }

    // ---- generated wallpapers (base artwork kept on the phone) ----
    fun imgPut(id: String, title: String, style: String, thumb: String, data: ByteArray) {
        val v = ContentValues().apply { put("id", id); put("title", title); put("style", style); put("ts", System.currentTimeMillis()); put("thumb", thumb); put("data", data) }
        writableDatabase.insertWithOnConflict("images", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun imgList(): String {
        val a = JSONArray()
        readableDatabase.rawQuery("SELECT id, title, style, ts, thumb FROM images ORDER BY ts DESC", null).use { c ->
            while (c.moveToNext()) a.put(JSONObject().put("id", c.getString(0)).put("title", c.getString(1)).put("style", c.getString(2)).put("ts", c.getLong(3)).put("thumb", c.getString(4)))
        }
        return a.toString()
    }
    fun imgGet(id: String): ByteArray? {
        readableDatabase.rawQuery("SELECT data FROM images WHERE id=?", arrayOf(id)).use { c -> if (c.moveToFirst()) return c.getBlob(0) }
        return null
    }
    fun imgDelete(id: String) { writableDatabase.delete("images", "id=?", arrayOf(id)) }

    // ---- sync log ----
    fun log(status: String, message: String) {
        val db = writableDatabase
        db.insert("sync_log", null, ContentValues().apply { put("ts", System.currentTimeMillis()); put("status", status); put("message", message) })
        db.execSQL("DELETE FROM sync_log WHERE id NOT IN (SELECT id FROM sync_log ORDER BY id DESC LIMIT 30)")
    }

    /** Summary for the Content Sync screen. */
    fun info(): String {
        val packs = JSONObject()
        readableDatabase.rawQuery("SELECT name, version, bytes, updated FROM packs", null).use { c ->
            while (c.moveToNext()) packs.put(c.getString(0), JSONObject().put("version", c.getString(1)).put("bytes", c.getInt(2)).put("updated", c.getLong(3)))
        }
        val log = JSONArray()
        readableDatabase.rawQuery("SELECT ts, status, message FROM sync_log ORDER BY id DESC LIMIT 8", null).use { c ->
            while (c.moveToNext()) log.put(JSONObject().put("ts", c.getLong(0)).put("status", c.getString(1)).put("message", c.getString(2)))
        }
        var ai = 0
        readableDatabase.rawQuery("SELECT COUNT(*) FROM ai_cache", null).use { c -> if (c.moveToFirst()) ai = c.getInt(0) }
        return JSONObject().put("packs", packs).put("log", log).put("aiCount", ai).toString()
    }

    companion object {
        @Volatile private var inst: ContentDb? = null
        fun get(ctx: Context): ContentDb = inst ?: synchronized(this) { inst ?: ContentDb(ctx).also { inst = it } }
    }
}
