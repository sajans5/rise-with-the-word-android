package com.risewiththeword.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.util.Calendar

/** Daily gentle reminders. Each reminder is stored in SharedPreferences so it can be restored after a reboot. */
object Reminders {
    private const val PREFS = "rwtw_reminders"
    const val CHANNEL = "rwtw_prayer_reminders"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Prayer reminders", NotificationManager.IMPORTANCE_DEFAULT)
            ch.description = "Gentle daily reminders to pray and read Scripture."
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun pending(ctx: Context, id: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).putExtra("id", id)
        return PendingIntent.getBroadcast(ctx, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun set(ctx: Context, id: String, hour: Int, minute: Int, on: Boolean, title: String, text: String) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!on) { am.cancel(pending(ctx, id)); prefs.edit().remove(id).apply(); return }
        prefs.edit().putString(id, JSONObject().put("h", hour).put("m", minute).put("t", title).put("x", text).toString()).apply()
        schedule(ctx, id, hour, minute)
    }

    fun schedule(ctx: Context, id: String, hour: Int, minute: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 1000) add(Calendar.DAY_OF_YEAR, 1)
        }
        // Inexact alarm: may arrive a few minutes late, needs no special permission.
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending(ctx, id))
    }

    fun restoreAll(ctx: Context) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        for ((id, v) in prefs.all) {
            try { val o = JSONObject(v as String); schedule(ctx, id, o.getInt("h"), o.getInt("m")) } catch (_: Exception) { }
        }
    }

    fun get(ctx: Context, id: String): JSONObject? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(id, null)?.let { try { JSONObject(it) } catch (_: Exception) { null } }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getStringExtra("id") ?: return
        val o = Reminders.get(context, id) ?: return
        Reminders.createChannel(context)
        val open = PendingIntent.getActivity(context, 7315, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, Reminders.CHANNEL)
            .setSmallIcon(R.drawable.ic_app)
            .setContentTitle(o.optString("t", "Rise With The Word"))
            .setContentText(o.optString("x", "Pause for a moment with God's Word."))
            .setAutoCancel(true).setContentIntent(open).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        try { NotificationManagerCompat.from(context).notify(id.hashCode(), n) } catch (_: SecurityException) { }
        Reminders.schedule(context, id, o.getInt("h"), o.getInt("m"))   // schedule tomorrow
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) Reminders.restoreAll(context)
    }
}
