package com.risewiththeword.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Writes new content by itself. The app queues prompts for the coming days (daily reflection, saint of the day,
 * Church news). This object works through the queue with Gemini + Google Search and stores the results in the
 * built-in database, so the content is ready offline without anyone adding it.
 */
object AutoContent {
    private const val PREFS = "rwtw_auto"
    private val running = AtomicBoolean(false)

    fun setOn(ctx: Context, on: Boolean) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("on", on).apply() }
    fun isOn(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("on", false)

    fun queue(ctx: Context, items: JSONArray) {
        val db = ContentDb.get(ctx)
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val k = o.optString("k"); if (k.isEmpty() || db.aiHas(k)) continue
            db.queueAdd(k, o.optString("title"), o.optString("instr"), o.optString("input"), o.optInt("max", 2500), o.optBoolean("search", true))
        }
    }

    fun status(ctx: Context): String = JSONObject().put("on", isOn(ctx)).put("pending", ContentDb.get(ctx).queueCount()).put("key", GeminiClient.hasKey(ctx)).toString()

    /** Processes up to maxItems from the queue. Safe to call from a background thread. */
    fun run(ctx: Context, maxItems: Int): Int {
        if (!isOn(ctx) || !GeminiClient.hasKey(ctx)) return 0
        if (!running.compareAndSet(false, true)) return 0
        var done = 0
        try {
            val db = ContentDb.get(ctx)
            for (item in db.queuePending(12)) {
                if (done >= maxItems) break
                val k = item.getString("k")
                if (db.aiHas(k)) { db.queueDone(k); continue }
                val r = JSONObject(GeminiClient.generate(ctx, k, item.getString("instr"), item.getString("input"), item.optInt("max", 2500), item.optInt("search", 1) == 1))
                if (r.optBoolean("ok")) {
                    val e = JSONObject().put("text", r.getString("text")).put("sources", r.optJSONArray("sources") ?: JSONArray())
                        .put("model", r.optString("model")).put("searched", r.optBoolean("searched")).put("incomplete", r.optBoolean("incomplete"))
                        .put("ts", System.currentTimeMillis()).put("title", item.optString("title")).put("auto", true)
                    db.aiPut(k, e.toString()); db.queueDone(k); done++
                    db.log("auto", "Wrote: " + item.optString("title"))
                } else {
                    val err = r.optString("error")
                    db.log("error", "Auto content: $err")
                    if (err.contains("quota", true) || err.contains("rate", true) || err.contains("key", true)) break
                }
                Thread.sleep(3000)
            }
        } catch (_: Exception) {
        } finally { running.set(false) }
        return done
    }
}
