package com.risewiththeword.app

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Read-aloud using the phone's own text-to-speech engine (works offline when the voice is installed). */
class Speaker(ctx: Context) {
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx.applicationContext) { status -> ready = (status == TextToSpeech.SUCCESS) }

    /** Returns "ok", "starting", or "nolang" (the voice for that language is not installed). */
    fun speak(text: String, lang: String): String {
        if (!ready) return "starting"
        val locale = if (lang == "ml") Locale("ml", "IN") else Locale.ENGLISH
        val r = tts.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) return "nolang"
        tts.stop()
        val max = (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(500)
        var i = 0
        for (part in split(text, max)) {
            tts.speak(part, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "rwtw$i")
            i++
        }
        return "ok"
    }

    fun stop() { tts.stop() }
    fun shutdown() { tts.stop(); tts.shutdown() }

    private fun split(text: String, max: Int): List<String> {
        val out = ArrayList<String>()
        var rest = text.trim()
        while (rest.length > max) {
            var cut = rest.lastIndexOf(". ", max)
            if (cut < max / 2) cut = rest.lastIndexOf(" ", max)
            if (cut < 1) cut = max
            out.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring(cut + 1).trim()
        }
        if (rest.isNotEmpty()) out.add(rest)
        return out
    }
}
