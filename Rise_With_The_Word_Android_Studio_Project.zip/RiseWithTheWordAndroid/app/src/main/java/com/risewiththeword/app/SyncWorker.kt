package com.risewiththeword.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Runs about every 12 hours in the background (even when the app is closed) when the phone is online. */
class SyncWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val url = ContentSync.feed(applicationContext)
        if (url.isBlank()) return Result.success()
        val status = try { JSONObject(ContentSync.run(applicationContext, url, true)).optString("status") } catch (_: Exception) { "error" }
        return if (status == "error" && runAttemptCount < 2) Result.retry() else Result.success()
    }

    companion object {
        private const val NAME = "rwtw-auto-sync"
        fun schedule(ctx: Context, feedUrl: String) {
            val wm = WorkManager.getInstance(ctx)
            ContentSync.setFeed(ctx, feedUrl)
            if (feedUrl.isBlank()) { wm.cancelUniqueWork(NAME); return }
            val req = PeriodicWorkRequestBuilder<SyncWorker>(12, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
            wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
