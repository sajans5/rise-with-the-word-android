package com.risewiththeword.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.io.File

/**
 * Rise With The Word - the whole user interface lives in app/src/main/assets (HTML/CSS/JS).
 * This class hosts it in a WebView and offers a small, safe "bridge" for things a web page
 * cannot do by itself: share, save files, reminders, and content updates.
 * Nothing here opens an external browser or another app (except the system share sheet when the user taps Share).
 */
class MainActivity : Activity() {
    lateinit var webView: WebView
    private val pickCode = 4410
    private val notifCode = 2001
    @Volatile private var isActivityVisible = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(75, 42, 107)
        window.navigationBarColor = Color.rgb(75, 42, 107)
        Reminders.createChannel(this)
        getSharedPreferences("rwtw_ai", MODE_PRIVATE).edit().clear().apply()   // remove any old (version 2.1) key

        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(18, 16, 28))
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true                 // needed to load the bundled app files
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportZoom(false)
            mediaPlaybackRequiresUserGesture = true
        }
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            // Keep everything inside the app: never hand control to an external browser.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme ?: return true
                return scheme != "file"
            }
        }
        // Keep the page clear of the status bar, navigation bar and keyboard (Android 15 draws edge-to-edge).
        ViewCompat.setOnApplyWindowInsetsListener(webView) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setContentView(webView)
        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    private fun js(code: String) = runOnUiThread { webView.evaluateJavascript(code, null) }

    inner class Bridge {
        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                startActivity(Intent.createChooser(send, "Share"))
            }
        }

        @JavascriptInterface
        fun shareImage(base64: String, name: String) {
            try {
                val dir = File(cacheDir, "shared").apply { mkdirs() }
                val file = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                file.writeBytes(Base64.decode(base64, Base64.DEFAULT))
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", file)
                runOnUiThread {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = if (name.endsWith(".jpg")) "image/jpeg" else "image/png"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(send, "Share"))
                }
            } catch (e: Exception) { toast("Could not share the image") }
        }

        @JavascriptInterface
        fun saveImage(base64: String, name: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, if (name.endsWith(".jpg")) "image/jpeg" else "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/RiseWithTheWord")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw Exception("no uri")
                    contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                    toast("Saved to Pictures/RiseWithTheWord")
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
                    File(dir, name).writeBytes(bytes)
                    toast("Saved in the app's Pictures folder")
                }
            } catch (e: Exception) { toast("Could not save the image") }
        }

        @JavascriptInterface
        fun saveTextFile(name: String, text: String) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, if (name.endsWith(".json")) "application/json" else "text/plain")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("no uri")
                    contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    toast("Saved to Downloads: $name")
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
                    File(dir, name).writeText(text)
                    toast("Saved in the app's Documents folder: $name")
                }
            } catch (e: Exception) { toast("Could not save the file") }
        }

        @JavascriptInterface
        fun pickBackup() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                try { startActivityForResult(i, pickCode) } catch (e: Exception) { toast("No file picker available") }
            }
        }

        @JavascriptInterface
        fun setReminder(id: String, hour: Int, minute: Int, on: Boolean, title: String, text: String) {
            Reminders.set(this@MainActivity, id, hour, minute, on, title, text)
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notifCode)
            }
        }

        @JavascriptInterface
        fun readPack(name: String): String = ContentSync.readPack(this@MainActivity, name)

        /** Saves the feed address and switches automatic background updates on (or off when blank). */
        @JavascriptInterface
        fun setFeedUrl(url: String) { try { SyncWorker.schedule(this@MainActivity, url) } catch (_: Exception) { } }

        // ---- social media (opened inside the app by default) ----
        @JavascriptInterface
        fun openInApp(url: String, title: String) {
            if (!WebViewerActivity.allowed(url)) { toast("That address is not allowed in the app."); return }
            runOnUiThread { startActivity(Intent(this@MainActivity, WebViewerActivity::class.java).putExtra("url", url).putExtra("title", title)) }
        }

        @JavascriptInterface
        fun playVideo(videoId: String, title: String) {
            if (!WebViewerActivity.videoId.matches(videoId)) { toast("Invalid video"); return }
            runOnUiThread { startActivity(Intent(this@MainActivity, WebViewerActivity::class.java).putExtra("video", videoId).putExtra("title", title)) }
        }

        /** Optional: open in the real YouTube/Facebook/Instagram app (user setting). */
        @JavascriptInterface
        fun openExternal(url: String) {
            if (!WebViewerActivity.allowed(url)) { toast("That address is not allowed."); return }
            runOnUiThread { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { toast("No app found to open this.") } }
        }

        @JavascriptInterface
        fun ytCached(): String = YouTubeFeed.cached(this@MainActivity)

        @JavascriptInterface
        fun ytRefresh(pageUrl: String, channelId: String) {
            Thread {
                YouTubeFeed.saveSource(this@MainActivity, pageUrl, channelId)
                val r = YouTubeFeed.refresh(this@MainActivity, pageUrl, channelId)
                js("window.onYtResult(${JSONObject.quote(r)})")
            }.start()
        }

        @JavascriptInterface
        fun setYtNotify(on: Boolean) { YouTubeFeed.setNotify(this@MainActivity, on) }

        @JavascriptInterface
        fun dbInfo(): String = ContentDb.get(this@MainActivity).info()

        @JavascriptInterface
        fun dbAiAll(): String = ContentDb.get(this@MainActivity).aiAll().toString()

        @JavascriptInterface
        fun dbAiPut(key: String, json: String) { ContentDb.get(this@MainActivity).aiPut(key, json) }

        @JavascriptInterface
        fun dbAiDelete(key: String) { ContentDb.get(this@MainActivity).aiDelete(key) }

        @JavascriptInterface
        fun syncContent(manifestUrl: String, silent: Boolean) {
            Thread {
                val result = ContentSync.run(this@MainActivity, manifestUrl, silent)
                js("window.onSyncResult(${JSONObject.quote(result)})")
            }.start()
        }

        @JavascriptInterface
        fun setAiKey(key: String) { GeminiClient.setKey(this@MainActivity, key) }

        @JavascriptInterface
        fun hasAiKey(): Boolean = GeminiClient.hasKey(this@MainActivity)

        @JavascriptInterface
        fun setAiModel(model: String) { GeminiClient.setModel(this@MainActivity, model) }

        /** Runs in the background; the result is delivered to window.onAiResult(...). */
        @JavascriptInterface
        fun aiGenerate(job: String, instructions: String, input: String, maxTokens: Int, search: Boolean) {
            Thread {
                val result = GeminiClient.generate(this@MainActivity, job, instructions, input, maxTokens, search)
                js("window.onAiResult(${JSONObject.quote(result)})")
                if (!this@MainActivity.isActivityVisible && job != "test") {
                    this@MainActivity.notifyDone()
                }
            }.start()
        }

        // ---- Wallpaper Studio ----
        @JavascriptInterface
        fun setImageModel(model: String) { GeminiClient.setImageModel(this@MainActivity, model) }

        @JavascriptInterface
        fun imageGenerate(job: String, prompt: String, style: String, aspect: String) {
            Thread {
                val result = GeminiClient.generateImage(this@MainActivity, job, prompt, style, aspect)
                js("window.onImageResult(${JSONObject.quote(result)})")
                if (!this@MainActivity.isActivityVisible) {
                    this@MainActivity.notifyDone()
                }
            }.start()
        }

        /** Built-in wallpapers only (images/wallpapers/*.jpg), returned as base64 so the page can edit them safely. */
        @JavascriptInterface
        fun assetBase64(path: String): String {
            if (!Regex("^images/wallpapers/[A-Za-z0-9_]+\\.jpg$").matches(path)) return ""
            return try { Base64.encodeToString(assets.open(path).use { it.readBytes() }, Base64.NO_WRAP) } catch (_: Exception) { "" }
        }

        /** target: "home", "lock" or "both" */
        @JavascriptInterface
        fun setWallpaper(base64: String, target: String) {
            Thread {
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw Exception("bad image")
                    val wm = android.app.WallpaperManager.getInstance(this@MainActivity)
                    if (Build.VERSION.SDK_INT >= 24) {
                        val flags = when (target) { "home" -> android.app.WallpaperManager.FLAG_SYSTEM; "lock" -> android.app.WallpaperManager.FLAG_LOCK; else -> android.app.WallpaperManager.FLAG_SYSTEM or android.app.WallpaperManager.FLAG_LOCK }
                        wm.setBitmap(bmp, null, true, flags)
                    } else wm.setBitmap(bmp)
                    toast("Wallpaper set")
                } catch (e: Exception) { toast("Could not set the wallpaper") }
            }.start()
        }

        @JavascriptInterface
        fun imgSave(id: String, title: String, style: String, thumb: String, base64: String) {
            try { ContentDb.get(this@MainActivity).imgPut(id, title, style, thumb, Base64.decode(base64, Base64.DEFAULT)) } catch (_: Exception) { toast("Could not save the image") }
        }

        @JavascriptInterface
        fun imgList(): String = ContentDb.get(this@MainActivity).imgList()

        @JavascriptInterface
        fun imgGet(id: String): String = ContentDb.get(this@MainActivity).imgGet(id)?.let { Base64.encodeToString(it, Base64.NO_WRAP) } ?: ""

        @JavascriptInterface
        fun imgDelete(id: String) { ContentDb.get(this@MainActivity).imgDelete(id) }

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun vibrate() {
            try {
                val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    v.vibrate(15)
                }
            } catch (_: Exception) { }
        }
    }

    private fun notifyDone() {
        try {
            val open = android.app.PendingIntent.getActivity(this, 7316, Intent(this, MainActivity::class.java), android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
            val n = androidx.core.app.NotificationCompat.Builder(this, Reminders.CHANNEL)
                .setSmallIcon(R.drawable.ic_app).setContentTitle("Your creation is ready")
                .setContentText("Open Rise With The Word to see it.").setAutoCancel(true).setContentIntent(open).build()
            androidx.core.app.NotificationManagerCompat.from(this).notify(9001, n)
        } catch (_: SecurityException) { }
    }

    override fun onResume() {
        super.onResume()
        isActivityVisible = true
    }

    override fun onPause() {
        isActivityVisible = false
        super.onPause()
    }

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    @Deprecated("Deprecated Android callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val text = contentResolver.openInputStream(uri)!!.use { it.readBytes() }.toString(Charsets.UTF_8)
                if (text.length > 20_000_000) throw Exception("too large")
                js("window.onBackupPicked(${JSONObject.quote(text)})")
            } catch (e: Exception) { toast("Could not read that file") }
        }
    }

    @Deprecated("Deprecated Android callback retained for compatibility")
    override fun onBackPressed() {
        webView.evaluateJavascript("(function(){return window.RWTW_BACK?window.RWTW_BACK():false})()") { r ->
            if (r != "true") finish()
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
