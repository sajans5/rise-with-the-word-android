package com.risewiththeword.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.graphics.Color
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val reminderRequestCode = 7314
    private val channelId = "rwtw_daily_reminder"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 21, 34)
        window.navigationBarColor = Color.rgb(16, 21, 34)
        createNotificationChannel()

        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(16, 21, 34))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.addJavascriptInterface(AppBridge(this), "AndroidBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme ?: return false
                if (scheme == "http" || scheme == "https") {
                    val host = uri.host.orEmpty()
                    if (host.isNotBlank()) {
                        return openExternal(uri)
                    }
                }
                return false
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun openExternal(uri: Uri): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
            true
        } catch (_: Exception) {
            Toast.makeText(this, "Unable to open this link.", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Daily prayer reminder",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "A gentle daily reminder to spend a moment with God's Word."
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun scheduleReminder() {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, reminderRequestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 20)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            cal.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pending
        )
        getSharedPreferences("rwtw", MODE_PRIVATE).edit().putBoolean("reminder_enabled", true).apply()
        Toast.makeText(this, "Daily reminder enabled for 8:00 PM.", Toast.LENGTH_LONG).show()
    }

    private fun cancelReminder() {
        val intent = Intent(this, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, reminderRequestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
        getSharedPreferences("rwtw", MODE_PRIVATE).edit().putBoolean("reminder_enabled", false).apply()
        Toast.makeText(this, "Daily reminder turned off.", Toast.LENGTH_SHORT).show()
    }

    private fun toggleReminderFromPage() {
        val enabled = getSharedPreferences("rwtw", MODE_PRIVATE).getBoolean("reminder_enabled", false)
        if (enabled) {
            cancelReminder()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
        } else {
            scheduleReminder()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2001) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                scheduleReminder()
            } else {
                Toast.makeText(this, "Notifications were not allowed. You can enable them in Android Settings.", Toast.LENGTH_LONG).show()
            }
        }
    }

    inner class AppBridge(private val activity: Activity) {
        @JavascriptInterface
        fun shareText(text: String) {
            activity.runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                activity.startActivity(Intent.createChooser(send, "Share Rise With The Word"))
            }
        }

        @JavascriptInterface
        fun toggleDailyReminder() {
            activity.runOnUiThread { toggleReminderFromPage() }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            activity.runOnUiThread {
                try { openExternal(Uri.parse(url)) }
                catch (_: Exception) { Toast.makeText(activity, "Unable to open this link.", Toast.LENGTH_SHORT).show() }
            }
        }

        @JavascriptInterface
        fun loadDailyVerse() {
            Thread {
                var verseText = ""
                var reference = ""
                var error = ""
                var connection: HttpURLConnection? = null
                try {
                    connection = (URL("https://beta.ourmanna.com/api/v1/get/?format=json").openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 10000
                        readTimeout = 10000
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("User-Agent", "RiseWithTheWordAndroid/1.5")
                    }
                    if (connection.responseCode !in 200..299) throw Exception("HTTP ${connection.responseCode}")
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val verse = JSONObject(body).getJSONObject("verse").getJSONObject("details")
                    verseText = verse.optString("text", "")
                    reference = verse.optString("reference", "Daily Scripture")
                    if (verseText.isBlank()) throw Exception("The verse service returned empty content")
                } catch (e: Exception) {
                    error = e.message ?: "Network error"
                } finally {
                    connection?.disconnect()
                }
                val safeText = JSONObject.quote(verseText)
                val safeReference = JSONObject.quote(reference)
                val safeError = JSONObject.quote(error)
                runOnUiThread {
                    webView.evaluateJavascript("window.onDailyVerseLoaded($safeText,$safeReference,$safeError)", null)
                }
            }.start()
        }
    }

    @Deprecated("Deprecated Android callback retained for device compatibility")
    override fun onBackPressed() {
        if (::webView.isInitialized) {
            val handled = webView.evaluateJavascript(
                "(function(){var p=document.querySelector('.page.active');if(p&&p.id!=='home'){showPage('home');return true;}return false;})()"
            ) { result ->
                if (result != "true") finish()
            }
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!context.getSharedPreferences("rwtw", Context.MODE_PRIVATE).getBoolean("reminder_enabled", false)) return
        val openApp = PendingIntent.getActivity(
            context, 7315, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, "rwtw_daily_reminder")
            .setSmallIcon(R.drawable.ic_app)
            .setContentTitle("Rise With The Word")
            .setContentText("Pause for a moment with God's Word and prayer.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Take a quiet moment for Scripture, gratitude, and prayer."))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(7316, notification)
        } catch (_: SecurityException) {
            // Notifications may be disabled by the user in Android settings.
        }
    }
}
