package com.risewiththeword.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Reads the public "latest videos" list of a YouTube channel (no API key needed) and keeps it in the built-in database.
 * 1. Finds the channel ID (from the channel page, or one you enter in Settings).
 * 2. Reads https://www.youtube.com/feeds/videos.xml?channel_id=...
 */
object YouTubeFeed {
    private const val PREFS = "rwtw_yt"
    private val idRegex = Regex("^UC[A-Za-z0-9_-]{22}$")

    private fun get(url: String, max: Int = 900_000): String {
        require(url.startsWith("https://")) { "https only" }
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000; readTimeout = 20000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            setRequestProperty("Accept-Language", "en")
            setRequestProperty("Cookie", "CONSENT=YES+1; SOCS=CAI")
        }
        try {
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            val out = java.io.ByteArrayOutputStream(); val buf = ByteArray(8192); var total = 0
            c.inputStream.use { ins -> while (true) { val n = ins.read(buf); if (n < 0) break; total += n; out.write(buf, 0, n); if (total > max) break } }
            return String(out.toByteArray(), Charsets.UTF_8)
        } finally { c.disconnect() }
    }

    private fun resolveId(ctx: Context, pageUrl: String, override: String): String {
        if (idRegex.matches(override.trim())) return override.trim()
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getString("cid:$pageUrl", null)?.let { if (idRegex.matches(it)) return it }
        val html = get(pageUrl)
        val m = Regex("channel_id=(UC[A-Za-z0-9_-]{22})").find(html) ?: Regex("\"(?:channelId|externalId|browseId)\":\"(UC[A-Za-z0-9_-]{22})\"").find(html)
            ?: throw Exception("Could not find the channel ID automatically. Enter it in Settings > Social (it starts with UC).")
        val id = m.groupValues[1]
        prefs.edit().putString("cid:$pageUrl", id).apply()
        return id
    }

    /** Returns JSON {ok, channelId, videos:[{id,title,published,thumb}]} and stores it as pack "yt_latest". */
    fun refresh(ctx: Context, pageUrl: String, channelOverride: String): String {
        val res = JSONObject()
        try {
            val cid = resolveId(ctx, pageUrl, channelOverride)
            val xml = get("https://www.youtube.com/feeds/videos.xml?channel_id=$cid", 400_000)
            val p = android.util.Xml.newPullParser(); p.setInput(StringReader(xml))
            val videos = JSONArray(); var cur: JSONObject? = null; var ev = p.eventType
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    val n = p.name
                    if (n == "entry") cur = JSONObject()
                    else if (cur != null) when (n) {
                        "yt:videoId" -> cur.put("id", p.nextText())
                        "title" -> cur.put("title", p.nextText())
                        "published" -> cur.put("published", p.nextText())
                        "media:thumbnail" -> cur.put("thumb", p.getAttributeValue(null, "url") ?: "")
                    }
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG && p.name == "entry" && cur != null) {
                    if (cur.has("id") && videos.length() < 15) videos.put(cur); cur = null
                }
                ev = p.next()
            }
            if (videos.length() == 0) throw Exception("No videos were found for this channel.")
            res.put("ok", true).put("channelId", cid).put("videos", videos).put("ts", System.currentTimeMillis())
            ContentDb.get(ctx).putPack("yt_latest", "1", res.toString())
        } catch (e: Exception) {
            res.put("ok", false).put("error", e.message ?: "Network error")
        }
        return res.toString()
    }

    fun cached(ctx: Context): String = ContentDb.get(ctx).getPack("yt_latest")

    // ---- new-video notifications ----
    fun notifyEnabled(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("notify", true)
    fun setNotify(ctx: Context, on: Boolean) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("notify", on).apply() }
    fun saveSource(ctx: Context, pageUrl: String, channelId: String) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("page", pageUrl).putString("cid", channelId).apply() }

    /** Called by the background worker: refresh and notify if the newest video is new. */
    fun checkForNew(ctx: Context) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val page = prefs.getString("page", "") ?: ""
        if (page.isEmpty()) return
        val r = JSONObject(refresh(ctx, page, prefs.getString("cid", "") ?: ""))
        if (!r.optBoolean("ok")) return
        val top = r.getJSONArray("videos").getJSONObject(0)
        val last = prefs.getString("lastId", null)
        prefs.edit().putString("lastId", top.optString("id")).apply()
        if (last != null && last != top.optString("id") && notifyEnabled(ctx)) {
            Reminders.createChannel(ctx)
            val open = android.app.PendingIntent.getActivity(ctx, 7317, android.content.Intent(ctx, MainActivity::class.java), android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
            val n = androidx.core.app.NotificationCompat.Builder(ctx, Reminders.CHANNEL).setSmallIcon(R.drawable.ic_app)
                .setContentTitle("New video on Rise With The Word").setContentText(top.optString("title")).setAutoCancel(true).setContentIntent(open).build()
            try { androidx.core.app.NotificationManagerCompat.from(ctx).notify(9002, n) } catch (_: SecurityException) { }
        }
    }
}
