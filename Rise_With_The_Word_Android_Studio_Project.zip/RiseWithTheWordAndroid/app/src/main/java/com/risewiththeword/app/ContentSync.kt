package com.risewiththeword.app

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Automatic content updates.
 * The app downloads a small "manifest.json" from YOUR https address, compares pack versions with
 * what is stored, and downloads any newer packs into private app storage (never executed as code).
 *
 * manifest.json:
 * { "packs": { "stories": {"version": 2, "url": "stories.json", "sha256": "optional"},
 *              "saints": {...}, "readings": {...}, "calendar": {...}, "quiz": {...}, "trivia": {...} } }
 */
object ContentSync {
    private val allowed = setOf("stories", "saints", "readings", "calendar", "quiz", "trivia")
    private const val MAX_BYTES = 8 * 1024 * 1024
    private const val PREFS = "rwtw_packs"

    private fun dir(ctx: Context) = File(ctx.filesDir, "content").apply { mkdirs() }

    fun readPack(ctx: Context, name: String): String {
        if (name !in allowed) return ""
        val f = File(dir(ctx), "$name.json")
        return if (f.exists()) f.readText(Charsets.UTF_8) else ""
    }

    private fun fetch(url: String): ByteArray {
        require(url.startsWith("https://")) { "Only https addresses are allowed" }
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000; readTimeout = 20000; requestMethod = "GET"
            setRequestProperty("Accept", "application/json"); setRequestProperty("User-Agent", "RiseWithTheWord/2.1")
        }
        try {
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            val out = java.io.ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val buf = ByteArray(8192); var total = 0
                while (true) { val n = ins.read(buf); if (n < 0) break; total += n; if (total > MAX_BYTES) throw Exception("File too large"); out.write(buf, 0, n) }
            }
            return out.toByteArray()
        } finally { c.disconnect() }
    }

    private fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    fun run(ctx: Context, manifestUrl: String, silent: Boolean): String {
        val res = JSONObject().put("silent", silent)
        try {
            if (manifestUrl.isBlank()) return res.put("status", "error").put("message", "No feed address set").toString()
            // Friendly fix: if the address is just a website/folder, add /manifest.json.
            val mUrl = if (manifestUrl.trim().substringBefore("?").lowercase().endsWith(".json")) manifestUrl.trim() else manifestUrl.trim().trimEnd('/') + "/manifest.json"
            val mText = String(fetch(mUrl), Charsets.UTF_8)
            if (mText.trimStart().startsWith("<")) throw Exception("This address returned a web page, not manifest.json. Use the full address ending in /manifest.json and make sure GitHub Pages is deployed.")
            val manifest = JSONObject(mText)
            val packs = manifest.getJSONObject("packs")
            val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val versions = JSONObject(); var updated = 0
            for (name in packs.keys()) {
                if (name !in allowed) continue
                val p = packs.getJSONObject(name)
                val ver = p.optString("version", "0")
                versions.put(name, ver)
                if (prefs.getString("v_$name", null) == ver && File(dir(ctx), "$name.json").exists()) continue
                val packUrl = URL(URL(mUrl), p.getString("url")).toString()
                val bytes = fetch(packUrl)
                val want = p.optString("sha256", "")
                if (want.isNotEmpty() && !want.equals(sha256(bytes), ignoreCase = true)) throw Exception("Checksum mismatch for $name")
                JSONObject(String(bytes, Charsets.UTF_8).let { if (it.trimStart().startsWith("[")) "{\"items\":$it}" else it })  // must be valid JSON
                val tmp = File(dir(ctx), "$name.tmp"); tmp.writeBytes(bytes)
                if (!tmp.renameTo(File(dir(ctx), "$name.json"))) { File(dir(ctx), "$name.json").writeBytes(bytes); tmp.delete() }
                prefs.edit().putString("v_$name", ver).apply(); updated++
            }
            res.put("status", if (updated > 0) "updated" else "current").put("packs", versions).put("message", if (updated > 0) "$updated pack(s) updated" else "")
        } catch (e: Exception) {
            res.put("status", "error").put("message", e.message ?: "Network error")
        }
        return res.toString()
    }
}
