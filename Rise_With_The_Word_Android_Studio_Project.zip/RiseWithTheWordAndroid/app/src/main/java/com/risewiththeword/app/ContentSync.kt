package com.risewiththeword.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Automatic content updates into the built-in database (ContentDb).
 * Downloads "manifest.json" from YOUR https address, compares pack versions with the database,
 * and stores any newer packs. Packs are plain data (never executed).
 *
 * manifest.json:
 * { "packs": { "stories": {"version": 2, "url": "stories.json", "sha256": "optional"}, "saints": {...},
 *              "readings": {...}, "calendar": {...}, "quiz": {...}, "trivia": {...} } }
 */
object ContentSync {
    private val allowed = setOf("stories", "saints", "readings", "calendar", "quiz", "trivia")
    private const val MAX_BYTES = 8 * 1024 * 1024
    private const val PREFS = "rwtw_sync"

    fun readPack(ctx: Context, name: String): String = if (name in allowed) ContentDb.get(ctx).getPack(name) else ""

    fun setFeed(ctx: Context, url: String) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("feed", url.trim()).apply() }
    fun feed(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("feed", "") ?: ""

    private fun fetch(url: String): ByteArray {
        require(url.startsWith("https://")) { "Only https addresses are allowed" }
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000; readTimeout = 20000; requestMethod = "GET"
            setRequestProperty("Accept", "application/json"); setRequestProperty("User-Agent", "RiseWithTheWord/2.2")
        }
        try {
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            val out = java.io.ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val buf = ByteArray(8192); var total = 0
                while (true) { val n = ins.read(buf); if (n < 0) break; total += n; if (total > MAX_BYTES) throw Exception("File too large"); out.write(buf, 0, n) }
            }
            return out.toByteArray()
        } finally { c.disconnect() }
    }

    private fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    fun run(ctx: Context, manifestUrl: String, silent: Boolean): String {
        val res = JSONObject().put("silent", silent)
        val db = ContentDb.get(ctx)
        try {
            if (manifestUrl.isBlank()) return res.put("status", "error").put("message", "No feed address set").toString()
            val mUrl = if (manifestUrl.trim().substringBefore("?").lowercase().endsWith(".json")) manifestUrl.trim() else manifestUrl.trim().trimEnd('/') + "/manifest.json"
            val mText = String(fetch(mUrl), Charsets.UTF_8)
            if (mText.trimStart().startsWith("<")) throw Exception("This address returned a web page, not manifest.json. Use the full address ending in /manifest.json and make sure GitHub Pages is deployed.")
            val packs = JSONObject(mText).getJSONObject("packs")
            val versions = JSONObject(); var updated = 0
            for (name in packs.keys()) {
                if (name !in allowed) continue
                val p = packs.getJSONObject(name)
                val ver = p.optString("version", "0")
                versions.put(name, ver)
                if (db.packVersion(name) == ver && db.getPack(name).isNotEmpty()) continue
                val bytes = fetch(URL(URL(mUrl), p.getString("url")).toString())
                val want = p.optString("sha256", "")
                if (want.isNotEmpty() && !want.equals(sha256(bytes), ignoreCase = true)) throw Exception("Checksum mismatch for $name")
                val body = String(bytes, Charsets.UTF_8)
                JSONObject(if (body.trimStart().startsWith("[")) "{\"items\":$body}" else body)   // must be valid JSON
                db.putPack(name, ver, body); updated++
            }
            val msg = if (updated > 0) "$updated pack(s) updated" else ""
            db.log(if (updated > 0) "updated" else "current", msg)
            res.put("status", if (updated > 0) "updated" else "current").put("packs", versions).put("message", msg)
        } catch (e: Exception) {
            db.log("error", e.message ?: "Network error")
            res.put("status", "error").put("message", e.message ?: "Network error")
        }
        return res.toString()
    }
}
