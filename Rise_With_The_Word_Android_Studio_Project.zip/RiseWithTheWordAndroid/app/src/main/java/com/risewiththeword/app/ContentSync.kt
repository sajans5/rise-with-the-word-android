package com.risewiththeword.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Automatic content updates into the built-in database (ContentDb).
 * Downloads "manifest.json" from YOUR https address, compares pack versions with the database,
 * and stores any newer packs. Packs are plain data (never executed).
 *
 * manifest.json:
 * { "packs": { "stories": {"version": 2, "url": "stories.json", "sha256": "optional"}, "saints": {...},
 *              "readings": {...}, "calendar": {...}, "quiz": {...}, "trivia": {...} } }
 */
object ContentSync {
    private val allowed = setOf("stories", "saints", "readings", "calendar", "quiz", "trivia", "videos", "social")
    private const val MAX_BYTES = 8 * 1024 * 1024
    private const val PREFS = "rwtw_sync"

    fun readPack(ctx: Context, name: String): String = if (name in allowed) ContentDb.get(ctx).getPack(name) else ""

    fun setFeed(ctx: Context, url: String) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("feed", url.trim()).apply() }
    fun feed(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("feed", "") ?: ""

    private fun fetch(url: String): ByteArray {
        require(url.startsWith("https://")) { "Only https addresses are allowed" }
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000; readTimeout = 20000; requestMethod = "GET"
            setRequestProperty("Accept", "application/json"); setRequestProperty("User-Agent", "RiseWithTheWord/2.2")
        }
        try {
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            val out = java.io.ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val buf = ByteArray(8192); var total = 0
                while (true) { val n = ins.read(buf); if (n < 0) break; total += n; if (total > MAX_BYTES) throw Exception("File too large"); out.write(buf, 0, n) }
            }
            return out.toByteArray()
        } finally { c.disconnect() }
    }

    private fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    /** Turns whatever address the user typed into a list of addresses to try (GitHub web addresses are converted). */
    private fun candidates(input: String): List<String> {
        val url = input.trim()
        val noQ = url.substringBefore("?").substringBefore("#")
        val gh = Regex("^https://(?:www\\.)?github\\.com/([^/]+)/([^/]+)(?:/(.*))?$").find(noQ)
        if (gh != null) {
            val user = gh.groupValues[1]
            val repo = gh.groupValues[2].removeSuffix(".git")
            var rest = gh.groupValues[3]
            var branch = ""
            if (rest.startsWith("blob/") || rest.startsWith("raw/") || rest.startsWith("tree/")) {
                val p = rest.split("/", limit = 3)
                branch = if (p.size > 1) p[1] else ""
                rest = if (p.size > 2) p[2] else ""
            }
            val file = if (rest.lowercase().endsWith(".json")) rest else (rest.trimEnd('/') + "/manifest.json").trimStart('/')
            val list = ArrayList<String>()
            val branches = if (branch.isNotEmpty()) listOf(branch) else listOf("main", "master")
            for (b in branches) list.add("https://raw.githubusercontent.com/" + user + "/" + repo + "/" + b + "/" + file)
            list.add("https://" + user + ".github.io/" + repo + "/" + file)
            return list
        }
        return listOf(if (noQ.lowercase().endsWith(".json")) url else url.trimEnd('/') + "/manifest.json")
    }

    private fun friendly(msg: String?): String {
        val m = msg ?: "Network error"
        return when {
            m.contains("404") -> "Not found (404). Check your GitHub name and repository name, and that manifest.json is in the repository."
            m.contains("Unable to resolve") || m.contains("timeout", true) || m.contains("failed to connect", true) -> "No internet connection. It will try again automatically."
            else -> m
        }
    }

    fun run(ctx: Context, manifestUrl: String, silent: Boolean): String {
        val res = JSONObject().put("silent", silent)
        val db = ContentDb.get(ctx)
        try {
            if (manifestUrl.isBlank()) return res.put("status", "error").put("message", "No feed address set").toString()
            var mUrl = ""; var mText = ""; var lastErr = ""
            for (c in candidates(manifestUrl)) {
                try {
                    val t = String(fetch(c), Charsets.UTF_8)
                    if (t.trimStart().startsWith("<")) { lastErr = "This address returned a web page, not manifest.json."; continue }
                    mUrl = c; mText = t; break
                } catch (e: Exception) { lastErr = e.message ?: "Network error" }
            }
            if (mUrl.isEmpty()) throw Exception(lastErr)
            val packs = JSONObject(mText).getJSONObject("packs")
            val versions = JSONObject(); var updated = 0
            for (name in packs.keys()) {
                if (name !in allowed) continue
                val p = packs.getJSONObject(name)
                val ver = p.optString("version", "0")
                versions.put(name, ver)
                if (db.packVersion(name) == ver && db.getPack(name).isNotEmpty()) continue
                val bytes = fetch(URL(URL(mUrl), p.getString("url")).toString())
                val want = p.optString("sha256", "")
                if (want.isNotEmpty() && !want.equals(sha256(bytes), ignoreCase = true)) throw Exception("Checksum mismatch for $name")
                val body = String(bytes, Charsets.UTF_8)
                JSONObject(if (body.trimStart().startsWith("[")) "{\"items\":$body}" else body)   // must be valid JSON
                db.putPack(name, ver, body); updated++
            }
            val msg = if (updated > 0) "$updated pack(s) updated" else ""
            db.log(if (updated > 0) "updated" else "current", msg)
            res.put("status", if (updated > 0) "updated" else "current").put("packs", versions).put("message", msg)
        } catch (e: Exception) {
            db.log("error", friendly(e.message))
            res.put("status", "error").put("message", friendly(e.message))
        }
        return res.toString()
    }
}
