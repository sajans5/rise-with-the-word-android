/* Optional settings. You can also enter the feed address inside the app: Me > Settings > Content feed.
   feedUrl: address of your published manifest.json (must start with https://).
   Example: "https://YOUR-USERNAME.github.io/rise-content/manifest.json" */
window.RWTW_CONFIG = {
  feedUrl: ""
};
