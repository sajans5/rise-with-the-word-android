/* AI Assistant (hidden until unlocked): expands stories, saints and liturgical days with Gemini.
   - Unlock: Me > Privacy > tap the version line 7 times, then Me > Settings > AI Assistant.
   - The API key is stored only by the Android code (never in the web page, never in backups).
   - Generation runs in the background; results are saved on the phone for offline reading. */
(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, Lit = W.Liturgy, SC = A.screens, AC = A.actions;
  var AB = W.AndroidBridge || null;
  var LENGTHS = [['concise', 'Concise (~700 words)', 700], ['detailed', 'Detailed (~1,500 words)', 1500], ['full', 'Full chapter (~3,500 words)', 3500]];
  var lenChoice = 'detailed';

  var AI = A.ai = {};
  AI.hasKey = function () { try { return !!(AB && AB.hasAiKey && AB.hasAiKey()); } catch (e) { return false; } };
  AI.unlocked = function () { return !!A.settings.aiUnlocked; };
  AI.enabled = function () { return AI.unlocked() && A.settings.aiOn !== false && AI.hasKey(); };
  function lang() { return A.settings.lang === 'ml' ? 'ml' : 'en'; }
  function keyOf(kind, id) { return kind + ':' + id + ':' + lang(); }
  function todayUse() { var u = S.get('aiUse', {}); return u.d === A.todayKey() ? u.n : 0; }
  function addUse() { S.set('aiUse', { d: A.todayKey(), n: todayUse() + 1 }); }

  /* ---------- prompts ---------- */
  var SYSTEM = function (words) {
    return 'You are a careful, reverent writer for a Catholic app read by ordinary lay people.\n' +
      'RULES:\n1. Accuracy comes first. Use web search to verify names, dates, places, historical context and Church teaching. Prefer vatican.va, usccb.org, the Catechism of the Catholic Church, the Catholic Encyclopedia and reputable academic sources.\n' +
      '2. Never invent quotations, miracles, dates, places or sources. If something is legend or pious tradition, say so (for example "according to tradition"). If you are not sure, leave it out.\n' +
      '3. Keep Scripture and commentary separate. Any imagined narrative detail must be clearly signalled ("we can imagine...") and never stated as fact.\n' +
      '4. Be faithful to Catholic teaching. Treat all supplied facts (calendar facts, scripture text, dates) as authoritative and do not contradict them.\n' +
      '5. Do not reproduce copyrighted lectionary or modern Bible translation text; paraphrase or use only the supplied Douay-Rheims text.\n' +
      '6. Warm, vivid, readable prose with no padding and no emojis. About ' + words + ' words.\n' +
      '7. Format as Markdown: ## section headings, short paragraphs, "- " bullets where useful. End with a short prayer.\n' +
      '8. Write in ' + (lang() === 'ml' ? 'Malayalam (natural, respectful Catholic Malayalam; keep Bible book names and saint names recognisable)' : 'English') + '.';
  };
  var BUILD = {
    story: function (id, words) {
      var s = W.RWTW_STORIES.filter(function (x) { return x.id === id; })[0]; if (!s) return null;
      var txt = ''; try { var r = W.Bible.ready ? W.Bible.resolve(s.ref.replace(/\s*\(.*?\)/g, '').split(';')[0]) : null; if (r) txt = r.blocks.map(function (b) { return b.label + '\n' + b.verses.map(function (v) { return v.t; }).join(' '); }).join('\n\n').slice(0, 7000); } catch (e) {}
      return { title: s.title, instr: SYSTEM(words), input: 'Expand this Bible story in depth.\n\nTitle: ' + s.title + '\nReference: ' + s.ref + '\nSummary in the app: ' + s.summary + '\nLesson in the app: ' + s.lesson + (txt ? '\n\nDouay-Rheims text of the passage:\n' + txt : '') + '\n\nSections: ## Setting and Historical Context; ## The Story (a vivid but faithful retelling that follows the biblical text); ## What the Church and Tradition Say (only well-attested points, such as the Church Fathers or the Catechism, with citations); ## Lessons for Today; ## Questions for Reflection; ## Prayer.' };
    },
    saint: function (id, words) {
      var p = id.split('|'), rec = Lit.allSaints().filter(function (x) { return x.md === p[0] && x.name === p[1]; })[0]; if (!rec) return null;
      return { title: rec.name, instr: SYSTEM(words), input: 'Write a detailed profile of: ' + rec.name + '\nFeast date (month-day): ' + rec.md + '\nRank in the calendar: ' + (Lit.RANKS[rec.rank] || '') + '\nShort biography in the app: ' + rec.bio + '\n\nSections: ## Who Was This Saint? (dates and places, verified); ## Life and Journey; ## Virtues and Spiritual Teaching; ## Miracles and Legends (label legends clearly as tradition); ## Patronage and Devotion; ## Legacy Today; ## Prayer. If several saints share this entry, cover each briefly.' };
    },
    day: function (id, words) {
      var d = A.dayInfo(A.dateFromKey(id)), rd = W.RWTW_READINGS.forDay(d), refs = ['first', 'psalm', 'second', 'gospel'].filter(function (k) { return rd[k]; }).map(function (k) { return k + ': ' + rd[k]; }).join('; ');
      var sa = (d.celebrations || []).map(function (c) { return c.name + (c.bio ? ' (' + c.bio + ')' : ''); }).join(' | ');
      return { title: d.title, instr: SYSTEM(words), input: 'Explain this day of the Roman Catholic liturgical calendar for ordinary readers.\n\nAUTHORITATIVE CALENDAR FACTS (do not change):\nDate: ' + Lit.fullName(d.date) + '\nCelebration: ' + d.title + '\nSeason: ' + d.seasonName + '\nRank: ' + d.rankName + '\nLiturgical colour: ' + d.colorName + '\nSunday cycle: ' + d.cycle.sunday + '; weekday cycle: ' + d.cycle.weekday + '\n' + (sa ? 'Saints/celebrations today: ' + sa + '\n' : '') + (refs ? 'Reading references (' + rd.label + '): ' + refs + '\n' : '') + '\nSections: ## What We Celebrate; ## History and Meaning; ## Today\u2019s Readings in Context (explain themes and background; do not quote lectionary text); ## Customs and Traditions (including the liturgical colour and any fasting or devotional customs); ## Living This Day; ## Prayer.' };
    }
  };

  /* ---------- markdown (small, safe) ---------- */
  function inline(s) { return esc(s).replace(/\[([^\]]+)\]\((?:https?:[^)]*)\)/g, '$1').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<i>$2</i>'); }
  AI.md = function (text) {
    var out = '', list = false;
    String(text || '').replace(/\r/g, '').split('\n').forEach(function (line) {
      var l = line.trim();
      if (/^[-*]\s+/.test(l)) { if (!list) { out += '<ul>'; list = true; } out += '<li>' + inline(l.replace(/^[-*]\s+/, '')) + '</li>'; return; }
      if (list) { out += '</ul>'; list = false; }
      if (!l) return;
      var m = l.match(/^(#{1,4})\s+(.*)$/);
      if (m) out += '<h3 style="margin:16px 0 6px">' + inline(m[2]) + '</h3>'; else out += '<p class="reader" style="margin:8px 0">' + inline(l) + '</p>';
    });
    if (list) out += '</ul>';
    return out;
  };

  /* ---------- card shown on stories / saints / day screens ---------- */
  AI.card = function (kind, id, label) {
    if (!AI.unlocked()) return '';
    var k = keyOf(kind, id), saved = A.aiStore.all()[k], pend = S.get('aiPending', {}), isPending = Object.keys(pend).some(function (j) { return pend[j].k === k; });
    var h = '';
    if (saved) h += viewHtml(k, saved);
    if (!AI.enabled()) return h + '<div class="banner">\u2728 AI expansion is off. Turn it on in Me \u2192 Settings \u2192 AI Assistant.</div>';
    h += '<div class="card"><h3>\u2728 ' + esc(label) + '</h3>';
    if (isPending) h += '<p>\u23F3 Writing in the background\u2026 this can take 1\u20133 minutes for long pieces. You can keep using the app; keep it open until finished.</p><button class="btn alt" data-act="aiRefresh">Check again</button>';
    else {
      h += '<label>Length</label><select id="aiLen" data-act="aiLen">' + LENGTHS.map(function (x) { return '<option value="' + x[0] + '"' + (x[0] === lenChoice ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select><button class="btn block" style="margin-top:8px" data-act="aiExpand" data-kind="' + kind + '" data-id="' + esc(id) + '">' + (saved ? 'Write again' : 'Expand with AI') + '</button><p class="small muted">Gemini searches the web and writes this for you. It is checked by instructions, not by a person: verify before teaching. Used today: ' + todayUse() + '/' + (A.settings.aiLimit || 20) + '.</p>';
    }
    return h + '</div>';
  };
  function viewHtml(k, v) {
    var src = (v.sources || []).map(function (s) { var host = ''; try { host = s.url.replace(/^https?:\/\//, '').split('/')[0]; } catch (e) {} return '<li class="small">' + esc(s.title || host) + ' <span class="muted">\u2014 ' + esc(host) + '</span></li>'; }).join('');
    return '<div class="card"><div class="small muted">\u2728 AI-written \u00b7 ' + esc(v.model || '') + ' \u00b7 ' + new Date(v.ts).toLocaleDateString() + (v.searched ? ' \u00b7 web search used' : ' \u00b7 no web search') + (v.incomplete ? ' \u00b7 shortened' : '') + '</div>' + AI.md(v.text) + (src ? '<h3 style="margin:14px 0 4px">Sources consulted</h3><ul>' + src + '</ul>' : '') +
      '<div class="banner">AI-generated content can contain mistakes. Please verify with the Catechism, your priest or official sources before teaching or sharing as doctrine.</div><div class="row"><button class="btn alt" data-act="aiShare" data-k="' + esc(k) + '">Share</button><button class="btn alt" data-act="aiCopy" data-k="' + esc(k) + '">Copy</button><button class="btn danger" data-act="aiDelete" data-k="' + esc(k) + '">Delete</button></div></div>';
  }
  AC.aiLen = function (el) { lenChoice = el.value; };
  document.addEventListener('change', function (e) { if (e.target && e.target.id === 'aiLen') lenChoice = e.target.value; });
  AC.aiRefresh = function () { A.refresh(); };

  AC.aiExpand = function (el) {
    var kind = el.getAttribute('data-kind'), id = el.getAttribute('data-id');
    if (todayUse() >= (A.settings.aiLimit || 20)) { A.toast('Daily AI limit reached. Change it in Settings.'); return; }
    var words = (LENGTHS.filter(function (x) { return x[0] === lenChoice; })[0] || LENGTHS[1])[2], b = BUILD[kind](id, words); if (!b) { A.toast('Could not prepare this item'); return; }
    var job = 'j' + Date.now().toString(36), pend = S.get('aiPending', {}); pend[job] = { k: keyOf(kind, id), kind: kind, id: id, title: b.title, ts: Date.now() }; S.set('aiPending', pend); addUse();
    var maxTok = Math.min(12000, Math.round(words * 1.9) + 1500);
    if (AB && AB.aiGenerate) AB.aiGenerate(job, b.instr, b.input, maxTok, A.settings.aiSearch !== false);
    else { A.toast('AI works in the installed app'); delete pend[job]; S.set('aiPending', pend); }
    A.toast('\u2728 Started in the background'); A.refresh();
  };

  W.onAiResult = function (json) {
    var r; try { r = typeof json === 'string' ? JSON.parse(json) : json; } catch (e) { return; }
    if (r.job === 'test') { A.toast(r.ok ? '\u2713 Connected (' + (r.model || '') + ')' + (r.searched === false ? ' \u2014 web search unavailable' : '') : 'Test failed: ' + (r.error || 'unknown error')); return; }
    var pend = S.get('aiPending', {}), p = pend[r.job]; if (!p) return;
    delete pend[r.job]; S.set('aiPending', pend);
    if (r.ok) { A.aiStore.put(p.k, { text: r.text, sources: r.sources || [], model: r.model, searched: !!r.searched, incomplete: !!r.incomplete, ts: Date.now(), title: p.title }); A.toast('\u2728 Ready: ' + p.title); A.mark('read'); }
    else A.toast('AI could not finish: ' + (r.error || 'error'));
    if (A.cur && ['story', 'saints', 'today', 'aiLibrary'].indexOf(A.cur.name) >= 0) A.refresh();
  };
  AC.aiShare = function (el) { var v = A.aiStore.all()[el.getAttribute('data-k')]; if (v) A.bridge.share(v.title + '\n\n' + v.text.replace(/[#*]/g, '') + '\n\n(AI-written; please verify) \u2014 Rise With The Word'); };
  AC.aiCopy = function (el) { var v = A.aiStore.all()[el.getAttribute('data-k')]; if (v) A.copy(v.text); };
  AC.aiDelete = function (el) { var k = el.getAttribute('data-k'); A.ask('Delete this expanded content?', function () { A.aiStore.del(k); A.refresh(); }, 'Delete'); };

  /* ---------- hook the card into existing screens ---------- */
  var oStory = SC.story;
  SC.story = function (id) { var o = oStory(id), s = W.RWTW_STORIES.filter(function (x) { return x.id === id; })[0]; if (s && o.html) o.html += AI.card('story', id, 'Expand this story'); return o; };
  var oToday = SC.today;
  SC.today = function (key) { var o = oToday(key), d = A.dayInfo(A.dateFromKey(key)); o.html += AI.card('day', d.key, 'Understand today\u2019s celebration'); return o; };
  var oSaints = SC.saints;
  SC.saints = function (key) {
    var o = oSaints(key), dt = key ? A.dateFromKey(key) : new Date(), list = Lit.saintsOn(dt.getMonth() + 1, dt.getDate());
    if (AI.unlocked() && list.length) { var extra = list.slice(0, 3).map(function (s) { return AI.card('saint', s.md + '|' + s.name, 'Expand: ' + s.name); }).join(''); o.html = o.html.replace('<h3 style="margin:14px 0 6px">Archive</h3>', extra + '<h3 style="margin:14px 0 6px">Archive</h3>'); }
    return o;
  };

  /* ---------- saved AI library ---------- */
  SC.aiLibrary = function () {
    var all = A.aiStore.all(), keys = Object.keys(all).sort(function (a, b) { return all[b].ts - all[a].ts; });
    return { title: 'My Expanded Content', html: keys.length ? keys.map(function (k) { return viewHtml(k, all[k]).replace('<div class="card">', '<div class="card"><h3>' + esc(all[k].title) + '</h3>'); }).join('') : '<p class="muted">Nothing yet. Open a story, saint or day and tap \u201CExpand with AI\u201D.</p>' };
  };

  /* ---------- hidden unlock + settings ---------- */
  var taps = 0, tapT;
  AC.aiTap = function () { taps++; clearTimeout(tapT); tapT = setTimeout(function () { taps = 0; }, 2500); if (taps >= 7) { taps = 0; A.settings.aiUnlocked = true; A.saveSettings(); A.toast('\u2728 AI Assistant unlocked \u2014 see Settings'); } else if (taps >= 4) A.toast((7 - taps) + ' more\u2026'); };
  var oPrivacy = SC.privacy;
  SC.privacy = function () { var o = oPrivacy(); o.html = o.html.replace(/<p>Rise With The Word v([0-9.]+)<\/p>/, '<p data-act="aiTap">Rise With The Word v$1</p>'); o.html += '<div class="card"><h3>AI Assistant (optional)</h3><p class="small muted">If you switch on the hidden AI Assistant, the text of the story, saint or calendar day you choose to expand is sent to Google (Gemini) using your own API key. No journal, notes, intentions or personal details are sent.</p></div>'; return o; };
  var oSettings = SC.settings;
  SC.settings = function () {
    var o = oSettings(); if (!AI.unlocked()) return o;
    var s = A.settings, has = AI.hasKey();
    o.html += '<div class="card"><h3>\u2728 AI Assistant (Gemini)</h3><p class="small muted">Your API key is stored only by the Android app on this phone. It is never saved in backups and is sent only to generativelanguage.googleapis.com. Each expansion is counted against your own Google AI Studio / Google Cloud plan (a free tier may apply, with rate limits). Never share your key.</p>' +
      '<p><label style="color:var(--text)"><input type="checkbox" id="aiOn"' + (s.aiOn !== false ? ' checked' : '') + '> Enable AI expansion buttons</label></p>' +
      '<label>Google Gemini API key ' + (has ? '(saved \u2014 leave blank to keep)' : '(not set)') + '</label><input type="password" id="aiKey" autocomplete="off" placeholder="AIza\u2026">' +
      '<label>Model</label><input type="text" id="aiModel" value="' + esc(/^gpt/i.test(s.aiModel || '') ? 'gemini-2.5-flash' : (s.aiModel || 'gemini-2.5-flash')) + '">' +
      '<p><label style="color:var(--text)"><input type="checkbox" id="aiSearch"' + (s.aiSearch !== false ? ' checked' : '') + '> Let Gemini use Google Search</label></p>' +
      '<label>Daily limit (expansions)</label><select id="aiLimit">' + [5, 10, 20, 40].map(function (n) { return '<option' + (n === (s.aiLimit || 20) ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select>' +
      '<div class="row" style="margin-top:8px"><button class="btn" data-act="aiSave">Save</button><button class="btn alt" data-act="aiTest">Test connection</button>' + (has ? '<button class="btn danger" data-act="aiRemove">Remove key</button>' : '') + '</div><button class="btn alt block" style="margin-top:8px" data-act="go" data-arg="aiLibrary">My expanded content</button></div>';
    return o;
  };
  AC.aiSave = function () {
    var key = A.$('#aiKey').value.trim(); A.settings.aiOn = A.$('#aiOn').checked; A.settings.aiSearch = A.$('#aiSearch').checked; A.settings.aiLimit = +A.$('#aiLimit').value; A.settings.aiModel = A.$('#aiModel').value.trim() || 'gemini-2.5-flash'; if (/^gpt/i.test(A.settings.aiModel)) A.settings.aiModel = 'gemini-2.5-flash';
    if (key && !/^AIza/.test(key)) { A.toast('That does not look like a Gemini API key (it starts with AIza)'); return; }
    if (AB && AB.setAiKey && key) AB.setAiKey(key); if (AB && AB.setAiModel) AB.setAiModel(A.settings.aiModel);
    A.saveSettings(); A.toast('\u2713 Saved'); A.refresh();
  };
  AC.aiTest = function () { if (!AI.hasKey()) { A.toast('Save your API key first'); return; } A.toast('Testing\u2026'); if (AB && AB.aiGenerate) AB.aiGenerate('test', 'You are a connection test.', 'Reply with the single word OK.', 50, A.settings.aiSearch !== false); };
  AC.aiRemove = function () { A.ask('Remove the saved API key from this phone?', function () { if (AB && AB.setAiKey) AB.setAiKey(''); A.refresh(); }, 'Remove'); };
})();
