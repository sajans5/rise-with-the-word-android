(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, t = A.t, Lit = W.Liturgy;
  var SC = A.screens, AC = A.actions;

  A.ask = function (msg, fn, yes) { A.askFn = fn; A.openSheet('<p>' + esc(msg) + '</p><div class="row"><button class="btn danger" data-act="askYes">' + esc(yes || 'Yes') + '</button><button class="btn alt" data-act="closeSheet">Cancel</button></div>'); };
  AC.askYes = function () { var f = A.askFn; A.closeSheet(); A.askFn = null; if (f) f(); };
  function tile(ico, title, sub, arg) { return '<button class="tile" data-act="go" data-arg="' + arg + '"><span class="ico">' + ico + '</span><b>' + esc(title) + '</b><span>' + esc(sub) + '</span></button>'; }
  function today() { return new Date(); }
  function fmtDate(ts) { var d = new Date(ts); return d.getDate() + ' ' + Lit.MONTHS[d.getMonth()].slice(0, 3) + ' ' + d.getFullYear(); }

  SC.me = function () {
    return { title: t('me'), html: '<div class="grid">' + tile('\uD83D\uDD25', t('streak'), A.streak() + ' day(s)', 'journey') + tile('\uD83D\uDCD3', t('journal'), S.get('journal', []).length + ' entries', 'journal') + tile('\uD83D\uDD12', t('intentions'), 'Private by default', 'intentions') + tile('\u2B50', t('favorites') + ' / ' + t('recent'), 'Saved items', 'favs') + tile('\u23F0', t('reminders'), 'Gentle notifications', 'reminders') + tile('\uD83D\uDCBE', t('backup'), 'Export / import', 'backup') + tile('\uD83D\uDD04', t('sync'), 'Updates & offline', 'sync') + tile('\uD83D\uDC6A', t('groups'), 'Family plans', 'groups') + tile('\u26EA', t('parish'), 'Mass times & notes', 'parish') + tile('\uD83C\uDFA8', t('cards'), 'Scripture images', 'card') + tile('\u2699\uFE0F', t('settings'), t('language') + ', ' + t('theme'), 'settings') + tile('\uD83D\uDEE1\uFE0F', t('privacy'), t('about'), 'privacy') + '</div>' };
  };

  /* ---------- journey ---------- */
  SC.journey = function () {
    var days = S.get('days', {}), total = Object.keys(days).length, h = '<div class="hero"><div class="eyebrow">' + esc(t('streak')) + '</div><h2>' + A.streak() + ' day(s)</h2><p>' + A.weekCount() + ' of ' + A.settings.weeklyGoal + ' days this week</p></div>';
    var d = new Date(); d.setHours(12); d.setDate(d.getDate() - 20); var cells = '';
    for (var i = 0; i < 21; i++) { var k = Lit.key(d), on = days[k]; cells += '<div style="aspect-ratio:1;border-radius:8px;background:' + (on ? 'var(--accent)' : 'var(--panel2)') + '" title="' + k + '"></div>'; d.setDate(d.getDate() + 1); }
    h += '<div class="card"><h3>Last 3 weeks</h3><div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px">' + cells + '</div><p class="small muted">' + total + ' days with prayer or reading since you began.</p></div>';
    h += '<div class="card"><label>Weekly goal (days)</label><select id="goal">' + [1, 2, 3, 4, 5, 6, 7].map(function (n) { return '<option' + (n === A.settings.weeklyGoal ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select><label><input type="checkbox" id="stOn"' + (A.settings.streaksOn ? ' checked' : '') + '> Show streaks on Home (optional)</label><button class="btn" style="margin-top:8px" data-act="goalSave">' + esc(t('save')) + '</button></div><button class="btn block" data-act="prayedToday">I prayed today</button>';
    return { title: t('streak'), html: h };
  };
  AC.goalSave = function () { A.settings.weeklyGoal = +A.$('#goal').value; A.settings.streaksOn = A.$('#stOn').checked; A.saveSettings(); A.toast('\u2713'); };

  /* ---------- journal ---------- */
  SC.journal = function () {
    var j = S.get('journal', []);
    var h = '<div class="row"><button class="btn" data-act="jNew">+ New entry</button><button class="btn alt" data-act="jExport">Export</button></div><div class="list" style="margin-top:10px">' + (j.length ? j.map(function (e) { return '<button class="item" data-act="jOpen" data-id="' + e.id + '"><b>' + esc(e.title || fmtDate(e.ts)) + '</b><span>' + fmtDate(e.ts) + ' \u00b7 ' + esc(e.text.slice(0, 80)) + '</span></button>'; }).join('') : '<p class="muted">Your journal is private and stays on this device.</p>') + '</div>';
    return { title: t('journal'), html: h };
  };
  AC.jNew = function () { A.go('jEdit', {}); };
  AC.jOpen = function (el) { A.go('jEdit', { id: el.getAttribute('data-id') }); };
  SC.jEdit = function (arg) {
    var ex = arg.id ? S.get('journal', []).filter(function (e) { return e.id === arg.id; })[0] : null; A.jCtx = ex;
    return { title: t('journal'), html: '<label>Title (optional)</label><input type="text" id="jt" value="' + esc(ex ? ex.title : '') + '"><label>Your prayer or reflection</label><textarea id="jx" style="min-height:240px">' + esc(ex ? ex.text : '') + '</textarea><div class="row"><button class="btn" data-act="jSave">' + esc(t('save')) + '</button>' + (ex ? '<button class="btn danger" data-act="jDel">Delete</button>' : '') + '</div>' };
  };
  AC.jSave = function () { var tx = A.$('#jx').value.trim(); if (!tx) { A.toast('Write something first'); return; } var j = S.get('journal', []), ti = A.$('#jt').value.trim();
    if (A.jCtx) { j = j.map(function (e) { return e.id === A.jCtx.id ? Object.assign(e, { title: ti, text: tx, edited: Date.now() }) : e; }); } else { j.unshift({ id: A.uid(), ts: Date.now(), title: ti, text: tx }); A.mark('prayer'); }
    S.set('journal', j); A.toast('\u2713 ' + t('saved')); A.back(); };
  AC.jDel = function () { A.ask('Delete this entry?', function () { S.set('journal', S.get('journal', []).filter(function (e) { return e.id !== A.jCtx.id; })); A.back(); }, 'Delete'); };
  AC.jExport = function () {
    var j = S.get('journal', []); if (!j.length) { A.toast('Nothing to export'); return; }
    var txt = 'Rise With The Word \u2014 Prayer Journal\nExported ' + fmtDate(Date.now()) + '\n\n' + j.slice().reverse().map(function (e) { return '=== ' + fmtDate(e.ts) + (e.title ? ' \u2014 ' + e.title : '') + ' ===\n' + e.text + '\n'; }).join('\n');
    A.bridge.saveText('prayer-journal-' + Lit.key(new Date()) + '.txt', txt);
  };

  /* ---------- intentions ---------- */
  SC.intentions = function () {
    var L = S.get('intentions', []);
    var h = '<div class="banner">\uD83D\uDD12 Private by default. These intentions never leave your device unless you choose to share one.</div><textarea id="in" placeholder="I pray for\u2026" style="min-height:70px"></textarea><button class="btn block" data-act="inAdd">Add intention</button><div class="list" style="margin-top:10px">';
    h += L.map(function (x) { return '<div class="item"><div class="row sp"><b style="' + (x.done ? 'text-decoration:line-through;opacity:.6' : '') + '">' + esc(x.text) + '</b></div><span>' + fmtDate(x.ts) + '</span><div class="row" style="margin-top:6px"><button class="chip" data-act="inDone" data-id="' + x.id + '">' + (x.done ? 'Reopen' : '\u2713 Answered / thanksgiving') + '</button><button class="chip" data-act="inShare" data-id="' + x.id + '">' + esc(t('share')) + '</button><button class="chip" data-act="inDel" data-id="' + x.id + '">Delete</button></div></div>'; }).join('') + '</div>';
    return { title: t('intentions'), html: h };
  };
  AC.inAdd = function () { var v = A.$('#in').value.trim(); if (!v) return; var L = S.get('intentions', []); L.unshift({ id: A.uid(), text: v, ts: Date.now(), done: false }); S.set('intentions', L); A.refresh(); };
  AC.inDone = function (el) { var L = S.get('intentions', []); L.forEach(function (x) { if (x.id === el.getAttribute('data-id')) x.done = !x.done; }); S.set('intentions', L); A.refresh(); };
  AC.inDel = function (el) { var id = el.getAttribute('data-id'); A.ask('Delete this intention?', function () { S.set('intentions', S.get('intentions', []).filter(function (x) { return x.id !== id; })); A.refresh(); }, 'Delete'); };
  AC.inShare = function (el) { var x = S.get('intentions', []).filter(function (y) { return y.id === el.getAttribute('data-id'); })[0]; if (x) A.bridge.share('Please pray for: ' + x.text); };

  /* ---------- favorites + recent ---------- */
  SC.favs = function () {
    var fav = S.get('fav', []), rec = S.get('recent', []);
    function open(type, id) { return type === 'prayer' ? 'data-act="openPrayer" data-id="' + id + '"' : type === 'story' ? 'data-act="openStory" data-id="' + id + '"' : type === 'chapter' ? 'data-act="openChapter" data-code="' + id.split(':')[0] + '" data-ch="' + id.split(':')[1] + '"' : type === 'rosary' ? 'data-act="rosaryStart" data-set="' + id + '"' : 'data-act="go" data-arg="home"'; }
    var h = '<h3>' + esc(t('favorites')) + '</h3><div class="list">' + (fav.length ? fav.map(function (f) { return '<button class="item" ' + open(f.type, f.id) + '><b>\u2605 ' + esc(f.title) + '</b><span>' + esc(f.type) + '</span></button>'; }).join('') : '<p class="muted small">Tap \u2606 on a prayer or story to save it here.</p>') + '</div><h3 style="margin-top:14px">' + esc(t('recent')) + '</h3><div class="list">' + rec.slice(0, 15).map(function (f) { return '<button class="item" ' + open(f.type, f.id) + '><b>' + esc(f.title) + '</b><span>' + esc(f.type) + '</span></button>'; }).join('') + '</div>';
    return { title: t('favorites'), html: h };
  };

  /* ---------- reminders ---------- */
  var DEFREM = [{ id: 'morning', title: 'Morning prayer', h: 7, m: 0, on: false, text: 'Start the day with God. A few quiet minutes of prayer.' }, { id: 'angelus', title: 'Angelus', h: 12, m: 0, on: false, text: 'Time for the Angelus.' }, { id: 'mercy', title: 'Divine Mercy', h: 15, m: 0, on: false, text: 'The hour of mercy. Jesus, I trust in You.' }, { id: 'evening', title: 'Evening examen', h: 20, m: 0, on: false, text: 'Take a moment to thank God for today.' }, { id: 'rosary', title: 'Rosary', h: 19, m: 0, on: false, text: 'Pray the Rosary today.' }];
  function rems() { var r = S.get('reminders', null); if (!r) { r = DEFREM; S.set('reminders', r); } return r; }
  SC.reminders = function () {
    var h = '<div class="banner">Reminders are gentle notifications scheduled on your phone. You may need to allow notifications for this app in Android settings.</div>' + rems().map(function (r) { return '<div class="card"><div class="row sp"><b>' + esc(r.title) + '</b><label style="color:inherit"><input type="checkbox" data-act="remOn" data-id="' + r.id + '"' + (r.on ? ' checked' : '') + '> On</label></div><input type="time" data-act="remTime" data-id="' + r.id + '" value="' + A.pad(r.h) + ':' + A.pad(r.m) + '"></div>'; }).join('');
    return { title: t('reminders'), html: h };
  };
  document.addEventListener('change', function (e) {
    var el = e.target, act = el.getAttribute && el.getAttribute('data-act'); if (act !== 'remOn' && act !== 'remTime') return;
    var L = rems(), r = L.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0]; if (!r) return;
    if (act === 'remOn') { r.on = el.checked; if (r.on) A.bridge.notifyPermission(); } else { var p = el.value.split(':'); if (p.length === 2) { r.h = +p[0]; r.m = +p[1]; } }
    S.set('reminders', L); A.bridge.setReminder(r.id, r.h, r.m, r.on, r.title, r.text); A.toast(r.on ? '\u23F0 ' + A.pad(r.h) + ':' + A.pad(r.m) : 'Off');
  });
  A.syncReminders = function () { rems().forEach(function (r) { A.bridge.setReminder(r.id, r.h, r.m, r.on, r.title, r.text); }); };

  /* ---------- backup / restore ---------- */
  SC.backup = function () {
    return { title: t('backup'), html: '<div class="card"><p>Your bookmarks, notes, highlights, journal, intentions, progress and settings live on this phone. Save a backup file to keep them safe or to move to a new phone.</p><button class="btn block" data-act="bkExport">Save backup file</button><p class="small muted">Saved to your Downloads folder as a .json file.</p></div><div class="card"><button class="btn alt block" data-act="bkRestore">Restore from backup file</button><p class="small muted">Restoring replaces the data on this device with the backup.</p></div>' };
  };
  AC.bkExport = function () { var data = S.all(); delete data.syncMeta; var json = JSON.stringify({ app: 'RiseWithTheWord', version: A.version, created: new Date().toISOString(), data: data }); A.bridge.saveText('rise-with-the-word-backup-' + Lit.key(new Date()) + '.json', json); };
  AC.bkRestore = function () { A.bridge.pickBackup(); };
  AC._restore = function (text) {
    try { var o = JSON.parse(text); if (o.app !== 'RiseWithTheWord' || !o.data) throw new Error('bad'); var n = Object.keys(o.data).length;
      A.ask('Restore ' + n + ' items from this backup? Current data on this device will be replaced.', function () { Object.keys(S.all()).forEach(function (k) { S.del(k); }); Object.keys(o.data).forEach(function (k) { try { localStorage.setItem('rwtw.' + k, o.data[k]); } catch (e) {} }); A.settings = Object.assign({}, A.settings, S.get('settings', {})); A.applySettings(); A.toast('\u2713 Restored'); A.root('home'); }, 'Restore');
    } catch (e) { A.toast('That file is not a Rise With The Word backup'); }
  };

  /* ---------- sync ---------- */
  A.normFeed = function (u) { u = (u || '').trim(); if (u && !/\.json(\?.*)?$/i.test(u)) u = u.replace(/\/+$/, '') + '/manifest.json'; return u; };
  A.feedUrl = function () { return A.normFeed(A.settings.feedUrl || (A.cfg && A.cfg.feedUrl) || ''); };
  SC.sync = function () {
    var m = S.get('syncMeta', {}), url = A.feedUrl();
    var h = '<div class="card"><h3>' + esc(t('sync')) + '</h3><p>Downloaded content stays on your phone, so the Bible, saints, stories and readings keep working offline.</p><p class="small">Feed: ' + (url ? '<span class="kbd">' + esc(url) + '</span>' : '<i>not set</i>') + '</p><p class="small">Last check: ' + (m.checked ? new Date(m.checked).toLocaleString() : 'never') + '<br>Status: ' + esc(m.status || '\u2014') + (m.message ? ' \u00b7 ' + esc(m.message) : '') + '</p>';
    h += '<button class="btn block" data-act="syncNow"' + (url ? '' : ' disabled') + '>Check for updates now</button>' + (url ? '' : '<p class="small muted">Set your content feed address in Settings to switch on automatic updates. See the README, section \u201CAutomatic content updates\u201D.</p>') + '</div>';
    var db = A.bridge.dbInfo(), pk = db ? db.packs : {}, names = Object.keys(pk || {});
    h += '<div class="card"><h3>Built-in database</h3>' + (db ? '<p class="small">' + names.length + ' content pack(s) \u00b7 ' + db.aiCount + ' saved AI expansion(s)</p>' + names.map(function (n) { return '<p class="small">' + esc(n) + ' \u00b7 version ' + esc(String(pk[n].version)) + ' \u00b7 ' + Math.round(pk[n].bytes / 1024) + ' KB \u00b7 ' + new Date(pk[n].updated).toLocaleDateString() + '</p>'; }).join('') + (db.log.length ? '<h3 style="margin-top:8px">Recent updates</h3>' + db.log.map(function (l) { return '<p class="small">' + new Date(l.ts).toLocaleString() + ' \u00b7 ' + esc(l.status) + (l.message ? ' \u00b7 ' + esc(l.message) : '') + '</p>'; }).join('') : '') : '<p class="small muted">The database is available in the installed app.</p>') + '</div>';
    h += '<div class="banner">Automatic updates: once a feed is set, the app also checks about every 12 hours in the background (when the phone is online), even if the app is closed, and when you open the app. No personal data is sent.</div>';
    return { title: t('sync'), html: h };
  };
  AC.syncNow = function () { if (!A.bridge.syncNow(A.feedUrl(), false)) A.toast('Sync works in the installed app'); else A.toast('Checking\u2026'); };
  A.autoSync = function () { var url = A.feedUrl(); if (!url) return; var m = S.get('syncMeta', {}); if (!m.checked || Date.now() - m.checked > 12 * 3600 * 1000) A.bridge.syncNow(url, true); };

  /* ---------- settings ---------- */
  SC.settings = function () {
    var s = A.settings;
    function sel(id, opts, cur) { return '<select id="' + id + '">' + opts.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] == cur ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('') + '</select>'; }
    function chk(id, label, v) { return '<p><label style="color:var(--text)"><input type="checkbox" id="' + id + '"' + (v ? ' checked' : '') + '> ' + esc(label) + '</label></p>'; }
    var h = '<div class="card"><label>' + esc(t('language')) + '</label>' + sel('sLang', [['en', 'English'], ['ml', '\u0D2E\u0D32\u0D2F\u0D3E\u0D33\u0D02 (Malayalam)']], s.lang) + '<label>' + esc(t('theme')) + '</label>' + sel('sTheme', [['auto', 'Automatic'], ['light', 'Light'], ['dark', 'Dark'], ['sepia', 'Sepia']], s.theme) + '<label>' + esc(t('textsize')) + ' (<span id="fsv">' + Math.round(s.fs * 100) + '%</span>)</label><input type="range" id="sFs" min="0.8" max="1.8" step="0.1" value="' + s.fs + '"></div>';
    h += '<div class="card"><h3>Liturgical calendar (Roman Rite)</h3>' + chk('sEpi', 'Epiphany on the Sunday (Jan 2\u20138) instead of 6 January', s.epiphanySunday) + chk('sAsc', 'Ascension on the 7th Sunday of Easter instead of Thursday', s.ascensionSunday) + chk('sCorp', 'Corpus Christi on Sunday instead of Thursday', s.corpusSunday) + chk('sInd', 'Show Indian / Kerala saints', s.indianSaints) + '<p class="small muted">These transfers differ by country. Check your diocesan calendar.</p></div>';
    h += '<div class="card"><h3>Content feed</h3><label>Address of your content feed (https only)</label><input type="text" id="sFeed" placeholder="https://\u2026/manifest.json" value="' + esc(s.feedUrl) + '"></div><button class="btn block" data-act="setSave">' + esc(t('save')) + '</button><button class="btn danger block" style="margin-top:12px" data-act="wipe">Erase all data on this device</button>';
    return { title: t('settings'), html: h, after: function () { var fs = A.$('#sFs'); fs.addEventListener('input', function () { A.$('#fsv').textContent = Math.round(fs.value * 100) + '%'; document.documentElement.style.setProperty('--fs', fs.value); }); } };
  };
  AC.setSave = function () {
    var s = A.settings; s.lang = A.$('#sLang').value; s.theme = A.$('#sTheme').value; s.fs = +A.$('#sFs').value; s.epiphanySunday = A.$('#sEpi').checked; s.ascensionSunday = A.$('#sAsc').checked; s.corpusSunday = A.$('#sCorp').checked; s.indianSaints = A.$('#sInd').checked;
    var f = A.$('#sFeed').value.trim(); if (f && f.indexOf('https://') !== 0) { A.toast('The feed address must start with https://'); return; } s.feedUrl = A.normFeed(f);
    A.saveSettings(); A.bridge.setFeedUrl(A.feedUrl()); A.toast('\u2713 ' + t('saved')); A.root('me');
  };
  AC.wipe = function () { A.ask('Erase ALL notes, journal, progress and settings on this device? This cannot be undone.', function () { Object.keys(S.all()).forEach(function (k) { S.del(k); }); A.settings = Object.assign({}, { lang: 'en', theme: 'auto', fs: 1, epiphanySunday: false, ascensionSunday: false, corpusSunday: false, indianSaints: true, feedUrl: '', weeklyGoal: 5, streaksOn: true, weekStart: 0 }); A.applySettings(); A.root('home'); }, 'Erase'); };

  /* ---------- groups / family plan (local) ---------- */
  SC.groups = function () {
    var g = S.get('groups', []);
    return { title: t('groups'), html: '<div class="banner">Create a private family or prayer-group plan on this phone. Group members check in on the same device, or share the invitation text with others. No account or server is used.</div><div class="card"><label>Group name</label><input type="text" id="gn" placeholder="e.g. Family Rosary"><label>Members (comma separated)</label><input type="text" id="gm" placeholder="Mum, Dad, Anna"><button class="btn block" style="margin-top:8px" data-act="gAdd">Create group</button></div><div class="list">' + g.map(function (x) { return '<button class="item" data-act="go" data-arg="group" data-arg2="' + x.id + '"><b>' + esc(x.name) + '</b><span>' + esc(x.members.join(', ')) + '</span></button>'; }).join('') + '</div>' };
  };
  AC.gAdd = function () { var n = A.$('#gn').value.trim(), m = A.$('#gm').value.split(',').map(function (s) { return s.trim(); }).filter(Boolean); if (!n || !m.length) { A.toast('Add a name and members'); return; } var g = S.get('groups', []); g.push({ id: A.uid(), name: n, members: m, checks: {} }); S.set('groups', g); A.refresh(); };
  SC.group = function (id) {
    var g = S.get('groups', []).filter(function (x) { return x.id === id; })[0]; if (!g) return { html: '' }; var k = A.todayKey(), c = g.checks[k] || {};
    var h = '<div class="card"><h3>' + esc(g.name) + '</h3><p class="small muted">Today\u2019s check-in</p>' + g.members.map(function (m) { return '<button class="item" data-act="gCheck" data-id="' + id + '" data-m="' + esc(m) + '"><b>' + (c[m] ? '\u2611 ' : '\u2610 ') + esc(m) + '</b></button>'; }).join('') + '</div>';
    h += '<div class="row"><button class="btn" data-act="gInvite" data-id="' + id + '">Share invitation</button><button class="btn alt" data-act="go" data-arg="rosary">Pray the Rosary</button><button class="btn danger" data-act="gDel" data-id="' + id + '">Delete</button></div>';
    return { title: g.name, html: h };
  };
  AC.gCheck = function (el) { var g = S.get('groups', []), id = el.getAttribute('data-id'), m = el.getAttribute('data-m'), k = A.todayKey(); g.forEach(function (x) { if (x.id === id) { x.checks[k] = x.checks[k] || {}; x.checks[k][m] = !x.checks[k][m]; } }); S.set('groups', g); A.refresh(); };
  AC.gInvite = function (el) { var g = S.get('groups', []).filter(function (x) { return x.id === el.getAttribute('data-id'); })[0]; A.bridge.share('You\u2019re invited to pray with our group \u201C' + g.name + '\u201D. Let\u2019s pray together every day using the Rise With The Word app. \uD83D\uDE4F'); };
  AC.gDel = function (el) { var id = el.getAttribute('data-id'); A.ask('Delete this group?', function () { S.set('groups', S.get('groups', []).filter(function (x) { return x.id !== id; })); A.back(); }, 'Delete'); };

  /* ---------- parish ---------- */
  SC.parish = function () {
    var p = S.get('parish', {});
    function f(id, label, v, area) { return '<label>' + label + '</label>' + (area ? '<textarea id="' + id + '" style="min-height:80px">' + esc(v || '') + '</textarea>' : '<input type="text" id="' + id + '" value="' + esc(v || '') + '">'); }
    return { title: t('parish'), html: '<div class="banner">Keep your parish details on this phone: Mass times, office hours and announcements. Edit them whenever they change.</div><div class="card">' + f('pn', 'Parish name', p.name) + f('pd', 'Diocese / Eparchy', p.diocese) + f('pa', 'Address', p.address) + f('pp', 'Phone', p.phone) + f('pm', 'Mass and devotion times', p.times, true) + f('pnotes', 'Announcements', p.notes, true) + '<button class="btn block" style="margin-top:8px" data-act="parSave">' + esc(t('save')) + '</button><button class="btn alt block" style="margin-top:8px" data-act="parShare">' + esc(t('share')) + '</button></div>' };
  };
  AC.parSave = function () { S.set('parish', { name: A.$('#pn').value, diocese: A.$('#pd').value, address: A.$('#pa').value, phone: A.$('#pp').value, times: A.$('#pm').value, notes: A.$('#pnotes').value }); A.toast('\u2713 ' + t('saved')); };
  AC.parShare = function () { var p = S.get('parish', {}); A.bridge.share([p.name, p.diocese, p.address, p.phone, p.times, p.notes].filter(Boolean).join('\n')); };

  /* ---------- scripture cards ---------- */
  var cs = { style: 0, size: 'sq' };
  var STYLES = [['#4b2a6b', '#b8862b', '#ffffff'], ['#0f3d5e', '#2f9e8f', '#ffffff'], ['#fff5df', '#f0c987', '#2a2536'], ['#1b1b2f', '#162447', '#f1c76a']];
  SC.card = function (arg) {
    if (arg && arg.text) { cs.text = arg.text; cs.ref = arg.ref; }
    if (!cs.text) { var ref = A.verseOfDay(new Date()), r = W.Bible.ready ? W.Bible.resolve(ref) : null; cs.text = r && r.blocks[0] ? r.blocks[0].verses.map(function (v) { return v.t; }).join(' ') : 'Be still, and know that I am God.'; cs.ref = ref; }
    var h = '<div class="center"><canvas id="cv" width="1080" height="1080" style="width:100%"></canvas></div><div class="row" style="margin:10px 0">' + STYLES.map(function (s, i) { return '<button class="chip ' + (cs.style === i ? 'on' : '') + '" data-act="cdStyle" data-v="' + i + '">Style ' + (i + 1) + '</button>'; }).join('') + '<button class="chip ' + (cs.size === 'sq' ? 'on' : '') + '" data-act="cdSize" data-v="sq">Square</button><button class="chip ' + (cs.size === 'wall' ? 'on' : '') + '" data-act="cdSize" data-v="wall">Wallpaper</button></div><div class="row"><button class="btn" data-act="cdSave">Save to gallery</button><button class="btn alt" data-act="cdShare">' + esc(t('share')) + '</button></div>';
    return { title: t('cards'), html: h, after: drawCard };
  };
  function wrap(ctx, text, maxW) { var words = text.split(' '), lines = [], line = ''; words.forEach(function (w) { var test = line ? line + ' ' + w : w; if (ctx.measureText(test).width > maxW && line) { lines.push(line); line = w; } else line = test; }); if (line) lines.push(line); return lines; }
  function drawCard() {
    var cv = A.$('#cv'); if (!cv) return; var W2 = 1080, H2 = cs.size === 'wall' ? 1920 : 1080; cv.width = W2; cv.height = H2; var c = cv.getContext('2d'), st = STYLES[cs.style];
    var g = c.createLinearGradient(0, 0, W2, H2); g.addColorStop(0, st[0]); g.addColorStop(1, st[1]); c.fillStyle = g; c.fillRect(0, 0, W2, H2);
    c.fillStyle = st[2]; c.globalAlpha = 0.9; c.fillRect(W2 / 2 - 4, H2 * 0.12, 8, 70); c.fillRect(W2 / 2 - 30, H2 * 0.12 + 20, 60, 8); c.globalAlpha = 1;
    var size = 64, text = '\u201C' + cs.text + '\u201D'; var lines; do { c.font = 'italic ' + size + 'px Georgia, serif'; lines = wrap(c, text, W2 - 200); size -= 4; } while (lines.length * (size + 22) > H2 * 0.55 && size > 26);
    c.textAlign = 'center'; c.fillStyle = st[2]; var lh = size + 22, y = H2 / 2 - (lines.length * lh) / 2 + lh / 2; lines.forEach(function (l, i) { c.fillText(l, W2 / 2, y + i * lh); });
    c.font = 'bold 44px system-ui, sans-serif'; c.fillText('\u2014 ' + cs.ref, W2 / 2, y + lines.length * lh + 50);
    c.globalAlpha = 0.75; c.font = '34px system-ui, sans-serif'; c.fillText('Rise With The Word  \u00b7  @risewiththeword', W2 / 2, H2 - 70); c.globalAlpha = 1;
  }
  AC.cdStyle = function (el) { cs.style = +el.getAttribute('data-v'); A.refresh(); };
  AC.cdSize = function (el) { cs.size = el.getAttribute('data-v'); A.refresh(); };
  function b64() { return A.$('#cv').toDataURL('image/png').split(',')[1]; }
  AC.cdSave = function () { A.bridge.saveImage(b64(), 'scripture-card-' + Date.now() + '.png'); };
  AC.cdShare = function () { A.bridge.shareImage(b64(), 'scripture-card.png'); };

  /* ---------- privacy / about ---------- */
  SC.privacy = function () {
    var edition = (W.RWTW_FULL_BIBLE && W.RWTW_FULL_BIBLE.edition) || 'not bundled in this build';
    return { title: t('privacy'), html: '<div class="card"><h3>Your privacy</h3><ul><li>No account is required to read Scripture or pray.</li><li>Notes, journal, intentions, bookmarks and progress stay on your phone.</li><li>No advertising, no analytics and no tracking.</li><li>The app goes online only for Content Sync, and only if a feed address is set. Nothing personal is sent.</li><li>Use Backup to keep your data safe; use Settings to erase it.</li></ul></div><div class="card"><h3>' + esc(t('about')) + '</h3><p>Rise With The Word v' + A.version + '</p><p class="small muted">Bible text: ' + esc(edition) + '. Traditional prayers are in the public domain. Saints, calendar and Gospel tables are starter data \u2014 please verify against your diocesan ordo before relying on them for liturgical planning.</p><p class="small muted">Malayalam texts are a starting point and should be reviewed by a native speaker or your parish priest.</p></div>' };
  };
})();
