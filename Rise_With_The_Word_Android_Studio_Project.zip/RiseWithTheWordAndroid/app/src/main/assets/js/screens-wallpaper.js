/* Wallpaper Studio.
   - Generates phone wallpapers (9:16) in "Chibi" (Pixar-style, like the app's reference artwork) or "Epic" (cinematic painting) with Gemini.
   - The AI draws the artwork WITHOUT text; the title "RISE WITH THE WORD", the tagline and an optional verse are added by the app,
     so the lettering is always sharp and spelled correctly.
   - Two ready-made wallpapers are built in (they work offline). Generated artwork is saved in the built-in database.
   - Uses the same Gemini API key as the AI Assistant. */
(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, SC = A.screens, AC = A.actions, AB = W.AndroidBridge || null;
  var st = { style: 'chibi', source: 'story', storyId: 's1', custom: '', busy: null, edit: null };
  var BUILTIN = [['rwtw1', 'Heroes of the Bible'], ['rwtw2', 'The Sermon at Sunset']];

  function hasKey() { try { return !!(AB && AB.hasAiKey && AB.hasAiKey()); } catch (e) { return false; } }
  function useToday() { var u = S.get('imgUse', {}); return u.d === A.todayKey() ? u.n : 0; }
  function addUse() { S.set('imgUse', { d: A.todayKey(), n: useToday() + 1 }); }
  function limit() { return A.settings.imgLimit || 10; }

  /* ---------- prompts ---------- */
  var STYLE_TEXT = {
    chibi: 'Create a vertical 9:16 phone-wallpaper illustration in exactly the style of the reference images: adorable Pixar-style 3D chibi characters with large expressive eyes, soft glossy rendering, glowing golden-hour sunlight and a luminous sky, lush detailed scenery and warm cinematic colours.',
    epic: 'Create a vertical 9:16 epic cinematic painting for a phone wallpaper: dramatic volumetric light rays, rich colour, highly detailed realistic scenery and figures, majestic composition, painterly style inspired by classical sacred art and modern film concept art.'
  };
  function scene() {
    if (st.source === 'story') { var s = W.RWTW_STORIES.filter(function (x) { return x.id === st.storyId; })[0]; return s ? s.title + ' (' + s.ref + '): ' + s.summary : 'A peaceful sunrise over the Holy Land'; }
    if (st.source === 'saint') { var d = new Date(), l = W.Liturgy.saintsOn(d.getMonth() + 1, d.getDate()); return l.length ? 'Saint ' + l[0].name.replace(/^St\.? /, '') + ': ' + l[0].bio : 'A peaceful sunrise with a glowing cross'; }
    return st.custom.trim() || 'A peaceful sunrise over the Holy Land';
  }
  function titleOf() { if (st.source === 'story') { var s = W.RWTW_STORIES.filter(function (x) { return x.id === st.storyId; })[0]; return s ? s.title : 'Wallpaper'; } if (st.source === 'saint') return 'Saint of the day'; return (st.custom.trim() || 'Wallpaper').slice(0, 40); }
  function buildPrompt() {
    return STYLE_TEXT[st.style] + '\n\nScene: ' + scene() + '\n\nKeep the depiction reverent, faithful to the Bible account and family-friendly, with Jesus and holy figures shown with dignity and kindness; nothing graphic or frightening. Composition: leave the top third as calm open sky or uncluttered space for a title; place the main subjects in the lower two-thirds. Absolutely no text, letters, numbers, captions, logos or watermarks anywhere in the image.';
  }

  /* ---------- studio screen ---------- */
  SC.wallpaper = function () {
    var h = '<div class="banner">Turn Bible stories into phone wallpapers. Two ready-made wallpapers work offline; new ones are drawn by Gemini AI with your own API key.</div>';
    h += '<h3>Ready-made</h3><div class="grid">' + BUILTIN.map(function (b) { return '<button class="tile" style="padding:6px;min-height:0" data-act="wpBuiltin" data-id="' + b[0] + '"><img src="images/wallpapers/' + b[0] + '.jpg" alt="' + esc(b[1]) + '" style="width:100%;border-radius:12px;aspect-ratio:9/16;object-fit:cover"><b style="font-size:.85rem;padding:4px">' + esc(b[1]) + '</b></button>'; }).join('') + '</div>';
    h += '<h3 style="margin:16px 0 6px">Create with AI</h3>';
    if (!hasKey()) h += '<div class="card"><p>Add your free Google AI Studio key (starts with <span class="kbd">AIza</span>) to draw new wallpapers. It is stored only on this phone.</p><input type="password" id="wpKey" placeholder="AIza\u2026" autocomplete="off"><button class="btn block" data-act="wpKeySave">Save key</button></div>';
    else {
      h += '<div class="card"><label>Style</label><div class="row">' + [['chibi', '\uD83E\uDDF8 Chibi (cute 3D cartoon)'], ['epic', '\uD83C\uDFAC Epic (cinematic)']].map(function (x) { return '<button class="chip ' + (st.style === x[0] ? 'on' : '') + '" data-act="wpStyle" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>';
      h += '<label>Scene</label><div class="row">' + [['story', 'Bible story'], ['saint', 'Saint of the day'], ['custom', 'My idea']].map(function (x) { return '<button class="chip ' + (st.source === x[0] ? 'on' : '') + '" data-act="wpSource" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>';
      if (st.source === 'story') h += '<select id="wpStory" data-act="wpStoryPick">' + W.RWTW_STORIES.map(function (s) { return '<option value="' + s.id + '"' + (s.id === st.storyId ? ' selected' : '') + '>' + esc(s.title) + '</option>'; }).join('') + '</select>';
      if (st.source === 'custom') h += '<textarea id="wpCustom" placeholder="e.g. Jesus blessing children on a hill at sunrise, with a little lamb" style="min-height:80px">' + esc(st.custom) + '</textarea>';
      if (st.busy) h += '<p>\u23F3 Drawing your wallpaper in the background\u2026 usually 20\u201360 seconds. You can leave this screen.</p><button class="btn alt" data-act="wpCheck">Check again</button>';
      else h += '<button class="btn block" style="margin-top:8px" data-act="wpGenerate">\u2728 Create wallpaper</button><p class="small muted">Used today: ' + useToday() + '/' + limit() + '. Image creation can use your Google quota; availability of image models depends on your Google account and region. AI art can contain flaws: check it before sharing.</p>';
      h += '</div>';
    }
    h += '<h3 style="margin:16px 0 6px">My wallpapers</h3>' + galleryHtml();
    return { title: 'Wallpaper Studio', html: h };
  };
  function gallery() { try { return AB && AB.imgList ? JSON.parse(AB.imgList()) : []; } catch (e) { return []; } }
  function galleryHtml() {
    var g = gallery(); if (!g.length) return '<p class="muted small">Nothing yet. Create one above.</p>';
    return '<div class="grid">' + g.map(function (x) { return '<button class="tile" style="padding:6px;min-height:0" data-act="wpOpen" data-id="' + esc(x.id) + '"><img src="' + esc(x.thumb) + '" alt="" style="width:100%;border-radius:12px;aspect-ratio:9/16;object-fit:cover"><b style="font-size:.8rem;padding:4px">' + esc(x.title) + '</b></button>'; }).join('') + '</div>';
  }
  AC.wpKeySave = function () { var k = A.$('#wpKey').value.trim(); if (!/^AIza/.test(k)) { A.toast('A Gemini key starts with AIza'); return; } if (AB && AB.setAiKey) AB.setAiKey(k); A.toast('\u2713 Saved'); A.refresh(); };
  AC.wpStyle = function (el) { st.style = el.getAttribute('data-v'); A.refresh(); };
  AC.wpSource = function (el) { var c = A.$('#wpCustom'); if (c) st.custom = c.value; st.source = el.getAttribute('data-v'); A.refresh(); };
  document.addEventListener('change', function (e) { if (e.target && e.target.id === 'wpStory') st.storyId = e.target.value; });
  AC.wpCheck = function () { A.refresh(); };

  AC.wpGenerate = function () {
    var c = A.$('#wpCustom'); if (c) st.custom = c.value;
    if (st.source === 'custom' && !st.custom.trim()) { A.toast('Describe your idea first'); return; }
    if (useToday() >= limit()) { A.toast('Daily image limit reached'); return; }
    if (!AB || !AB.imageGenerate) { A.toast('Wallpaper creation works in the installed app'); return; }
    var job = 'w' + Date.now().toString(36); st.busy = { job: job, style: st.style, title: titleOf() }; addUse();
    if (A.settings.imgModel && AB.setImageModel) AB.setImageModel(A.settings.imgModel);
    AB.imageGenerate(job, buildPrompt(), st.style, '9:16'); A.toast('\u2728 Started in the background'); A.refresh();
  };

  W.onImageResult = function (json) {
    var r; try { r = JSON.parse(json); } catch (e) { return; }
    if (!st.busy || st.busy.job !== r.job) return;
    var meta = st.busy; st.busy = null;
    if (!r.ok) { A.toast('Could not create the image: ' + (r.error || 'error')); if (A.cur && A.cur.name === 'wallpaper') A.refresh(); return; }
    var url = 'data:' + (r.mime || 'image/png') + ';base64,' + r.data, im = new Image();
    im.onload = function () {
      var id = 'g' + Date.now().toString(36), cv = document.createElement('canvas'); cv.width = im.width; cv.height = im.height; cv.getContext('2d').drawImage(im, 0, 0);
      var jpeg = cv.toDataURL('image/jpeg', 0.92), th = document.createElement('canvas'); th.width = 180; th.height = Math.round(180 * im.height / im.width); th.getContext('2d').drawImage(im, 0, 0, th.width, th.height);
      if (AB && AB.imgSave) AB.imgSave(id, meta.title, meta.style, th.toDataURL('image/jpeg', 0.7), jpeg.split(',')[1]);
      A.mark('read'); A.toast('\u2728 Your wallpaper is ready');
      openEditor({ id: id, title: meta.title, style: meta.style, img: jpeg, overlay: true });
    };
    im.onerror = function () { A.toast('The image could not be read'); };
    im.src = url;
  };

  AC.wpBuiltin = function (el) {
    var id = el.getAttribute('data-id'), b64 = AB && AB.assetBase64 ? AB.assetBase64('images/wallpapers/' + id + '.jpg') : '';
    if (!b64) { A.toast('Wallpapers open in the installed app'); return; }
    var t = BUILTIN.filter(function (x) { return x[0] === id; })[0][1];
    openEditor({ id: id, title: t, style: 'built-in', img: 'data:image/jpeg;base64,' + b64, overlay: false, builtin: true });
  };
  AC.wpOpen = function (el) {
    var id = el.getAttribute('data-id'), g = gallery().filter(function (x) { return x.id === id; })[0], b64 = AB && AB.imgGet ? AB.imgGet(id) : '';
    if (!b64) { A.toast('Could not open this image'); return; }
    openEditor({ id: id, title: g ? g.title : 'Wallpaper', style: g ? g.style : '', img: 'data:image/jpeg;base64,' + b64, overlay: true });
  };
  function openEditor(o) { st.edit = Object.assign({ pos: 'top', color: 'gold', verse: '', ref: '' }, o); A.go('wpEdit'); }

  /* ---------- editor ---------- */
  SC.wpEdit = function () {
    var e = st.edit; if (!e) return { html: '' };
    var h = '<div class="center"><canvas id="wpCv" width="1080" height="1920" style="width:70%"></canvas></div>';
    h += '<div class="card" style="margin-top:10px"><label style="color:var(--text)"><input type="checkbox" id="wpOv"' + (e.overlay ? ' checked' : '') + '> Add the title \u201CRISE WITH THE WORD\u201D</label>' +
      '<div class="row" style="margin:6px 0">' + [['top', 'Top'], ['center', 'Middle'], ['bottom', 'Bottom']].map(function (x) { return '<button class="chip ' + (e.pos === x[0] ? 'on' : '') + '" data-act="wpPos" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + [['gold', 'Gold'], ['white', 'White']].map(function (x) { return '<button class="chip ' + (e.color === x[0] ? 'on' : '') + '" data-act="wpColor" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<label>Verse or message on the wallpaper (optional)</label><textarea id="wpVerse" style="min-height:70px" placeholder="Type a verse or use the verse of the day">' + esc(e.verse) + '</textarea><input type="text" id="wpRef" placeholder="Reference, e.g. John 3:16" value="' + esc(e.ref) + '"><div class="row"><button class="btn alt" data-act="wpVod">Use verse of the day</button><button class="btn alt" data-act="wpRedraw">Update preview</button></div></div>';
    h += '<div class="row"><button class="btn" data-act="wpSet" data-t="home">Set as home screen</button><button class="btn" data-act="wpSet" data-t="lock">Set as lock screen</button><button class="btn" data-act="wpSet" data-t="both">Set for both</button></div><div class="row" style="margin-top:8px"><button class="btn alt" data-act="wpSave">Save to gallery</button><button class="btn alt" data-act="wpShare">Share</button>' + (e.builtin ? '' : '<button class="btn danger" data-act="wpDel">Delete</button>') + '</div>';
    return { title: e.title, html: h, after: function () { var ov = A.$('#wpOv'); ov.addEventListener('change', function () { e.overlay = ov.checked; draw(); }); draw(); } };
  };
  function syncFields() { var e = st.edit, v = A.$('#wpVerse'), r = A.$('#wpRef'); if (v) e.verse = v.value; if (r) e.ref = r.value; }
  AC.wpPos = function (el) { syncFields(); st.edit.pos = el.getAttribute('data-v'); A.refresh(); };
  AC.wpColor = function (el) { syncFields(); st.edit.color = el.getAttribute('data-v'); A.refresh(); };
  AC.wpRedraw = function () { syncFields(); draw(); };
  AC.wpVod = function () { var ref = A.verseOfDay(new Date()), r = W.Bible && W.Bible.ready ? W.Bible.resolve(ref) : null; st.edit.verse = r && r.blocks[0] ? r.blocks[0].verses.map(function (v) { return v.t; }).join(' ') : ''; st.edit.ref = ref; A.refresh(); };

  function spaced(c, text, cx, y, sp) { var w = 0, i, ws = []; for (i = 0; i < text.length; i++) { ws.push(c.measureText(text[i]).width); w += ws[i] + sp; } w -= sp; var x = cx - w / 2; c.textAlign = 'left'; for (i = 0; i < text.length; i++) { c.fillText(text[i], x, y); x += ws[i] + sp; } c.textAlign = 'center'; }
  function wrap(c, text, maxW) { var words = text.split(' '), lines = [], line = ''; words.forEach(function (w) { var t = line ? line + ' ' + w : w; if (c.measureText(t).width > maxW && line) { lines.push(line); line = w; } else line = t; }); if (line) lines.push(line); return lines; }

  function draw() {
    var e = st.edit, cv = A.$('#wpCv'); if (!e || !cv) return; var W2 = 1080, H2 = 1920, c = cv.getContext('2d'), im = new Image();
    im.onload = function () {
      c.clearRect(0, 0, W2, H2); var s = Math.max(W2 / im.width, H2 / im.height), w = im.width * s, h = im.height * s; c.drawImage(im, (W2 - w) / 2, (H2 - h) / 2, w, h);
      var gold = e.color === 'gold', serif = 'Georgia, "Times New Roman", serif', so = A.social ? A.social() : { tagline: 'EVERY DAY WITH GOD\u2019S WORD', youtube: { handle: '@risewiththeword' } };
      var cy = e.pos === 'top' ? 330 : e.pos === 'center' ? 940 : 1450;
      if (e.overlay) {
        var g = c.createRadialGradient(W2 / 2, cy, 40, W2 / 2, cy, 520); g.addColorStop(0, 'rgba(10,8,30,0.45)'); g.addColorStop(1, 'rgba(10,8,30,0)'); c.fillStyle = g; c.fillRect(0, cy - 520, W2, 1040);
        c.textAlign = 'center'; c.shadowColor = 'rgba(0,0,0,0.55)'; c.shadowBlur = 18; c.shadowOffsetY = 4;
        c.font = '600 56px ' + serif; c.fillStyle = gold ? '#f6e3b0' : '#ffffff'; spaced(c, 'RISE WITH', W2 / 2, cy - 70, 16);
        c.font = '800 168px ' + serif; var tg = c.createLinearGradient(0, cy - 60, 0, cy + 90); if (gold) { tg.addColorStop(0, '#ffe9a6'); tg.addColorStop(0.5, '#e8b84a'); tg.addColorStop(1, '#a8741c'); } else { tg.addColorStop(0, '#ffffff'); tg.addColorStop(1, '#e8e4f4'); } c.fillStyle = tg; c.fillText('THE WORD', W2 / 2, cy + 85);
        c.shadowBlur = 8; c.strokeStyle = gold ? '#e8b84a' : '#ffffff'; c.lineWidth = 3; c.beginPath(); c.moveTo(210, cy + 150); c.lineTo(500, cy + 150); c.moveTo(580, cy + 150); c.lineTo(870, cy + 150); c.stroke();
        c.fillStyle = gold ? '#e8b84a' : '#ffffff'; c.fillRect(538, cy + 118, 5, 64); c.fillRect(522, cy + 134, 37, 5);
        c.font = '500 36px ' + serif; c.fillStyle = gold ? '#f6e3b0' : '#ffffff'; spaced(c, (so.tagline || 'EVERY DAY WITH GOD\u2019S WORD').toUpperCase(), W2 / 2, cy + 240, 8);
        c.shadowColor = 'transparent';
      }
      if (e.verse && e.verse.trim()) {
        var vy = e.pos === 'bottom' ? 560 : 1380; c.shadowColor = 'rgba(0,0,0,0.7)'; c.shadowBlur = 24; c.fillStyle = '#ffffff'; c.textAlign = 'center';
        var size = 58, lines; do { c.font = 'italic ' + size + 'px ' + serif; lines = wrap(c, '\u201C' + e.verse.trim() + '\u201D', 880); size -= 3; } while (lines.length * (size + 22) > 420 && size > 28);
        var bandTop = vy - size - 30, bandH = lines.length * (size + 22) + (e.ref ? 110 : 50), bg = c.createLinearGradient(0, bandTop, 0, bandTop + bandH); bg.addColorStop(0, 'rgba(10,8,30,0)'); bg.addColorStop(0.2, 'rgba(10,8,30,0.5)'); bg.addColorStop(0.8, 'rgba(10,8,30,0.5)'); bg.addColorStop(1, 'rgba(10,8,30,0)'); c.save(); c.shadowColor = 'transparent'; c.fillStyle = bg; c.fillRect(0, bandTop, W2, bandH); c.restore();
        lines.forEach(function (l, i) { c.fillText(l, W2 / 2, vy + i * (size + 22)); });
        if (e.ref) { c.font = 'bold 40px ' + serif; c.fillStyle = gold ? '#f6e3b0' : '#ffffff'; c.fillText('\u2014 ' + e.ref, W2 / 2, vy + lines.length * (size + 22) + 30); }
        c.shadowColor = 'transparent';
      }
    };
    im.src = e.img;
  }
  function out() { syncFields(); return A.$('#wpCv').toDataURL('image/jpeg', 0.92).split(',')[1]; }
  AC.wpSet = function (el) { var b = out(); if (AB && AB.setWallpaper) AB.setWallpaper(b, el.getAttribute('data-t')); else A.toast('Setting wallpapers works in the installed app'); };
  AC.wpSave = function () { A.bridge.saveImage(out(), 'rise-wallpaper-' + Date.now() + '.jpg'); };
  AC.wpShare = function () { A.bridge.shareImage(out(), 'rise-wallpaper.jpg'); };
  AC.wpDel = function () { var e = st.edit; A.ask('Delete this wallpaper from the gallery?', function () { if (AB && AB.imgDelete) AB.imgDelete(e.id); A.back(); }, 'Delete'); };

  /* ---------- entry points ---------- */
  function addTile(name, tile) { var o0 = SC[name]; SC[name] = function () { var o = o0.apply(null, arguments), i = o.html.lastIndexOf('</div>'); o.html = o.html.slice(0, i) + tile + o.html.slice(i); return o; }; }
  var tileHtml = '<button class="tile" data-act="go" data-arg="wallpaper"><span class="ico">\uD83D\uDDBC\uFE0F</span><b>Wallpaper Studio</b><span>Epic &amp; chibi phone wallpapers</span></button>';
  addTile('discover', tileHtml); addTile('me', tileHtml);
  var oCard = SC.card;
  SC.card = function (arg) { var o = oCard(arg); o.html += '<button class="btn alt block" style="margin-top:10px" data-act="go" data-arg="wallpaper">\uD83D\uDDBC\uFE0F Make an AI wallpaper instead</button>'; return o; };
  var oSettings = SC.settings;
  SC.settings = function () { var o = oSettings(); o.html += '<div class="card"><h3>Wallpaper images</h3><label>Image model</label><input type="text" id="imgModel" value="' + esc(A.settings.imgModel || 'gemini-2.5-flash-image') + '"><label>Daily limit (images)</label><select id="imgLimit">' + [3, 5, 10, 20].map(function (n) { return '<option' + (n === limit() ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select><button class="btn" data-act="imgSave">Save</button></div>'; return o; };
  AC.imgSave = function () { A.settings.imgModel = A.$('#imgModel').value.trim() || 'gemini-2.5-flash-image'; A.settings.imgLimit = +A.$('#imgLimit').value; A.saveSettings(); if (AB && AB.setImageModel) AB.setImageModel(A.settings.imgModel); A.toast('\u2713 Saved'); };
})();
