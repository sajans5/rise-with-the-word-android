/* Internet features.
   - Ask the web: Gemini with Google Search grounding answers any question the Catholic way, with sources; answers are saved for offline reading.
   - Trusted Catholic websites open inside the app (a protected viewer that allows only a short, fixed list).
   - Automatic content: the app queues a daily reflection, a saint profile and Church news for the coming days; Android writes them in the
     background (even when the app is closed) into the built-in database. No one has to add content by hand. */
(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, SC = A.screens, AC = A.actions, AB = W.AndroidBridge || null, AI = A.ai, Lit = W.Liturgy;

  function hash(s) { var h = 0; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h).toString(36); }
  function lang() { return A.settings.lang === 'ml' ? 'ml' : 'en'; }
  function stripPrayer(s) { return s.replace('7. Format as Markdown: ## section headings, short paragraphs, "- " bullets where useful. End with a short prayer.', '7. Format as Markdown: ## section headings, short paragraphs, "- " bullets where useful.'); }

  /* ---------- prompts ---------- */
  AI.BUILD.ask = function (id, words) {
    var q = (S.get('askq', {}) || {})[id]; if (!q) return null;
    var extra = '\n\nYou are answering a question from a user of a Catholic app, often in India. Answer as a faithful teacher of the Roman Catholic Church. Use Scripture and the Catechism of the Catholic Church, and cite only references you are sure of. ' +
      'Where Eastern Catholic (Syro-Malabar, Syro-Malankara) practice or Indian customs differ, say so. Separate doctrine, Church discipline and pious opinion. Be kind and clear. Politely correct wrong premises. ' +
      'If the question shows personal distress, respond with compassion and encourage talking to a priest or a counsellor; if self-harm is mentioned, include: in India call 112 or Tele-MANAS 14416, elsewhere your local emergency number. ' +
      'Give general information only for medical or legal matters. Structure: ## Short Answer; ## What the Bible Says; ## What the Church Teaches; ## In Daily Life; ## Where to Learn More (name the sources, such as the Catechism numbers or official Church websites).';
    return { title: q, words: 500, instr: stripPrayer(AI.SYSTEM(500)) + extra, input: 'Question: ' + q };
  };
  AI.BUILD.news = function (id) {
    var d = A.dateFromKey(id);
    var extra = '\n\nTask: Church news digest. Use Google Search to find the most important Catholic Church news from the last 24 hours. Prefer Vatican News, Catholic News Agency, UCA News, Crux, and Indian Catholic sources (CBCI, Syro-Malabar and Syro-Malankara Churches). ' +
      'List 5 or 6 items. For each: a bold headline, a 2 to 3 sentence neutral summary, and the source name and date. Include at least one India item if reliable news exists. Do not give opinions or take political sides. If you cannot find reliable recent news, say so plainly and do not invent anything.';
    return { title: 'Church news \u00b7 ' + Lit.fullName(d), words: 500, instr: stripPrayer(AI.SYSTEM(500)) + extra, input: 'Today is ' + Lit.fullName(d) + '. Write the Church news digest.' };
  };

  /* ---------- Ask the web ---------- */
  var showKey = null;
  var EXAMPLES = ['Why do Catholics pray the Rosary?', 'What is the meaning of Lent?', 'How do I prepare for Confession?', 'Who was St Alphonsa?', 'Is cremation allowed for Catholics?', 'How can I read the Bible daily?'];
  function pendingFor(k) { var p = S.get('aiPending', {}); return Object.keys(p).some(function (j) { return p[j].k === k; }); }
  SC.ask = function (arg) {
    var all = A.aiStore.all(), pre = (arg && arg.q) || A._askPrefill || ''; A._askPrefill = '';
    var h = '<div class="banner">\uD83C\uDF10 Ask any question about the faith, the Bible, saints, prayer or life. The app searches the internet with Google and writes a Catholic answer with sources. Answers are saved to read offline.</div>';
    if (!AI.hasKey()) {
      h += '<div class="card"><h3>Switch on internet search (free)</h3><ol class="steps"><li>On any phone browser open <b>aistudio.google.com</b> and sign in with a Google account.</li><li>Tap <b>Get API key</b> \u2192 <b>Create API key</b> and copy it (it starts with <span class="kbd">AIza</span>).</li><li>Paste it below. It stays only on this phone.</li></ol><input type="password" id="wkKey" placeholder="AIza\u2026" autocomplete="off"><button class="btn block" data-act="wkKeySave">Save key</button></div>' +
        '<p class="muted small">Meanwhile you can search the built-in answers:</p><button class="btn alt block" data-act="go" data-arg="faq">\uD83D\uDCAC Ask & Answer (works offline)</button>';
    } else {
      h += '<textarea id="askq" placeholder="Type your question\u2026" style="min-height:90px">' + esc(pre) + '</textarea><div class="row" style="margin:4px 0 8px">' + EXAMPLES.map(function (e) { return '<button class="chip" data-act="askEx" data-q="' + esc(e) + '">' + esc(e) + '</button>'; }).join('') + '</div>' +
        '<p><label style="color:var(--text)"><input type="checkbox" id="askSearch"' + (A.settings.aiSearch !== false ? ' checked' : '') + '> Search the internet with Google</label></p><button class="btn block" data-act="webAsk">\uD83D\uDD0D Ask</button>';
      var shown = showKey && all[showKey] ? showKey : null;
      if (!shown) { var keys = Object.keys(all).filter(function (k) { return k.indexOf('ask:') === 0; }); keys.forEach(function (k) { if (pendingFor(k)) h += '<div class="banner">\u23F3 Searching and writing your answer\u2026 usually 20\u201360 seconds. You can leave this screen.</div>'; }); var p = S.get('aiPending', {}); if (Object.keys(p).some(function (j) { return p[j].kind === 'ask'; })) h += '<div class="banner">\u23F3 Searching and writing your answer\u2026 usually 20\u201360 seconds. You can leave this screen; it will be saved.</div>'; }
      if (shown) h += '<h3 style="margin:14px 0 4px">' + esc(all[shown].title) + '</h3>' + AI.view(shown, all[shown]);
      var recent = Object.keys(all).filter(function (k) { return k.indexOf('ask:') === 0; }).sort(function (a, b) { return all[b].ts - all[a].ts; }).slice(0, 12);
      if (recent.length) h += '<h3 style="margin:14px 0 6px">My questions</h3><div class="list">' + recent.map(function (k) { return '<button class="item" data-act="askOpen" data-k="' + esc(k) + '"><b>' + esc(all[k].title) + '</b><span>' + new Date(all[k].ts).toLocaleDateString() + '</span></button>'; }).join('') + '</div>';
    }
    return { title: 'Ask the Web', html: h };
  };
  AC.wkKeySave = function () { var k = A.$('#wkKey').value.trim(); if (!/^AIza/.test(k)) { A.toast('A Gemini key starts with AIza'); return; } if (AB && AB.setAiKey) AB.setAiKey(k); A.toast('\u2713 Saved'); setTimeout(function () { A.autoPlan(); }, 500); A.refresh(); };
  AC.askEx = function (el) { var t = A.$('#askq'); if (t) t.value = el.getAttribute('data-q'); };
  AC.askFrom = function (el) { A._askPrefill = el.getAttribute('data-q'); A.go('ask'); };
  AC.askOpen = function (el) { showKey = el.getAttribute('data-k'); A.refresh(); };
  AC.webAsk = function () {
    var q = A.$('#askq').value.trim(); if (q.length < 6) { A.toast('Please type your question'); return; }
    A.settings.aiSearch = A.$('#askSearch').checked; A.saveSettings();
    var id = hash(q), m = S.get('askq', {}); m[id] = q; S.set('askq', m); showKey = null;
    AC.aiExpand({ getAttribute: function (n) { return n === 'data-kind' ? 'ask' : n === 'data-id' ? id : ''; } });
  };

  /* ---------- Church news ---------- */
  SC.news = function (key) {
    key = key || A.todayKey();
    var h = AI.card('news', key, 'Get today\u2019s Church news');
    if (!AI.hasKey()) h = '<div class="banner">Church news needs internet search. Add your free Gemini key in <b>Ask the Web</b>.</div><button class="btn block" data-act="go" data-arg="ask">\uD83C\uDF10 Ask the Web</button>';
    h += '<button class="btn alt block" style="margin-top:10px" data-act="go" data-arg="sites">\uD83C\uDF0D Trusted Catholic websites</button>';
    return { title: 'Today in the Church', html: h };
  };

  /* ---------- trusted websites ---------- */
  var SITES = [['Vatican', 'https://www.vatican.va/content/vatican/en.html', 'The Holy See: documents, popes and the Bible'], ['Catechism of the Catholic Church', 'https://www.vatican.va/archive/ENG0015/_INDEX.HTM', 'Read the Catechism online'], ['Vatican News', 'https://www.vaticannews.va/en.html', 'Daily news from the Vatican'],
    ['USCCB \u2013 Daily Readings', 'https://bible.usccb.org/daily-bible-reading', 'Mass readings (US bishops)'], ['New Advent', 'https://www.newadvent.org/', 'Catholic Encyclopedia and Church Fathers'], ['EWTN', 'https://www.ewtn.com/', 'Catholic television and radio'],
    ['Catholic Answers', 'https://www.catholic.com/', 'Answers to questions about the faith'], ['CBCI \u2013 Catholic Bishops\u2019 Conference of India', 'https://cbci.in/', 'News from the Church in India'], ['Franciscan Media \u2013 Saint of the Day', 'https://www.franciscanmedia.org/saint-of-the-day/', 'Daily saint stories'],
    ['Aleteia', 'https://aleteia.org/', 'Catholic news and spirituality'], ['Wikipedia', 'https://en.wikipedia.org/', 'General knowledge']];
  SC.sites = function () {
    return { title: 'Trusted Catholic Websites', html: '<div class="banner">These websites open inside the app. Only this fixed list is allowed, for your safety. Needs an internet connection.</div><div class="list">' + SITES.map(function (s, i) { return '<button class="item" data-act="siteOpen" data-i="' + i + '"><b>\uD83C\uDF10 ' + esc(s[0]) + '</b><span>' + esc(s[2]) + '</span></button>'; }).join('') + '</div>' };
  };
  AC.siteOpen = function (el) { var s = SITES[+el.getAttribute('data-i')]; if (AB && AB.openTrusted) AB.openTrusted(s[1], s[0]); else A.toast('Websites open inside the installed app'); };

  /* ---------- automatic content ---------- */
  function autoOn() { return AI.hasKey() && A.settings.autoContent !== false; }
  A.autoPlan = function () {
    if (!AB || !AB.autoQueue) return;
    if (AB.setAutoContent) AB.setAutoContent(autoOn());
    if (!autoOn()) return;
    var all = A.aiStore.all(), items = [], L = lang(), d0 = new Date(); d0.setHours(12);
    function add(kind, id, k) { if (all[k]) return; var b = AI.BUILD[kind](id, 500); if (b) items.push({ k: k, title: b.title, instr: b.instr, input: b.input, max: 2500, search: A.settings.aiSearch !== false }); }
    for (var i = 0; i < 4; i++) {
      var dt = Lit.add(d0, i), key = Lit.key(dt);
      add('day', key, 'day:' + key + ':' + L);
      var sl = Lit.saintsOn(dt.getMonth() + 1, dt.getDate()).filter(function (s) { return A.settings.indianSaints || s.rank !== 'L'; });
      if (sl.length) add('saint', sl[0].md + '|' + sl[0].name, 'saint:' + sl[0].md + '|' + sl[0].name + ':' + L);
      if (i === 0) add('news', key, 'news:' + key + ':' + L);
    }
    if (items.length) { AB.autoQueue(JSON.stringify(items)); }
    if (AB.autoRunNow) AB.autoRunNow();
  };
  W.onAutoDone = function (n) { A.toast('\u2728 ' + n + ' new item(s) written for you'); if (A.cur && ['home', 'today', 'saints', 'news', 'ask'].indexOf(A.cur.name) >= 0) A.refresh(); };
  A.autoStatus = function () { try { return AB && AB.autoStatus ? JSON.parse(AB.autoStatus()) : null; } catch (e) { return null; } };

  var oSettings = SC.settings;
  SC.settings = function () {
    var o = oSettings(), st = A.autoStatus();
    o.html = o.html.replace('<div class="card"><label>', '<div class="card"><h3>\uD83C\uDF10 Internet & automatic content</h3><p class="small muted">With a free Gemini key the app searches the internet and writes new daily content by itself: a reflection for each day, the saint of the day, and Church news. It is saved for offline reading.</p>' +
      '<p><label style="color:var(--text)"><input type="checkbox" id="autoOn"' + (A.settings.autoContent !== false ? ' checked' : '') + '> Write new content automatically</label></p>' +
      '<p class="small">' + (AI.hasKey() ? '\u2713 Gemini key saved' : '\u26A0 No key yet') + (st ? ' \u00b7 ' + st.pending + ' item(s) waiting' : '') + '</p><div class="row"><button class="btn" data-act="autoSave">Save</button><button class="btn alt" data-act="autoNow">Write now</button><button class="btn alt" data-act="go" data-arg="ask">Add key / Ask the web</button></div></div><div class="card"><label>');
    return o;
  };
  AC.autoSave = function () { A.settings.autoContent = A.$('#autoOn').checked; A.saveSettings(); A.autoPlan(); A.toast('\u2713 Saved'); };
  AC.autoNow = function () { if (!AI.hasKey()) { A.toast('Add your Gemini key first'); return; } A.settings.autoContent = true; A.saveSettings(); S.set('autoPlanned', 0); A.autoPlan(); A.toast('Working in the background\u2026'); };
  setTimeout(function () { var last = S.get('autoPlanned', 0); if (Date.now() - last > 3600 * 1000) { S.set('autoPlanned', Date.now()); A.autoPlan(); } }, 4000);

  /* make results refresh the new screens */
  var oR = W.onAiResult; W.onAiResult = function (j) { oR(j); try { var r = typeof j === 'string' ? JSON.parse(j) : j; if (r.ok && A.cur && ['ask', 'news', 'home'].indexOf(A.cur.name) >= 0) A.refresh(); } catch (e) {} };
})();
