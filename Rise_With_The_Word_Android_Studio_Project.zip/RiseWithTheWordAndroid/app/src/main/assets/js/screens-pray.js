(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, t = A.t, PR = W.RWTW_PRAYERS, P = PR.prayers;
  var SC = A.screens, AC = A.actions;

  function tile(ico, title, sub, act, arg, arg2) { return '<button class="tile" data-act="' + act + '" data-arg="' + arg + '"' + (arg2 ? ' data-arg2="' + arg2 + '"' : '') + '><span class="ico">' + ico + '</span><b>' + esc(title) + '</b><span>' + esc(sub) + '</span></button>'; }

  SC.pray = function () {
    var h = '<div class="grid">' +
      tile('\uD83D\uDCFF', t('rosary'), A.rosaryToday().name, 'go', 'rosary') + tile('\u2764\uFE0F', t('mercy'), 'Chaplet', 'go', 'mercy') +
      tile('\uD83D\uDCD6', t('prayers'), 'Traditional prayers', 'go', 'prayers') + tile('\uD83D\uDD6F\uFE0F', t('litanies'), 'Loreto, St Joseph\u2026', 'go', 'litanies') +
      tile('\uD83D\uDCC5', t('novenas'), 'Nine-day prayers', 'go', 'novenas') + tile('\u271D\uFE0F', t('stations'), '14 stations', 'go', 'stations') +
      tile('\uD83C\uDF05', t('morning'), t('routines'), 'go', 'routine', 'morning') + tile('\uD83C\uDF19', t('evening'), t('routines'), 'go', 'routine', 'evening') +
      tile('\uD83D\uDE34', t('sleep'), 'Peaceful night prayers', 'go', 'routine', 'sleep') + tile('\u23F1\uFE0F', t('timer'), 'Silent & guided', 'go', 'timer') + '</div>';
    return { title: t('pray'), html: h };
  };

  /* ---------- guided stepper ---------- */
  function startGuided(kind, steps, title, extra) { A.step = { kind: kind, steps: steps, i: 0, title: title, extra: extra || {} }; A.go('guided'); }
  function stepText(s) { if (s.p) return A.L(P[s.p], 'text'); return s.text || ''; }
  SC.guided = function () {
    var g = A.step; if (!g) return { html: '' };
    var s = g.steps[g.i], n = g.steps.length;
    var h = '<div class="progress"><i style="width:' + Math.round(100 * (g.i + 1) / n) + '%"></i></div><p class="small muted">' + (g.i + 1) + ' / ' + n + '</p>';
    h += '<div class="card"><h3>' + esc(s.h) + '</h3>';
    if (s.dec) { h += '<div class="bead">' + (function () { var x = ''; for (var k = 1; k <= 10; k++) x += '<i class="' + (s.bead && k <= s.bead ? 'f' : '') + '"></i>'; return x; })() + '</div>'; }
    if (s.mystery && s.dec) h += '<p class="small muted">' + esc(s.mystery[0]) + ' \u00b7 ' + esc(s.mystery[1]) + '</p>';
    if (s.note) h += '<p class="muted small">' + esc(s.note) + '</p>';
    h += '<p class="prayer-text">' + esc(stepText(s)) + '</p>';
    if (s.refrain) h += '<p class="prayer-text muted">' + esc(s.refrain) + '</p>';
    h += '</div>';
    h += '<div class="row sp"><button class="btn alt" data-act="gPrev"' + (g.i === 0 ? ' disabled' : '') + '>\u2190 ' + esc(t('prev')) + '</button>' + (g.i < n - 1 ? '<button class="btn" data-act="gNext">' + esc(t('next')) + ' \u2192</button>' : '<button class="btn" data-act="gDone">\u2713 Amen</button>') + '</div>';
    A.onBackHook = null;
    return { title: g.title, html: h };
  };
  AC.gNext = function () { A.step.i++; A.bridge.vibrate(); A.refresh(); };
  AC.gPrev = function () { if (A.step.i > 0) A.step.i--; A.refresh(); };
  AC.gDone = function () { A.mark('prayer'); A.toast('\u2713 ' + t('saved')); A.back(); };

  /* ---------- rosary ---------- */
  SC.rosary = function () {
    var today = A.rosaryToday(), M = PR.mysteries;
    var h = '<div class="banner">Today (' + ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date().getDay()] + ') the traditional mysteries are the <b>' + esc(today.name) + '</b>.</div><div class="list">';
    Object.keys(M).forEach(function (k) { h += '<button class="item" data-act="rosaryStart" data-set="' + k + '"><b>' + esc(A.L(M[k], 'name')) + (k === today.id ? ' \u2022 ' + esc(t('today')) : '') + '</b><span>' + M[k].list.map(function (x) { return x[0]; }).join(' \u00b7 ') + '</span></button>'; });
    h += '</div><p class="small muted">Tap Next after each prayer. The bead counter shows your place in each decade.</p>';
    return { title: t('rosary'), html: h };
  };
  AC.rosaryStart = function (el) { var set = el.getAttribute('data-set'); A.recent('rosary', set, A.L(PR.mysteries[set], 'name')); startGuided('rosary', PR.rosarySteps(set), A.L(PR.mysteries[set], 'name')); };
  SC.mercy = function () {
    var m = PR.mercy;
    return { title: t('mercy'), html: '<div class="card"><p>' + esc(m.intro) + '</p></div><button class="btn block" data-act="mercyStart">Begin the Chaplet</button><div class="card" style="margin-top:12px"><h3>Prayer</h3><p class="prayer-text">' + esc(m.big) + '\n\n' + esc(m.small) + '</p></div>' };
  };
  AC.mercyStart = function () { startGuided('mercy', PR.mercySteps(), t('mercy')); };

  /* ---------- prayers ---------- */
  SC.prayers = function () {
    var fav = S.get('fav', []);
    var h = '<div class="list">' + PR.order.map(function (id) { var p = P[id]; return '<button class="item" data-act="openPrayer" data-id="' + id + '"><b>' + esc(A.L(p, 'title')) + (fav.some(function (f) { return f.id === id; }) ? ' \u2605' : '') + '</b><span>' + esc(p.text.slice(0, 70)) + '\u2026</span></button>'; }).join('') + '</div>';
    return { title: t('prayers'), html: h };
  };
  AC.openPrayer = function (el) { A.go('prayer', el.getAttribute('data-id')); };
  SC.prayer = function (id) {
    var p = P[id]; A.recent('prayer', id, p.title); var fav = S.get('fav', []).some(function (f) { return f.id === id; });
    var h = '<div class="card"><p class="prayer-text">' + esc(A.L(p, 'text')) + '</p></div><div class="row"><button class="btn" data-act="prayerDone" data-id="' + id + '">\u2713 I prayed this</button><button class="btn alt" data-act="favToggle" data-type="prayer" data-id="' + id + '" data-title="' + esc(p.title) + '">' + (fav ? '\u2605' : '\u2606') + ' ' + esc(t('favorites')) + '</button><button class="btn alt" data-act="prayerShare" data-id="' + id + '">' + esc(t('share')) + '</button></div>';
    if (A.settings.lang === 'ml' && !p.text_ml) h += '<p class="small muted">Malayalam text for this prayer will be added through content updates.</p>';
    return { title: A.L(p, 'title'), html: h };
  };
  AC.prayerDone = function () { A.mark('prayer'); A.toast('\u2713'); };
  AC.prayerShare = function (el) { var p = P[el.getAttribute('data-id')]; A.bridge.share(p.title + '\n\n' + A.L(p, 'text') + '\n\nRise With The Word'); };
  AC.favToggle = function (el) { var fav = S.get('fav', []), id = el.getAttribute('data-id'), i = fav.findIndex(function (f) { return f.id === id && f.type === el.getAttribute('data-type'); }); if (i >= 0) fav.splice(i, 1); else fav.unshift({ type: el.getAttribute('data-type'), id: id, title: el.getAttribute('data-title') }); S.set('fav', fav); A.refresh(); };

  /* ---------- litanies ---------- */
  SC.litanies = function () { return { title: t('litanies'), html: '<div class="list">' + Object.keys(PR.litanies).map(function (k) { return '<button class="item" data-act="go" data-arg="litany" data-arg2="' + k + '"><b>' + esc(PR.litanies[k].title) + '</b><span>' + PR.litanies[k].items.length + ' invocations</span></button>'; }).join('') + '</div>' }; };
  SC.litany = function (k) {
    var L = PR.litanies[k], h = '<div class="card"><p class="small muted">' + esc(L.intro) + '</p><p class="prayer-text">Lord, have mercy. \u2014 Lord, have mercy.\nChrist, have mercy. \u2014 Christ, have mercy.\nLord, have mercy. \u2014 Lord, have mercy.</p></div><div class="card">' + L.items.map(function (x) { return '<p style="margin:6px 0"><b>' + esc(x) + '</b>' + (k === 'humility' ? '' : ' \u2014 <i class="muted">' + esc(L.response) + '</i>') + '</p>'; }).join('') + (k === 'humility' ? '<p><i>' + esc(L.response) + '</i></p>' : '') + '</div><button class="btn" data-act="prayerDone">\u2713 I prayed this</button>';
    return { title: L.title, html: h };
  };

  /* ---------- novenas ---------- */
  SC.novenas = function () {
    var prog = S.get('novenas', {});
    return { title: t('novenas'), html: '<div class="list">' + PR.novenas.map(function (n) { var d = Object.keys(prog[n.id] || {}).length; return '<button class="item" data-act="go" data-arg="novena" data-arg2="' + n.id + '"><b>' + esc(n.title) + '</b><span>' + esc(n.when) + (d ? ' \u00b7 ' + d + '/9' : '') + '</span></button>'; }).join('') + '</div>' };
  };
  SC.novena = function (id) {
    var n = PR.novenas.filter(function (x) { return x.id === id; })[0], prog = (S.get('novenas', {})[id]) || {};
    var h = '<div class="card"><p>' + esc(n.when) + '</p><p class="prayer-text"><i>' + esc(n.opening) + '</i></p></div>';
    h += n.days.map(function (d, i) { return '<div class="card"><div class="row sp"><h3>' + esc(d[0]) + '</h3><button class="ib" data-act="novDone" data-id="' + id + '" data-i="' + i + '">' + (prog[i] ? '\u2611' : '\u2610') + '</button></div><p class="small muted">Scripture: ' + esc(d[1]) + (W.Bible && W.Bible.ready ? ' \u00b7 <a href="#" data-act="readRef" data-ref="' + esc(d[1]) + '">read</a>' : '') + '</p><p>' + esc(d[2]) + '</p></div>'; }).join('');
    h += '<div class="card"><p class="prayer-text"><i>' + esc(n.closing) + '</i></p></div>';
    return { title: n.title, html: h };
  };
  AC.novDone = function (el) { var all = S.get('novenas', {}), id = el.getAttribute('data-id'), i = el.getAttribute('data-i'); all[id] = all[id] || {}; if (all[id][i]) delete all[id][i]; else { all[id][i] = 1; A.mark('prayer'); } S.set('novenas', all); A.refresh(); };
  AC.readRef = function (el, e) { if (e) e.preventDefault(); A.go('refview', el.getAttribute('data-ref')); };
  SC.refview = function (ref) { var res = W.Bible.ready ? W.Bible.resolve(ref) : null; return { title: ref, html: res && res.blocks.length ? A.passageHtml(res) : '<p class="muted">Passage not available.</p>' }; };

  /* ---------- stations ---------- */
  SC.stations = function () { return { title: t('stations'), html: '<div class="card"><p>Walk with Jesus on the way of the Cross through 14 stations. Each station has a short reflection and prayer.</p></div><button class="btn block" data-act="stationsStart">Begin</button>' }; };
  AC.stationsStart = function () {
    var s = [{ h: 'Opening', text: 'In the name of the Father, and of the Son, and of the Holy Spirit. Amen.\n\nMy Lord Jesus Christ, you have walked this road for love of me. Help me to walk with you.' }];
    PR.stations.forEach(function (st, i) { s.push({ h: 'Station ' + (i + 1) + ': ' + st[0], text: PR.stationsRefrain.join('\n') + '\n\n' + st[1] + '\n\n' + st[2] + '\n\nOur Father\u2026 Hail Mary\u2026 Glory Be\u2026' }); });
    s.push({ h: 'Closing', text: 'Lord Jesus, thank you for your love, shown on the cross. Help me to carry my cross each day and to rise with you on Easter morning. Amen.' });
    startGuided('stations', s, t('stations'));
  };

  /* ---------- routines ---------- */
  SC.routine = function (k) {
    var r = PR.routines[k];
    return { title: r.title, html: '<div class="card"><p>' + r.steps.length + ' short steps.</p></div><button class="btn block" data-act="routineStart" data-k="' + k + '">Begin</button><div class="list" style="margin-top:12px">' + r.steps.map(function (s) { return '<div class="item"><b>' + esc(s.h) + '</b></div>'; }).join('') + '</div>' };
  };
  AC.routineStart = function (el) { var r = PR.routines[el.getAttribute('data-k')]; startGuided('routine', r.steps, r.title); };

  /* ---------- timer ---------- */
  var tm = null, ctx = null;
  function chime(n) {
    try {
      ctx = ctx || new (W.AudioContext || W.webkitAudioContext)();
      for (var i = 0; i < (n || 1); i++) {
        var o = ctx.createOscillator(), g = ctx.createGain(), st = ctx.currentTime + i * 1.4;
        o.type = 'sine'; o.frequency.value = 528; g.gain.setValueAtTime(0.0001, st); g.gain.exponentialRampToValueAtTime(0.3, st + 0.05); g.gain.exponentialRampToValueAtTime(0.0001, st + 1.6);
        o.connect(g); g.connect(ctx.destination); o.start(st); o.stop(st + 1.7);
      }
    } catch (e) {}
  }
  A.stopTimers = function () { if (tm) { clearInterval(tm.id); if (W.AndroidBridge && W.AndroidBridge.keepScreenOn) W.AndroidBridge.keepScreenOn(false); tm = null; } };
  var LECTIO = [['Lectio \u2013 Read', 'Read the passage slowly. Notice a word or phrase that stands out.'], ['Meditatio \u2013 Reflect', 'Repeat the phrase. What is God saying to you through it?'], ['Oratio \u2013 Respond', 'Speak to God honestly about what you feel and need.'], ['Contemplatio \u2013 Rest', 'Be still in God\u2019s presence. Let go of words.']];
  SC.timer = function () {
    var h = '<div class="card"><h3>' + esc(t('timer')) + '</h3><p class="muted small">A soft chime sounds at the start, between guided stages, and at the end.</p><label>Minutes</label><select id="tmMin">' + [3, 5, 10, 15, 20, 30].map(function (m) { return '<option value="' + m + '"' + (m === 10 ? ' selected' : '') + '>' + m + '</option>'; }).join('') + '</select><label>Mode</label><select id="tmMode"><option value="silent">Silent prayer</option><option value="lectio">Lectio Divina (guided stages)</option></select><button class="btn block" style="margin-top:10px" data-act="tmStart">Start</button></div><div id="tmBox"></div>';
    return { title: t('timer'), html: h };
  };
  AC.tmStart = function () {
    var mins = +A.$('#tmMin').value, mode = A.$('#tmMode').value, total = mins * 60, start = Date.now();
    A.stopTimers(); chime(1); if (W.AndroidBridge && W.AndroidBridge.keepScreenOn) W.AndroidBridge.keepScreenOn(true);
    tm = { id: setInterval(function () {
      var el = Math.floor((Date.now() - start) / 1000), left = Math.max(0, total - el), box = A.$('#tmBox'); if (!box) return;
      var stage = ''; if (mode === 'lectio') { var idx = Math.min(3, Math.floor(el / (total / 4))); stage = '<h3>' + esc(LECTIO[idx][0]) + '</h3><p>' + esc(LECTIO[idx][1]) + '</p>'; if (tm.last !== idx) { if (tm.last !== undefined) chime(1); tm.last = idx; } }
      box.innerHTML = '<div class="card center"><div class="timer">' + A.pad(Math.floor(left / 60)) + ':' + A.pad(left % 60) + '</div>' + stage + '<button class="btn alt" data-act="tmStop">Stop</button></div>';
      if (left <= 0) { chime(3); A.stopTimers(); A.mark('prayer'); box.innerHTML = '<div class="card center"><h3>\u2713 Amen</h3><p>Your prayer time has been counted.</p></div>'; }
    }, 500) };
  };
  AC.tmStop = function () { A.stopTimers(); var b = A.$('#tmBox'); if (b) b.innerHTML = ''; };
})();
