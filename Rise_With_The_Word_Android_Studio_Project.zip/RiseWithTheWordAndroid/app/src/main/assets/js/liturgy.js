/* Roman Rite liturgical calendar engine.
   Computes seasons, Sundays, movable feasts, colours, cycles (A/B/C, I/II) and merges
   the fixed-date celebrations from saints.js. Works for any year (UI offers 2026-2031).
   Regional options (set via Liturgy.options):
     epiphanySunday  - celebrate Epiphany on the Sunday between Jan 2-8 (default false = Jan 6)
     ascensionSunday - move Ascension to the 7th Sunday of Easter (default false = Thursday)
     corpusSunday    - move Corpus Christi to the Sunday (default false = Thursday)
   IMPORTANT: always compare with your diocese / national conference ordo. */
(function (root) {
  'use strict';
  var DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  var COLORS = { w: 'White', r: 'Red', g: 'Green', v: 'Violet', p: 'Rose' };
  var RANKS = { S: 'Solemnity', F: 'Feast', M: 'Memorial', O: 'Optional memorial', L: 'Local memorial (India)', T: 'Weekday', U: 'Sunday', D: 'Sacred Triduum' };
  var ORD = ['', 'First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth'];
  var LORD_FEASTS = { '02-02': 1, '08-06': 1, '09-14': 1, '11-09': 1 };

  var Liturgy = { options: { epiphanySunday: false, ascensionSunday: false, corpusSunday: false }, DAYS: DAYS, MONTHS: MONTHS, COLORS: COLORS, RANKS: RANKS };

  function mk(y, m, d) { return new Date(y, m, d, 12, 0, 0, 0); }
  function add(dt, n) { return mk(dt.getFullYear(), dt.getMonth(), dt.getDate() + n); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function key(dt) { return dt.getFullYear() + '-' + pad(dt.getMonth() + 1) + '-' + pad(dt.getDate()); }
  function md(dt) { return pad(dt.getMonth() + 1) + '-' + pad(dt.getDate()); }
  function diff(a, b) { return Math.round((mk(a.getFullYear(), a.getMonth(), a.getDate()) - mk(b.getFullYear(), b.getMonth(), b.getDate())) / 86400000); }
  function sundayOnOrBefore(dt) { return add(dt, -dt.getDay()); }
  function ord(n) { return n + (n % 100 >= 11 && n % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][n % 10 > 3 ? 0 : n % 10] || 'th'); }
  Liturgy.key = key; Liturgy.mk = mk; Liturgy.add = add;

  /* Gregorian Easter (Meeus/Jones/Butcher algorithm). */
  function easter(y) {
    var a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4;
    var f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
    var i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
    var month = Math.floor((h + l - 7 * m + 114) / 31), day = ((h + l - 7 * m + 114) % 31) + 1;
    return mk(y, month - 1, day);
  }
  Liturgy.easter = easter;

  function advent1(y) { var c = mk(y, 11, 25), dw = c.getDay() || 7; return add(c, -dw - 21); }
  function epiphany(y) { // Epiphany in civil year y
    if (!Liturgy.options.epiphanySunday) return mk(y, 0, 6);
    var d = mk(y, 0, 2); while (d.getDay() !== 0) d = add(d, 1); return d; // Sunday Jan 2-8
  }
  function baptism(y) {
    var e = epiphany(y);
    if (!Liturgy.options.epiphanySunday) { var d = add(e, 1); while (d.getDay() !== 0) d = add(d, 1); return d; }
    var dd = e.getDate(); // Jan 2-8
    return dd >= 7 ? add(e, 1) : add(e, 7);
  }
  function holyFamily(y) { var c = mk(y, 11, 25); if (c.getDay() === 0) return mk(y, 11, 30); var d = add(c, 1); while (d.getDay() !== 0) d = add(d, 1); return d; }

  function dates(y) {
    var E = easter(y);
    var asc = add(E, 39), cc = add(E, 60);
    if (Liturgy.options.ascensionSunday) asc = add(E, 42);
    if (Liturgy.options.corpusSunday) cc = add(E, 63);
    return {
      easter: E, ash: add(E, -46), palm: add(E, -7), pentecost: add(E, 49), trinity: add(E, 56), corpus: cc,
      ascension: asc, sacredHeart: add(E, 68), immaculateHeart: add(E, 69), motherChurch: add(E, 50),
      advent1: advent1(y), epiphany: epiphany(y), baptism: baptism(y), holyFamily: holyFamily(y),
      christKing: add(advent1(y), -7)
    };
  }

  var cacheYears = {};
  function D(y) { var k = y + '|' + JSON.stringify(Liturgy.options); if (!cacheYears[k]) cacheYears[k] = dates(y); return cacheYears[k]; }

  /* Parse the raw saints list into objects (once). */
  var SAINTS = null;
  function saints() {
    if (SAINTS) return SAINTS;
    SAINTS = {};
    (root.RWTW_SAINTS_RAW || []).concat(root.RWTW_SAINTS_EXTRA || []).forEach(function (line) {
      var p = typeof line === 'string' ? line.split('|') : line;
      var rec = typeof line === 'string' ? { md: p[0], rank: p[1], color: p[2], name: p[3], bio: p.slice(4).join('|') } : line;
      (SAINTS[rec.md] = SAINTS[rec.md] || []).push(rec);
    });
    return SAINTS;
  }
  Liturgy.saintsOn = function (m, d) { return (saints()[pad(m) + '-' + pad(d)] || []).slice(); };
  Liturgy.allSaints = function () { var out = []; var s = saints(); Object.keys(s).sort().forEach(function (k) { s[k].forEach(function (r) { out.push(r); }); }); return out; };
  Liturgy.resetSaints = function () { SAINTS = null; };

  /* Transfers of solemnities (returns map 'YYYY-MM-DD' -> list of fixed records for that year). */
  function transferred(y) {
    var out = {}, t = D(y), s = saints();
    function put(dt, rec, note) { var k = key(dt); (out[k] = out[k] || []).push(Object.assign({}, rec, { note: note || rec.note })); }
    var skip = {};
    // Joseph, 19 March
    var j = mk(y, 2, 19), jr = (s['03-19'] || [])[0];
    if (jr) {
      if (j >= t.palm && j < t.easter) { var sat = add(t.palm, -1); put(sat, jr, 'Transferred from 19 March (Holy Week)'); skip['03-19'] = 1; }
      else if (j.getDay() === 0 && j >= t.ash && j < t.palm) { put(add(j, 1), jr, 'Transferred from Sunday of Lent'); skip['03-19'] = 1; }
    }
    // Annunciation, 25 March
    var a = mk(y, 2, 25), ar = (s['03-25'] || [])[0];
    if (ar) {
      if (a >= t.palm && a < add(t.easter, 8)) { put(add(t.easter, 8), ar, 'Transferred from 25 March (Holy Week / Easter Octave)'); skip['03-25'] = 1; }
      else if (a.getDay() === 0 && a >= t.ash && a < t.palm) { put(add(a, 1), ar, 'Transferred from Sunday of Lent'); skip['03-25'] = 1; }
    }
    // Immaculate Conception, 8 December on Advent Sunday
    var ic = mk(y, 11, 8), icr = (s['12-08'] || [])[0];
    if (icr && ic.getDay() === 0) { put(add(ic, 1), icr, 'Transferred from Sunday of Advent'); skip['12-08'] = 1; }
    // John the Baptist vs Sacred Heart
    var jb = mk(y, 5, 24), jbr = (s['06-24'] || [])[0];
    if (jbr && key(jb) === key(t.sacredHeart)) { put(add(jb, -1), jbr, 'Transferred (Sacred Heart)'); skip['06-24'] = 1; }
    var pp = mk(y, 5, 29), ppr = (s['06-29'] || [])[0];
    if (ppr && key(pp) === key(t.sacredHeart)) { put(add(pp, 1), ppr, 'Transferred (Sacred Heart)'); skip['06-29'] = 1; }
    return { map: out, skip: skip };
  }
  var trCache = {};
  function TR(y) { var k = y + '|' + JSON.stringify(Liturgy.options); if (!trCache[k]) trCache[k] = transferred(y); return trCache[k]; }

  function fixedFor(dt) {
    var y = dt.getFullYear(), t = D(y), tr = TR(y), list = [];
    var m = md(dt);
    if (!tr.skip[m]) (saints()[m] || []).forEach(function (r) { list.push(r); });
    (tr.map[key(dt)] || []).forEach(function (r) { list.push(r); });
    var k = key(dt);
    if (k === key(t.motherChurch)) list.push({ md: m, rank: 'M', color: 'w', name: 'Mary, Mother of the Church', bio: 'Memorial on the Monday after Pentecost, honouring Mary as Mother of the Church.' });
    if (k === key(t.immaculateHeart)) list.push({ md: m, rank: 'M', color: 'w', name: 'The Immaculate Heart of Mary', bio: 'Memorial on the Saturday after the Sacred Heart, honouring the Heart of Mary.' });
    return list;
  }

  /* Seasonal (movable) description of a date. */
  function seasonal(dt) {
    var y = dt.getFullYear(), t = D(y), dw = dt.getDay(), name = DAYS[dw], k = key(dt);
    var prev = D(y - 1), nextAdvent = t.advent1;
    var r = { season: 'ordinary', seasonName: 'Ordinary Time', color: 'g', kind: 'ferial', week: 0, title: '' };

    // Christmas season of previous year spills into January
    if (dt <= t.baptism) {
      r.season = 'christmas'; r.seasonName = 'Christmas Time'; r.color = 'w';
      if (k === key(t.epiphany)) { r.kind = 'top'; r.title = 'The Epiphany of the Lord'; return r; }
      if (k === key(t.baptism)) { r.kind = 'top'; r.title = 'The Baptism of the Lord'; return r; }
      if (dt.getMonth() === 0 && dt.getDate() === 1) { r.kind = 'xmas'; r.title = 'Mary, Mother of God'; return r; }
      if (dw === 0 && dt < t.epiphany) { r.kind = 'top'; r.title = 'Second Sunday after Christmas'; return r; }
      if (dt < t.epiphany) { r.kind = 'ferial'; r.title = name + ' of Christmas Time (' + dt.getDate() + ' January)'; return r; }
      r.kind = 'ferial'; r.title = name + ' after the Epiphany'; return r;
    }
    // Advent
    if (dt >= t.advent1 && dt < mk(y, 11, 25)) {
      r.season = 'advent'; r.seasonName = 'Advent'; r.color = 'v';
      var wk = Math.floor(diff(dt, t.advent1) / 7) + 1; r.week = wk;
      if (dw === 0) { r.kind = 'top'; r.title = ord(wk) + ' Sunday of Advent'; if (wk === 3) { r.color = 'p'; r.title += ' (Gaudete)'; } return r; }
      if (dt.getMonth() === 11 && dt.getDate() >= 17) { r.kind = 'lentlike'; r.title = name + ', December ' + dt.getDate() + ' (Advent)'; return r; }
      r.kind = 'ferial'; r.title = name + ' of the ' + ord(wk) + ' week of Advent'; return r;
    }
    // Christmas Day -> Dec 31
    if (dt >= mk(y, 11, 25)) {
      r.season = 'christmas'; r.seasonName = 'Christmas Time'; r.color = 'w';
      if (dt.getDate() === 25) { r.kind = 'xmas'; r.title = 'The Nativity of the Lord'; return r; }
      if (k === key(t.holyFamily)) { r.kind = 'top'; r.title = 'The Holy Family of Jesus, Mary and Joseph'; return r; }
      if (dw === 0) { r.kind = 'top'; r.title = 'Second Sunday after Christmas'; return r; }
      r.kind = 'xmas'; r.title = name + ' in the Octave of Christmas (' + dt.getDate() + ' December)'; return r;
    }
    // Ordinary Time Part 1
    if (dt > t.baptism && dt < t.ash) {
      var wkOT = 1 + Math.round(diff(sundayOnOrBefore(dt), sundayOnOrBefore(t.baptism)) / 7);
      r.week = wkOT;
      if (dw === 0) { r.kind = 'sundayOT'; r.title = ord(wkOT) + ' Sunday in Ordinary Time'; return r; }
      r.title = name + ' of the ' + ord(wkOT) + ' week in Ordinary Time'; return r;
    }
    // Lent
    if (dt >= t.ash && dt < add(t.easter, -3)) {
      r.season = 'lent'; r.seasonName = 'Lent'; r.color = 'v';
      if (k === key(t.ash)) { r.kind = 'top'; r.title = 'Ash Wednesday'; return r; }
      if (dt < add(t.ash, 4)) { r.kind = 'lentlike'; r.title = name + ' after Ash Wednesday'; return r; }
      if (dt >= t.palm) {
        r.season = 'holyweek'; r.seasonName = 'Holy Week';
        if (dw === 0) { r.kind = 'top'; r.title = 'Palm Sunday of the Passion of the Lord'; r.color = 'r'; return r; }
        r.kind = 'top'; r.title = name + ' of Holy Week'; return r;
      }
      var l1 = add(t.ash, 4), wk2 = Math.floor(diff(dt, l1) / 7) + 1; r.week = wk2;
      if (dw === 0) { r.kind = 'top'; r.title = ord(wk2) + ' Sunday of Lent'; if (wk2 === 4) { r.color = 'p'; r.title += ' (Laetare)'; } return r; }
      r.kind = 'lentlike'; r.title = name + ' of the ' + ord(wk2) + ' week of Lent'; return r;
    }
    // Triduum
    var E = t.easter;
    if (k === key(add(E, -3))) { r.season = 'triduum'; r.seasonName = 'Easter Triduum'; r.kind = 'top'; r.color = 'w'; r.title = 'Holy Thursday — Mass of the Lord\u2019s Supper'; return r; }
    if (k === key(add(E, -2))) { r.season = 'triduum'; r.seasonName = 'Easter Triduum'; r.kind = 'top'; r.color = 'r'; r.title = 'Good Friday of the Passion of the Lord'; return r; }
    if (k === key(add(E, -1))) { r.season = 'triduum'; r.seasonName = 'Easter Triduum'; r.kind = 'top'; r.color = 'v'; r.title = 'Holy Saturday'; return r; }
    // Easter season
    if (dt >= E && dt <= t.pentecost) {
      r.season = 'easter'; r.seasonName = 'Easter Time'; r.color = 'w'; r.kind = 'top';
      var n = diff(dt, E);
      if (n === 0) { r.title = 'Easter Sunday of the Resurrection of the Lord'; return r; }
      if (n < 7) { r.title = name + ' within the Octave of Easter'; return r; }
      if (n === 7) { r.title = 'Second Sunday of Easter (Sunday of Divine Mercy)'; r.week = 2; return r; }
      if (k === key(t.ascension)) { r.title = 'The Ascension of the Lord'; return r; }
      if (k === key(t.pentecost)) { r.title = 'Pentecost Sunday'; r.color = 'r'; return r; }
      var we = Math.floor(n / 7) + 1; r.week = we;
      if (dw === 0) { r.title = ord(we) + ' Sunday of Easter'; return r; }
      r.kind = 'ferial'; r.title = name + ' of the ' + ord(we) + ' week of Easter';
      if (dt > t.ascension && dt < t.pentecost && we >= 7) r.title = name + ' of the 7th week of Easter';
      if (dt >= add(t.pentecost, -7) && dt < t.pentecost && dw !== 0 && Liturgy.options.ascensionSunday) r.title = name + ' of the 7th week of Easter';
      return r;
    }
    // Ordinary Time Part 2
    var sun = sundayOnOrBefore(dt), w2 = 34 - Math.round(diff(t.christKing, sun) / 7);
    r.week = w2;
    if (k === key(t.trinity)) { r.kind = 'top'; r.title = 'The Most Holy Trinity'; r.color = 'w'; return r; }
    if (k === key(t.corpus)) { r.kind = 'top'; r.title = 'The Most Holy Body and Blood of Christ (Corpus Christi)'; r.color = 'w'; return r; }
    if (k === key(t.sacredHeart)) { r.kind = 'top'; r.title = 'The Most Sacred Heart of Jesus'; r.color = 'w'; return r; }
    if (k === key(t.christKing)) { r.kind = 'top'; r.title = 'Our Lord Jesus Christ, King of the Universe'; r.color = 'w'; return r; }
    if (dw === 0) { r.kind = 'sundayOT'; r.title = ord(w2) + ' Sunday in Ordinary Time'; return r; }
    r.title = name + ' of the ' + ord(w2) + ' week in Ordinary Time';
    return r;
  }

  function cycles(dt) {
    var y = dt.getFullYear(), ly = dt >= D(y).advent1 ? y : y - 1;
    var sc = ['A', 'B', 'C'][ly % 3];
    return { sunday: sc, weekday: (y % 2 === 1) ? 'I' : 'II' };
  }

  Liturgy.day = function (input) {
    var dt = input instanceof Date ? mk(input.getFullYear(), input.getMonth(), input.getDate()) : input;
    var s = seasonal(dt), fx = fixedFor(dt), cyc = cycles(dt);
    var out = {
      date: dt, key: key(dt), dow: dt.getDay(), season: s.season, seasonName: s.seasonName, week: s.week,
      title: s.title, rank: 'T', color: s.color, kind: s.kind, cycle: cyc, saints: [], optional: [], note: ''
    };
    var best = null, order = { S: 0, F: 1, M: 2 };
    function sortF(a, b) { return (order[a.rank] === undefined ? 9 : order[a.rank]) - (order[b.rank] === undefined ? 9 : order[b.rank]); }
    fx.sort(sortF);
    var S = fx.filter(function (r) { return r.rank === 'S'; }), F = fx.filter(function (r) { return r.rank === 'F'; });
    var M = fx.filter(function (r) { return r.rank === 'M'; }), O = fx.filter(function (r) { return r.rank === 'O' || r.rank === 'L'; });
    var kind = s.kind;
    if (kind === 'top') {
      out.optional = []; out.saints = [];
      if (fx.length) out.note = 'Not observed liturgically today: ' + fx.map(function (r) { return r.name; }).join('; ');
      if (S.length && s.season !== 'triduum' && s.season !== 'holyweek' && s.season !== 'easter' && s.season !== 'advent' && s.season !== 'lent' && dt.getDay() !== 0) { /* handled above by transfers */ }
    } else if (kind === 'sundayOT') {
      if (S.length) best = S[0]; else { var lf = F.filter(function (r) { return LORD_FEASTS[r.md]; }); if (lf.length) best = lf[0]; }
      if (best) { out.saints = fx.filter(function (r) { return r !== best; }); }
      else out.note = fx.length ? 'Not observed liturgically today: ' + fx.map(function (r) { return r.name; }).join('; ') : '';
    } else if (kind === 'lentlike' || kind === 'xmas') {
      if (S.length) best = S[0]; else if (F.length) best = F[0];
      out.optional = fx.filter(function (r) { return r !== best && (r.rank === 'M' || r.rank === 'O' || r.rank === 'L'); });
      if (best) out.saints = fx.filter(function (r) { return r !== best && r.rank !== 'M' && r.rank !== 'O' && r.rank !== 'L'; });
    } else { // ferial / OT weekday / Easter weekday
      if (S.length) best = S[0]; else if (F.length) best = F[0]; else if (M.length) best = M[0];
      out.optional = fx.filter(function (r) { return r !== best && (r.rank === 'M' || r.rank === 'O' || r.rank === 'L'); });
      if (best) out.saints = fx.filter(function (r) { return r !== best && (r.rank === 'S' || r.rank === 'F'); });
    }
    if (best) {
      out.rank = best.rank; out.celebration = best.name; out.color = best.color || out.color;
      out.title = best.name; out.md = best.md; out.seasonTitle = s.title; out.bio = best.bio; out.note = best.note || out.note;
    }
    if (!best) {
      if (/^(The Epiphany|The Ascension|Pentecost|The Most Holy|The Most Sacred Heart|Our Lord Jesus Christ, King|Easter Sunday|.* within the Octave of Easter)/.test(out.title)) out.rank = 'S';
      else if (/^(The Baptism of the Lord|The Holy Family)/.test(out.title)) out.rank = 'F';
      else if (s.season === 'triduum') out.rank = 'D';
      else if (dt.getDay() === 0) out.rank = 'U';
    }
    out.rankName = RANKS[out.rank];
    out.colorName = COLORS[out.color];
    out.celebrations = [];
    if (best) out.celebrations.push(best);
    out.optional.forEach(function (r) { out.celebrations.push(r); });
    return out;
  };

  Liturgy.month = function (y, m) {
    var n = new Date(y, m + 1, 0).getDate(), res = [];
    for (var i = 1; i <= n; i++) res.push(Liturgy.day(mk(y, m, i)));
    return res;
  };

  Liturgy.fullName = function (dt) { return DAYS[dt.getDay()] + ', ' + dt.getDate() + ' ' + MONTHS[dt.getMonth()] + ' ' + dt.getFullYear(); };
  Liturgy.keyOf = key; Liturgy.dates = D;

  root.Liturgy = Liturgy;
  if (typeof module !== 'undefined') module.exports = Liturgy;
})(typeof window !== 'undefined' ? window : global);
