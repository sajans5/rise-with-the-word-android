(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, t = A.t, Lit = W.Liturgy, Bible = W.Bible;
  var SC = A.screens, AC = A.actions;

  A.dayInfo = function (dt) {
    var d = Lit.day(dt), o = (A.packs.calendar || {})[d.key];
    if (o) { d = Object.assign({}, d, o); d.colorName = Lit.COLORS[d.color] || d.colorName; d.rankName = Lit.RANKS[d.rank] || d.rankName; }
    return d;
  };
  A.dateFromKey = function (k) { var p = (k || '').split('-'); return p.length === 3 ? Lit.mk(+p[0], +p[1] - 1, +p[2]) : new Date(); };
  A.colorDot = function (c) { return '<span class="swatch col-' + esc(c) + '"></span>'; };
  A.bibleMissing = function () { return '<div class="banner">The full Bible text is added when the app is built by GitHub Actions. If you see this message, rebuild the APK with the provided workflow (see README). Other features still work.</div>'; };

  var VERSES = ['Jn 3:16', 'Ps 23:1-4', 'Phil 4:4-7', 'Rom 8:28', 'Is 41:10', 'Jer 29:11', 'Mt 11:28-30', 'Prv 3:5-6', 'Jos 1:9', 'Ps 46:1-3', '1 Cor 13:4-7', 'Mt 6:33', 'Ps 121:1-2', 'Jn 14:27', 'Rom 12:12', 'Lk 1:37', 'Is 40:31', 'Ps 27:1', 'Col 3:23', 'Heb 11:1', 'Gal 5:22-23', 'Mk 10:27', 'Ps 91:1-2', '2 Cor 12:9', 'Jn 15:5', 'Mt 5:14-16', 'Ps 118:24', 'Lam 3:22-23', '1 Jn 4:18-19', 'Eph 2:8-9'];
  A.verseOfDay = function (dt) { var n = Math.floor(dt.getTime() / 86400000); return VERSES[n % VERSES.length]; };

  function passage(res) {
    if (!res) return '';
    var h = '';
    res.blocks.forEach(function (b) {
      h += '<h4 class="muted small" style="margin:10px 0 4px">' + esc(b.label) + '</h4><div class="reader">' + b.verses.map(function (v) { return '<span class="v" data-act="vtap" data-code="' + res.code + '" data-ch="' + v.c + '" data-v="' + v.n + '"><sup>' + v.n + '</sup>' + esc(v.t) + ' </span>'; }).join('') + '</div>';
    });
    (res.notes || []).filter(function (x, i, a) { return a.indexOf(x) === i; }).forEach(function (n) { h += '<div class="banner">' + esc(n) + '</div>'; });
    return h;
  }
  A.passageHtml = passage;
  var READING_LABELS = {
    'First Reading': 'ഒന്നാം വായന', 'Responsorial Psalm': 'പ്രതിവചന സങ്കീർത്തനം',
    'Second Reading': 'രണ്ടാം വായന', 'Gospel': 'സുവിശേഷം', 'Gospel Acclamation': 'സുവിശേഷഘോഷണം'
  };
  A.refBlock = function (label, ref) {
    if (!ref) return '';
    var en = Bible.ready ? Bible.resolve(ref) : null;
    var ml = Bible.resolveMalayalam ? Bible.resolveMalayalam(ref) : null;
    function renderPassage(res, lang) {
      if (!res || !res.blocks || !res.blocks.length) return '<p class="muted small">' + (lang === 'ml' ? 'ഈ ഭാഗത്തിന്റെ പാഠം ഓഫ്‌ലൈൻ ഡാറ്റയിൽ ലഭ്യമല്ല.' : 'Passage text is not available in the bundled English Bible.') + '</p>';
      var html='';
      res.blocks.forEach(function(b){
        html += '<h4 class="muted small" style="margin:10px 0 4px">'+esc(b.label)+'</h4><div class="reader">'+b.verses.map(function(v){
          return '<span class="v"><sup>'+v.n+'</sup>'+esc(v.t)+' </span>';
        }).join('')+'</div>';
      });
      (res.notes||[]).forEach(function(n){ html += '<p class="small muted">'+esc(n)+'</p>'; });
      return html;
    }
    var mlLabel = READING_LABELS[label] || label;
    var html = '<div class="card"><div class="row sp"><h3>'+esc(label)+' / '+esc(mlLabel)+'</h3><span class="small muted">'+esc(ref)+'</span></div>';
    html += '<details open><summary><b>English</b></summary>'+renderPassage(en,'en')+'</details>';
    html += '<details open><summary><b>മലയാളം</b></summary>'+renderPassage(ml,'ml')+'</details>';
    html += '<p class="small muted">Scripture reference: '+esc(ref)+'. Text availability depends on the locally bundled translation.</p></div>';
    return html;
  };

  /* ---------- HOME ---------- */
  SC.home = function () {
    var now = new Date(), d = A.dayInfo(now), rd = W.RWTW_READINGS.forDay(d), last = S.get('lastRead', null), vref = A.verseOfDay(now);
    var vres = Bible.ready ? Bible.resolve(vref) : null, vtext = vres && vres.blocks[0] ? vres.blocks[0].verses.map(function (v) { return v.t; }).join(' ') : '';
    var sa = (d.celebrations || []).slice(0, 1), saint = Lit.saintsOn(now.getMonth() + 1, now.getDate());
    var days = S.get('days', {}), did = !!days[A.todayKey()];
    var h = '<div class="hero"><div class="eyebrow">' + esc(Lit.fullName(now)) + '</div><h2>' + esc(d.title) + '</h2><p>' + A.colorDot(d.color) + esc(d.colorName) + ' \u00b7 ' + esc(d.seasonName) + ' \u00b7 ' + esc(d.rankName) + '</p><p class="small">Sunday cycle ' + d.cycle.sunday + ' \u00b7 Weekday cycle ' + d.cycle.weekday + '</p></div>';
    h += '<div class="card"><h3>' + esc(t('gospel')) + '</h3><p>' + esc(rd.gospel || '') + '</p><p class="small muted">' + esc(rd.label) + '</p><button class="btn block" data-act="go" data-arg="today">' + esc(t('gospel')) + ' \u2192</button></div>';
    h += '<div class="card"><h3>' + esc(t('verse')) + '</h3>' + (vtext ? '<p class="reader">\u201C' + esc(vtext) + '\u201D</p>' : '') + '<p class="small muted">' + esc(vref) + '</p><div class="row"><button class="btn alt" data-act="cardFromRef" data-ref="' + esc(vref) + '">' + esc(t('cards')) + '</button><button class="btn alt" data-act="shareRef" data-ref="' + esc(vref) + '">' + esc(t('share')) + '</button></div></div>';
    if (last) h += '<div class="card"><h3>' + esc(t('continue')) + '</h3><button class="item" data-act="openChapter" data-code="' + last.code + '" data-ch="' + last.ch + '"><b>' + esc(last.title) + '</b><span>' + esc(t('bible')) + '</span></button></div>';
    if (saint.length) h += '<button class="item" data-act="go" data-arg="saints"><b>' + esc(t('saint')) + ': ' + esc(saint[0].name) + '</b><span>' + esc(saint[0].bio.slice(0, 90)) + '\u2026</span></button><div style="height:12px"></div>';
    h += '<div class="grid">' +
      '<button class="tile" data-act="go" data-arg="rosary"><span class="ico">\uD83D\uDCFF</span><b>' + esc(t('rosary')) + '</b><span>' + esc(rosaryToday().name) + '</span></button>' +
      '<button class="tile" data-act="go" data-arg="stories"><span class="ico">\uD83D\uDCDA</span><b>' + esc(t('stories')) + '</b><span>' + (W.RWTW_STORIES ? W.RWTW_STORIES.length : 0) + ' stories</span></button>' +
      '<button class="tile" data-act="go" data-arg="calendar"><span class="ico">\uD83D\uDDD3\uFE0F</span><b>' + esc(t('calendar')) + '</b><span>2026\u20132031</span></button>' +
      '<button class="tile" data-act="go" data-arg="mercy"><span class="ico">\u2764\uFE0F</span><b>' + esc(t('mercy')) + '</b><span>3 o\u2019clock</span></button>' +
      '<button class="tile" data-act="go" data-arg="routine" data-arg2="morning"><span class="ico">\uD83C\uDF05</span><b>' + esc(t('morning')) + '</b><span>' + esc(t('routines')) + '</span></button>' +
      '<button class="tile" data-act="go" data-arg="routine" data-arg2="evening"><span class="ico">\uD83C\uDF19</span><b>' + esc(t('evening')) + '</b><span>' + esc(t('routines')) + '</span></button></div>';
    var cu = A.comingUp(); if (cu.length) h += '<div class="card" style="margin-top:12px"><h3>Coming up</h3>' + cu.map(function (x) { return '<button class="item" style="margin-bottom:6px" data-act="goDate" data-k="' + x.d.key + '"><b>' + A.colorDot(x.d.color) + esc(x.d.title) + '</b><span>' + (x.n === 1 ? 'Tomorrow' : 'In ' + x.n + ' days') + ' \u00b7 ' + Lit.fullName(x.d.date) + '</span></button>'; }).join('') + '</div>';
    if (A.settings.streaksOn) h += '<div class="card" style="margin-top:12px"><div class="row sp"><div><h3>' + esc(t('streak')) + '</h3><span class="muted small">' + A.streak() + ' day(s) \u00b7 ' + A.weekCount() + '/' + A.settings.weeklyGoal + ' this week</span></div>' + (did ? '<span class="chip on">\u2713 ' + esc(t('today')) + '</span>' : '<button class="btn alt" data-act="prayedToday">I prayed today</button>') + '</div><div class="progress" style="margin-top:8px"><i style="width:' + Math.min(100, Math.round(100 * A.weekCount() / A.settings.weeklyGoal)) + '%"></i></div></div>';
    return { title: 'Rise With The Word', html: h, actions: '<button class="ib" data-act="go" data-arg="search" aria-label="Search">\uD83D\uDD0D</button>' };
  };
  function rosaryToday() { var d = new Date().getDay(); var m = W.RWTW_PRAYERS.mysteries, k = Object.keys(m).filter(function (x) { return m[x].days.indexOf(d) >= 0; })[0] || 'joyful'; return { id: k, name: A.L(m[k], 'name') }; }
  A.rosaryToday = rosaryToday;
  AC.prayedToday = function () { A.mark('prayer'); A.toast('\u2713'); A.refresh(); };

  /* ---------- TODAY / readings ---------- */
  SC.today = function (key) {
    var dt = A.dateFromKey(key), d = A.dayInfo(dt), rd = W.RWTW_READINGS.forDay(d), k = d.key;
    var prev = Lit.key(Lit.add(dt, -1)), next = Lit.key(Lit.add(dt, 1));
    var h = '<div class="row sp" style="margin-bottom:10px"><button class="btn alt" data-act="goDate" data-k="' + prev + '">\u2190 ' + esc(t('prev')) + '</button><button class="btn alt" data-act="goDate" data-k="' + Lit.key(new Date()) + '">' + esc(t('today')) + '</button><button class="btn alt" data-act="goDate" data-k="' + next + '">' + esc(t('next')) + ' \u2192</button></div>';
    h += '<div class="card"><div class="small muted">' + esc(Lit.fullName(dt)) + '</div><h3 style="font-size:1.2rem">' + esc(d.title) + '</h3><p>' + A.colorDot(d.color) + esc(d.colorName) + ' \u00b7 ' + esc(d.seasonName) + ' \u00b7 ' + esc(d.rankName) + '</p>' + (d.note ? '<p class="small muted">' + esc(d.note) + '</p>' : '') + '<p class="small muted">Sunday cycle ' + d.cycle.sunday + (d.season === 'ordinary' ? ' \u00b7 Weekday cycle ' + d.cycle.weekday : '') + '</p></div>';
    if (A.fastNote(d)) h += '<div class="banner">\uD83C\uDF3F ' + esc(A.fastNote(d)) + '</div>';
    h += '<div class="banner">' + esc(rd.label) + (rd.note ? ' \u00b7 ' + esc(rd.note) : '') + '</div>';
    if (rd.first) h += A.refBlock('First Reading', rd.first);
    if (rd.psalm) h += A.refBlock('Responsorial Psalm', rd.psalm);
    if (rd.second) h += A.refBlock('Second Reading', rd.second);
    if (rd.alleluia || rd.gospelAcclamation) h += '<div class="card"><h3>Gospel Acclamation</h3><p>' + esc(rd.alleluia || rd.gospelAcclamation) + '</p></div>';
    if (Array.isArray(rd.alternatives) && rd.alternatives.length) {
      h += '<div class="card"><h3>Permitted alternative readings</h3><p class="small muted">Use only the option specified by the approved lectionary for this celebration.</p>' + rd.alternatives.map(function (a) {
        return '<div class="card"><b>' + esc(a.label || 'Alternative') + '</b>' + (a.first ? A.refBlock('First Reading', a.first) : '') + (a.psalm ? A.refBlock('Responsorial Psalm', a.psalm) : '') + (a.second ? A.refBlock('Second Reading', a.second) : '') + (a.gospel ? A.refBlock('Gospel', a.gospel) : '') + '</div>';
      }).join('') + '</div>';
    }
    if (rd.massOptions && Array.isArray(rd.massOptions)) {
      h += '<div class="card"><h3>Mass options</h3><p class="small muted">Some solemnities have separate Vigil, Night, Dawn, or Day formularies.</p>' + rd.massOptions.map(function (m) {
        return '<div class="card"><b>' + esc(m.name || 'Mass') + '</b>' + (m.first ? A.refBlock('First Reading', m.first) : '') + (m.psalm ? A.refBlock('Responsorial Psalm', m.psalm) : '') + (m.second ? A.refBlock('Second Reading', m.second) : '') + (m.alleluia || m.gospelAcclamation ? '<p><b>Gospel Acclamation</b><br>' + esc(m.alleluia || m.gospelAcclamation) + '</p>' : '') + (m.gospel ? A.refBlock('Gospel', m.gospel) : '') + '</div>';
      }).join('') + '</div>';
    }
    if (rd.source === 'plan' && Bible.ready) {
      var ch = Bible.chapter(rd.planCode, rd.planChapter), b = Bible.byCode[rd.planCode];
      h += '<div class="card"><div class="row sp"><h3>Gospel Reading</h3><span class="small muted">' + esc(rd.gospel) + '</span></div>' + (ch ? '<div class="reader">' + ch.verses.map(function (v) { return '<span class="v" data-act="vtap" data-code="' + rd.planCode + '" data-ch="' + ch.n + '" data-v="' + v.n + '"><sup>' + v.n + '</sup>' + esc(v.t) + ' </span>'; }).join('') + '</div>' : '') + '</div>';
    } else if (rd.gospel) h += A.refBlock('Gospel', rd.gospel);
    if (!rd.verified) h += '<div class="banner">Reading data is not verified as the official India lectionary for this date. Check the approved CCBI/diocesan Ordo. A continuous Gospel plan is for Bible reading only, not a substitute for Mass readings.</div>';
    else h += '<div class="banner">Source: ' + esc(rd.sourceName || 'approved liturgical source') + (rd.sourceUrl ? ' · ' + esc(rd.sourceUrl) : '') + '</div>';
    var more = (d.optional || []).concat(d.saints || []);
    if (d.celebrations && d.celebrations.length) h += '<div class="card"><h3>' + esc(t('saint')) + ' / വിശുദ്ധർ</h3>' + d.celebrations.concat(d.saints || []).filter(function (r, i, a) { return a.indexOf(r) === i; }).map(function (s) { return '<div class="item"><b>' + esc(s.name) + '</b><span>' + esc(Lit.RANKS[s.rank] || '') + '</span><p class="small">' + esc(s.bio || '') + '</p><button class="btn alt" data-act="saintOpen" data-id="' + esc(A.sid(s)) + '">Full biography / വിശദമായ ജീവചരിത്രം</button></div>'; }).join('') + '</div>';
    h += '<div class="row"><button class="btn" data-act="markRead">\u2713 I read today\u2019s Gospel</button><button class="btn alt" data-act="shareDay" data-k="' + k + '">' + esc(t('share')) + '</button></div>';
    A.currentDay = d; A.currentRd = rd;
    return { title: t('gospel'), html: h };
  };
  AC.goDate = function (el) { A.go('today', el.getAttribute('data-k'), { replace: true }); };
  AC.markRead = function () { A.mark('read'); A.mark('prayer'); A.toast('\u2713 ' + t('saved')); };
  AC.shareDay = function () { var d = A.currentDay, rd = A.currentRd; A.bridge.share(d.title + ' (' + Lit.fullName(d.date) + ')\nGospel: ' + (rd.gospel || '') + '\n\nShared from Rise With The Word'); };

  /* ---------- BIBLE ---------- */
  var bibleTab = 'books';
  A.setBibleTab = function (v) { bibleTab = v; };
  var malBookIndex = -1, malChapterIndex = -1, malSearchQuery = '', malSearchHits = null;
  function malayalamView() {
    var db = W.RWTW_MALAYALAM_BIBLE;
    if (!db || !db.books || !db.books.length) return '<div class="banner">Malayalam Bible data is missing. Rebuild the APK with the supplied project ZIP.</div>';
    var h = '<div class="card"><b>മലയാളം കത്തോലിക്കാ ബൈബിൾ</b><p class="small muted">73 പുസ്തകങ്ങളുടെ കാനോൻ പട്ടിക · 66 പുസ്തകങ്ങളുടെ വാചകം ഇപ്പോൾ ഓഫ്‌ലൈനിൽ ലഭ്യമാണ്.</p><p class="small muted">തോബിത്, യൂദിത്ത്, ജ്ഞാനം, പ്രഭാഷകൻ, ബാറൂക്ക്, 1–2 മക്കബായർ എന്നിവയുടെ മലയാളം വാചകം ലൈസൻസ്/അനുമതി സ്ഥിരീകരിക്കുന്നതുവരെ ഉൾപ്പെടുത്തിയിട്ടില്ല.</p><p class="small muted">POC മലയാളം ബൈബിൾ: പ്രത്യേകം പതിപ്പായി ചേർക്കാനുള്ള സൗകര്യം തയ്യാറാക്കുന്ന ഘട്ടത്തിലാണ്. ഔദ്യോഗികമായി ലഭിച്ചും ഓഫ്‌ലൈൻ പുനർവിതരണത്തിന് അനുമതിയുള്ളതുമായ ഡാറ്റ ലഭിക്കുന്നതുവരെ POC വാചകം ഈ ആപ്പിൽ ഉൾപ്പെടുത്തിയിട്ടില്ല.</p></div>';
    if (malSearchHits !== null) {
      h += '<div class="row sp"><h3>തിരയൽ ഫലങ്ങൾ</h3><button class="btn alt" data-act="malayalamClearSearch">Back</button></div>';
      h += '<p class="small muted">' + malSearchHits.length + ' results shown (maximum 50)</p><div class="list">';
      h += malSearchHits.map(function (x) { return '<button class="item" data-act="malayalamSearchOpen" data-b="' + x.b + '" data-c="' + x.c + '"><b>' + esc(db.books[x.b].malayalamTitle) + ' ' + x.c + ':' + x.v + '</b><span>' + esc(x.t.slice(0,150)) + '</span></button>'; }).join('');
      h += '</div>';
      return h;
    }
    if (malBookIndex >= 0 && malChapterIndex >= 0) {
      var book = db.books[malBookIndex], chapter = book.chapters[malChapterIndex];
      h += '<div class="row sp" style="margin-bottom:8px"><button class="btn alt" data-act="malayalamBack">← പുസ്തകങ്ങൾ</button><span class="small muted">' + (malChapterIndex + 1) + ' / ' + book.chapters.length + '</span></div>';
      h += '<div class="row sp"><button class="btn alt" data-act="malayalamPrevChapter" ' + (malChapterIndex === 0 ? 'disabled' : '') + '>← മുമ്പ്</button><h3 style="text-align:center">' + esc(book.malayalamTitle) + ' ' + chapter.n + '</h3><button class="btn alt" data-act="malayalamNextChapter" ' + (malChapterIndex >= book.chapters.length - 1 ? 'disabled' : '') + '>അടുത്തത് →</button></div>';
      h += '<div class="reader" lang="ml">' + chapter.verses.map(function (v) { return '<span class="v"><sup>' + v.n + '</sup>' + esc(v.t) + ' </span>'; }).join('') + '</div>';
      h += '<p class="small muted">Source: godlytalias/Bible-Database · GPL-3.0</p>';
      return h;
    }
    if (malBookIndex >= 0) {
      var b = db.books[malBookIndex];
      h += '<div class="row sp" style="margin-bottom:8px"><button class="btn alt" data-act="malayalamBack">← പുസ്തകങ്ങൾ</button><h3>' + esc(b.malayalamTitle) + '</h3></div>';
      if (!b.chapters || !b.chapters.length) {
        h += '<div class="banner"><b>മലയാളം വാചകം ഇതുവരെ ഉൾപ്പെടുത്തിയിട്ടില്ല.</b><p>ഈ പുസ്തകത്തിന്റെ പൂർണ്ണ മലയാളം വാചകം ലഭ്യമാക്കാൻ പ്രസിദ്ധീകരണാനുമതിയും ഉറവിടത്തിന്റെ ലൈസൻസും സ്ഥിരീകരിക്കണം. നിലവിൽ ഈ എൻട്രി കാനോൻ പട്ടികയ്ക്കു മാത്രമാണ്.</p><p><a href="https://www.thiruvachanam.org/api-docs" target="_blank" rel="noopener">Thiruvachanam API documentation</a></p></div>';
        return h;
      }
      h += '<div class="grid" style="grid-template-columns:repeat(5,1fr)">' + b.chapters.map(function (c, i) { return '<button class="ib" style="width:100%" data-act="malayalamChapter" data-c="' + i + '">' + c.n + '</button>'; }).join('') + '</div>';
      return h;
    }
    h += '<div class="row" style="margin-bottom:8px"><input type="search" id="malsearch" placeholder="വാക്യം തിരയുക (Malayalam)" style="flex:1"><button class="btn" data-act="malayalamSearch">🔍</button></div>';
    h += '<div class="list">' + db.books.map(function (b, i) { return '<button class="item" data-act="malayalamBook" data-b="' + i + '"><b>' + esc(b.malayalamTitle) + '</b><span>' + esc(b.englishTitle) + ' · ' + b.chapters.length + ' അധ്യായങ്ങൾ</span></button>'; }).join('') + '</div>';
    return h;
  }
  SC.bible = function () {
    var h = '';
    h += '<div class="row" style="margin-bottom:8px">' + [['books', 'English Bible'], ['malayalam', 'മലയാളം'], ['plans', t('plans')], ['marks', t('bookmarks') + ' / ' + t('notes')]].map(function (x) { return '<button class="chip ' + (bibleTab === x[0] ? 'on' : '') + '" data-act="bibleTab" data-v="' + x[0] + '">' + esc(x[1]) + '</button>'; }).join('') + '</div>';
    if (bibleTab === 'malayalam') h += malayalamView();
    else if (!Bible.ready) h += A.bibleMissing();
    else {
      h += '<div class="row" style="margin-bottom:8px"><input type="search" id="bsearch" placeholder="' + esc(t('search')) + ' (e.g. love, John 3:16)" style="flex:1"><button class="btn" data-act="bsearch">🔍</button></div>';
      if (bibleTab === 'books') {
        var grp = function (label, books) { return '<h3 style="margin:10px 0 6px">' + label + '</h3><div class="list">' + books.map(function (b) { return '<button class="item" data-act="openBook" data-code="' + b.code + '"><b>' + esc(b.title) + '</b><span>' + b.chapters.length + ' chapters</span></button>'; }).join('') + '</div>'; };
        h += grp('Old Testament', Bible.OT) + grp('New Testament', Bible.NT);
        h += '<p class="small muted center" style="margin-top:14px">' + esc((Bible.data.edition || '') + ' · ' + (Bible.data.license || '')) + '</p>';
      } else if (bibleTab === 'plans') h += plansHtml();
      else h += marksHtml();
    }
    return { title: t('bible'), html: h };
  };
  AC.bibleTab = function (el) { bibleTab = el.getAttribute('data-v'); malBookIndex = -1; malChapterIndex = -1; malSearchHits = null; A.refresh(); };
  AC.malayalamBook = function (el) { malBookIndex = +el.getAttribute('data-b'); malChapterIndex = -1; malSearchHits = null; A.refresh(); };
  AC.malayalamChapter = function (el) { malChapterIndex = +el.getAttribute('data-c'); A.refresh(); };
  AC.malayalamBack = function () { if (malChapterIndex >= 0) malChapterIndex = -1; else malBookIndex = -1; A.refresh(); };
  AC.malayalamPrevChapter = function () { if (malChapterIndex > 0) malChapterIndex--; A.refresh(); };
  AC.malayalamNextChapter = function () { var b = W.RWTW_MALAYALAM_BIBLE.books[malBookIndex]; if (b && malChapterIndex < b.chapters.length - 1) malChapterIndex++; A.refresh(); };
  AC.malayalamSearch = function () {
    var db = W.RWTW_MALAYALAM_BIBLE, el = document.getElementById('malsearch'), q = (el ? el.value : '').trim().toLowerCase();
    if (!q || !db) { A.toast('തിരയാനുള്ള വാക്ക് നൽകുക'); return; }
    malSearchHits = [];
    for (var bi = 0; bi < db.books.length && malSearchHits.length < 50; bi++) {
      for (var ci = 0; ci < db.books[bi].chapters.length && malSearchHits.length < 50; ci++) {
        var verses = db.books[bi].chapters[ci].verses;
        for (var vi = 0; vi < verses.length && malSearchHits.length < 50; vi++) if (verses[vi].t.toLowerCase().indexOf(q) >= 0) malSearchHits.push({ b: bi, c: ci + 1, v: verses[vi].n, t: verses[vi].t });
      }
    }
    A.refresh();
  };
  AC.malayalamClearSearch = function () { malSearchHits = null; A.refresh(); };
  AC.malayalamSearchOpen = function (el) { malBookIndex = +el.getAttribute('data-b'); malChapterIndex = +el.getAttribute('data-c') - 1; malSearchHits = null; A.refresh(); };
  AC.openBook = function (el) { var code = el.getAttribute('data-code'), b = Bible.byCode[code];
    var intro = (W.RWTW_FAITH.bookIntros || {})[code], rc = S.get('readCh', {}), nread = b.chapters.filter(function (c) { return rc[code + ':' + c.n]; }).length;
    var h = '<h3 style="margin:4px 0 6px">' + esc(b.title) + '</h3>' + (intro ? '<div class="card"><p><b>About this book.</b> ' + esc(intro[0]) + '</p><p>' + esc(intro[1]) + '</p></div>' : '') + '<p class="small muted">' + nread + ' of ' + b.chapters.length + ' chapters marked read</p><div class="grid" style="grid-template-columns:repeat(5,1fr)">' + b.chapters.map(function (c) { return '<button class="ib" style="width:100%" data-act="openChapter" data-code="' + code + '" data-ch="' + c.n + '">' + (rc[code + ':' + c.n] ? '\u2713 ' : '') + c.n + '</button>'; }).join('') + '</div>';
    A.go('page', { title: b.title, html: h });
  };
  SC.page = function (arg) { return arg || { html: '' }; };

  AC.openChapter = function (el) { A.go('chapter', { code: el.getAttribute('data-code'), ch: +el.getAttribute('data-ch') }); };
  SC.chapter = function (arg) {
    var b = Bible.byCode[arg.code], ch = Bible.chapter(arg.code, arg.ch);
    if (!b || !ch) return { title: t('bible'), html: '<p>Chapter not found.</p>' };
    var hl = S.get('hl', {}), bm = S.get('bm', []);
    var idx = b.chapters.indexOf(ch), prev = b.chapters[idx - 1], next = b.chapters[idx + 1];
    var title = Bible.shortTitle(b) + ' ' + ch.n;
    S.set('lastRead', { code: arg.code, ch: ch.n, title: b.title + ' ' + ch.n }); A.recent('chapter', arg.code + ':' + ch.n, b.title + ' ' + ch.n);
    var h = '<div class="row sp" style="margin-bottom:6px"><div class="row"><button class="ib" data-act="fs" data-d="-0.1">A\u2212</button><button class="ib" data-act="fs" data-d="0.1">A+</button></div><div class="row"><button class="btn alt" data-act="markChapter" data-code="' + arg.code + '" data-ch="' + ch.n + '">' + (S.get('readCh', {})[arg.code + ':' + ch.n] ? '\u2713 Read' : 'Mark read') + '</button></div></div>';
    h += '<div class="reader" id="chtext">' + ch.verses.map(function (v) {
      var id = arg.code + ':' + ch.n + ':' + v.n, cls = 'v' + (hl[id] ? ' hl' + hl[id] : '') + (bm.some(function (x) { return x.id === id; }) ? ' bm' : '');
      return '<span class="' + cls + '" data-act="vtap" data-code="' + arg.code + '" data-ch="' + ch.n + '" data-v="' + v.n + '"><sup>' + v.n + '</sup>' + esc(v.t) + ' </span>';
    }).join('') + '</div>';
    if (b.code === 'ps') h += '<div class="banner">Psalms use Vulgate numbering in the Douay\u2013Rheims (Psalm ' + ch.n + ' here is Psalm ' + (ch.n + (ch.n >= 9 && ch.n <= 146 ? 1 : 0)) + ' in most modern Bibles, approximately).</div>';
    h += '<div class="row sp" style="margin-top:14px">' + (prev ? '<button class="btn alt" data-act="chNav" data-code="' + arg.code + '" data-ch="' + prev.n + '">\u2190 ' + prev.n + '</button>' : '<span></span>') + (next ? '<button class="btn alt" data-act="chNav" data-code="' + arg.code + '" data-ch="' + next.n + '">' + next.n + ' \u2192</button>' : '<span></span>') + '</div>';
    return { title: title, html: h, actions: '<button class="ib" data-act="go" data-arg="search" aria-label="Search">\uD83D\uDD0D</button>' };
  };
  AC.chNav = function (el) { A.go('chapter', { code: el.getAttribute('data-code'), ch: +el.getAttribute('data-ch') }, { replace: true }); };
  AC.fs = function (el) { A.settings.fs = Math.max(0.8, Math.min(1.8, Math.round((A.settings.fs + parseFloat(el.getAttribute('data-d'))) * 10) / 10)); A.saveSettings(); };
  AC.markChapter = function (el) { var rc = S.get('readCh', {}), k = el.getAttribute('data-code') + ':' + el.getAttribute('data-ch'); if (rc[k]) delete rc[k]; else { rc[k] = 1; A.mark('read'); } S.set('readCh', rc); A.refresh(); };

  /* verse actions */
  AC.vtap = function (el) {
    var sel = { code: el.getAttribute('data-code'), ch: +el.getAttribute('data-ch'), v: +el.getAttribute('data-v') };
    A.sel = sel; var b = Bible.byCode[sel.code], c = Bible.chapter(sel.code, sel.ch); if (!c) return;
    var vv = c.verses.filter(function (x) { return x.n === sel.v; })[0]; if (!vv) return;
    sel.text = vv.t; sel.ref = Bible.shortTitle(b) + ' ' + sel.ch + ':' + sel.v; sel.id = sel.code + ':' + sel.ch + ':' + sel.v;
    A.$$('.v.sel').forEach(function (e) { e.classList.remove('sel'); }); el.classList.add('sel');
    A.openSheet('<div class="row sp"><b>' + esc(sel.ref) + '</b><button class="ib" data-act="closeSheet">\u2715</button></div><p class="small muted" style="max-height:3.2em;overflow:hidden">' + esc(sel.text) + '</p><div class="sw"><button class="dot c1" data-act="hlSet" data-c="1" aria-label="Yellow"></button><button class="dot c2" data-act="hlSet" data-c="2" aria-label="Green"></button><button class="dot c3" data-act="hlSet" data-c="3" aria-label="Blue"></button><button class="dot c4" data-act="hlSet" data-c="4" aria-label="Pink"></button><button class="ib" data-act="hlSet" data-c="0" aria-label="Clear">\u2298</button></div><div class="row"><button class="btn alt" data-act="bmToggle">\uD83D\uDD16 ' + esc(t('bookmarks')) + '</button><button class="btn alt" data-act="noteAdd">\u270E ' + esc(t('notes')) + '</button><button class="btn alt" data-act="verseCopy">Copy</button><button class="btn alt" data-act="verseShare">' + esc(t('share')) + '</button><button class="btn alt" data-act="verseCard">' + esc(t('cards')) + '</button></div>');
  };
  AC.closeSheet = function () { A.closeSheet(); A.$$('.v.sel').forEach(function (e) { e.classList.remove('sel'); }); };
  AC.hlSet = function (el) { var c = +el.getAttribute('data-c'), hl = S.get('hl', {}); if (c) hl[A.sel.id] = c; else delete hl[A.sel.id]; S.set('hl', hl); A.closeSheet(); A.refresh(); };
  AC.bmToggle = function () { var bm = S.get('bm', []), id = A.sel.id, i = bm.findIndex(function (x) { return x.id === id; }); if (i >= 0) bm.splice(i, 1); else bm.unshift({ id: id, code: A.sel.code, ch: A.sel.ch, v: A.sel.v, ref: A.sel.ref, text: A.sel.text, ts: Date.now() }); S.set('bm', bm); A.closeSheet(); A.refresh(); A.toast(i >= 0 ? 'Removed' : '\uD83D\uDD16 ' + t('saved')); };
  AC.verseCopy = function () { A.copy('\u201C' + A.sel.text + '\u201D \u2014 ' + A.sel.ref); A.closeSheet(); };
  AC.verseShare = function () { A.bridge.share('\u201C' + A.sel.text + '\u201D\n\u2014 ' + A.sel.ref + '\n\nRise With The Word'); A.closeSheet(); };
  AC.verseCard = function () { var s = A.sel; A.closeSheet(); A.go('card', { text: s.text, ref: s.ref }); };
  AC.noteAdd = function () { var s = A.sel; A.closeSheet(); A.go('noteEdit', { ref: s.ref, code: s.code, ch: s.ch, v: s.v, text: s.text }); };
  AC.shareRef = function (el) { var r = Bible.resolve(el.getAttribute('data-ref')); var txt = r && r.blocks[0] ? r.blocks[0].verses.map(function (v) { return v.t; }).join(' ') : ''; A.bridge.share('\u201C' + txt + '\u201D\n\u2014 ' + el.getAttribute('data-ref') + '\n\nRise With The Word'); };
  AC.cardFromRef = function (el) { var ref = el.getAttribute('data-ref'), r = Bible.resolve(ref); A.go('card', { text: r && r.blocks[0] ? r.blocks[0].verses.map(function (v) { return v.t; }).join(' ') : '', ref: ref }); };

  /* notes + bookmarks */
  SC.noteEdit = function (arg) {
    var notes = S.get('notes', []), ex = arg.id ? notes.filter(function (n) { return n.id === arg.id; })[0] : null;
    var h = '<div class="card"><b>' + esc(arg.ref) + '</b><p class="small muted">' + esc(arg.text || '') + '</p></div><label>Private note (stored only on this device)</label><textarea id="noteText">' + esc(ex ? ex.text : '') + '</textarea><div class="row"><button class="btn" data-act="noteSave">' + esc(t('save')) + '</button>' + (ex ? '<button class="btn danger" data-act="noteDelete">Delete</button>' : '') + '</div>';
    A.noteCtx = { arg: arg, ex: ex };
    return { title: t('notes'), html: h };
  };
  AC.noteSave = function () { var tx = A.$('#noteText').value.trim(), c = A.noteCtx, notes = S.get('notes', []); if (!tx) { A.toast('Write something first'); return; }
    if (c.ex) { c.ex.text = tx; c.ex.ts = Date.now(); notes = notes.map(function (n) { return n.id === c.ex.id ? c.ex : n; }); } else notes.unshift({ id: A.uid(), ref: c.arg.ref, code: c.arg.code, ch: c.arg.ch, v: c.arg.v, text: tx, ts: Date.now() });
    S.set('notes', notes); A.toast('\u2713 ' + t('saved')); A.back(); };
  AC.noteDelete = function () { var c = A.noteCtx; S.set('notes', S.get('notes', []).filter(function (n) { return n.id !== c.ex.id; })); A.back(); };
  AC.noteOpen = function (el) { var id = el.getAttribute('data-id'), n = S.get('notes', []).filter(function (x) { return x.id === id; })[0]; if (n) A.go('noteEdit', { id: n.id, ref: n.ref, code: n.code, ch: n.ch, v: n.v, text: '' }); };
  function marksHtml() {
    var bm = S.get('bm', []), notes = S.get('notes', []), hl = S.get('hl', {}), h = '<h3>' + esc(t('bookmarks')) + '</h3><div class="list">';
    h += bm.length ? bm.map(function (b) { return '<button class="item" data-act="openChapter" data-code="' + b.code + '" data-ch="' + b.ch + '"><b>' + esc(b.ref) + '</b><span>' + esc(b.text.slice(0, 90)) + '\u2026</span></button>'; }).join('') : '<p class="muted small">Tap a verse and choose Bookmarks.</p>';
    h += '</div><h3 style="margin-top:14px">' + esc(t('notes')) + '</h3><div class="list">';
    h += notes.length ? notes.map(function (n) { return '<button class="item" data-act="noteOpen" data-id="' + n.id + '"><b>' + esc(n.ref) + '</b><span>' + esc(n.text.slice(0, 100)) + '</span></button>'; }).join('') : '<p class="muted small">No notes yet.</p>';
    var hk = Object.keys(hl); h += '</div><h3 style="margin-top:14px">' + esc(t('highlights')) + ' (' + hk.length + ')</h3><div class="list">';
    hk.slice(-30).reverse().forEach(function (id) { var p = id.split(':'), b = Bible.byCode[p[0]]; if (!b) return; var c = Bible.chapter(p[0], +p[1]); var v = c && c.verses.filter(function (x) { return x.n === +p[2]; })[0]; h += '<button class="item" data-act="openChapter" data-code="' + p[0] + '" data-ch="' + p[1] + '"><b><span class="swatch" style="background:var(--hl' + hl[id] + ')"></span>' + esc(Bible.shortTitle(b) + ' ' + p[1] + ':' + p[2]) + '</b><span>' + esc(v ? v.t.slice(0, 90) : '') + '</span></button>'; });
    return h + '</div>';
  }

  /* ---------- SEARCH ---------- */
  var searchT;
  SC.search = function (arg) {
    var h = '<input type="search" id="q" placeholder="' + esc(t('search')) + ': love, \u201Cgood shepherd\u201D, John 3:16" value="' + esc(arg && arg.q || '') + '" autofocus><div id="results" class="list" style="margin-top:8px"></div>';
    return { title: t('search'), html: h, after: function () { var q = A.$('#q'); q.addEventListener('input', function () { clearTimeout(searchT); searchT = setTimeout(doSearch, 250); }); if (arg && arg.q) doSearch(); } };
  };
  AC.bsearch = function () { var q = A.$('#bsearch').value; A.go('search', { q: q }); };
  function doSearch() {
    var q = A.$('#q').value.trim(), box = A.$('#results'); if (!box) return;
    if (!q) { box.innerHTML = ''; return; }
    var out = '';
    if (Bible.ready) {
      var r = Bible.search(q, 60);
      if (r.ref) { var res = Bible.resolve(r.ref); out += res && res.blocks.length ? '<div class="card"><h3>' + esc(r.ref) + '</h3>' + passage(res) + '</div>' : '<p class="muted">Reference not found.</p>'; }
      else {
        out += '<p class="small muted">' + r.total + ' verse(s) found' + (r.total > r.hits.length ? ' \u2014 showing ' + r.hits.length : '') + '</p>';
        out += r.hits.map(function (e) { var txt = esc(e.t); r.words.forEach(function (w) { if (w.length > 1) txt = txt.replace(new RegExp('(' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig'), '<mark>$1</mark>'); }); return '<button class="item" data-act="openChapter" data-code="' + e.b.code + '" data-ch="' + e.c + '"><b>' + esc(Bible.shortTitle(e.b) + ' ' + e.c + ':' + e.v) + '</b><span style="color:var(--text)">' + txt + '</span></button>'; }).join('');
      }
    } else out += A.bibleMissing();
    var lib = A.librarySearch ? A.librarySearch(q) : '';
    box.innerHTML = out + lib;
  }

  /* ---------- PLANS ---------- */
  function chapters(code, from, to) { var a = []; for (var i = from; i <= to; i++) a.push({ code: code, ch: i }); return a; }
  function planDefs() {
    var cnt = function (c) { return Bible.byCode[c] ? Bible.byCode[c].chapters.length : 0; };
    return [
      { id: 'gospel30', name: '30-Day Gospel Journey', desc: 'Mark, the Passion and Resurrection in John, and the start of Acts', items: chapters('mk', 1, 16).concat(chapters('jn', 13, 21), chapters('acts', 1, 5)) },
      { id: 'john', name: 'The Gospel of John', desc: cnt('jn') + ' days', items: chapters('jn', 1, cnt('jn')) },
      { id: 'luke', name: 'The Gospel of Luke', desc: cnt('lk') + ' days', items: chapters('lk', 1, cnt('lk')) },
      { id: 'matthew', name: 'The Gospel of Matthew', desc: cnt('mt') + ' days', items: chapters('mt', 1, cnt('mt')) },
      { id: 'psalms30', name: '30 Days of Psalms', desc: 'Psalms 1\u201330 (Vulgate numbering)', items: chapters('ps', 1, 30) },
      { id: 'acts', name: 'Acts of the Apostles', desc: cnt('acts') + ' days', items: chapters('acts', 1, cnt('acts')) },
      { id: 'week7', name: '7-Day Starter Plan', desc: 'A gentle first week', items: [{ code: 'ps', ch: 22 }, { code: 'mt', ch: 5 }, { code: 'lk', ch: 15 }, { code: 'jn', ch: 3 }, { code: 'rom', ch: 8 }, { code: '1cor', ch: 13 }, { code: 'jn', ch: 20 }] }
    ].filter(function (p) { return p.items.every(function (i) { return Bible.byCode[i.code]; }); });
  }
  A.planDefs = planDefs;
  function plansHtml() {
    var prog = S.get('plans', {});
    return '<div class="list">' + planDefs().map(function (p) { var d = Object.keys((prog[p.id] || {}).done || {}).length; return '<button class="item" data-act="openPlan" data-id="' + p.id + '"><b>' + esc(p.name) + '</b><span>' + esc(p.desc) + ' \u00b7 ' + d + '/' + p.items.length + '</span><div class="progress" style="margin-top:6px"><i style="width:' + Math.round(100 * d / p.items.length) + '%"></i></div></button>'; }).join('') + '</div>';
  }
  AC.openPlan = function (el) { A.go('plan', el.getAttribute('data-id')); };
  SC.plan = function (id) {
    var p = planDefs().filter(function (x) { return x.id === id; })[0]; if (!p) return { html: '' };
    var prog = S.get('plans', {}), done = (prog[id] || {}).done || {}, next = -1;
    p.items.forEach(function (it, i) { if (next < 0 && !done[i]) next = i; });
    var h = '<div class="card"><h3>' + esc(p.name) + '</h3><p class="muted small">' + esc(p.desc) + '</p>' + (next >= 0 ? '<button class="btn block" data-act="openChapter" data-code="' + p.items[next].code + '" data-ch="' + p.items[next].ch + '">Day ' + (next + 1) + ' \u2192</button>' : '<p>\uD83C\uDF89 Plan complete!</p>') + '</div><div class="list">';
    h += p.items.map(function (it, i) { var b = Bible.byCode[it.code]; return '<div class="row"><button class="ib" data-act="planDone" data-id="' + id + '" data-i="' + i + '" aria-label="Done">' + (done[i] ? '\u2611' : '\u2610') + '</button><button class="item" style="flex:1" data-act="openChapter" data-code="' + it.code + '" data-ch="' + it.ch + '"><b>Day ' + (i + 1) + '</b><span>' + esc(Bible.shortTitle(b) + ' ' + it.ch) + '</span></button></div>'; }).join('') + '</div>';
    return { title: p.name, html: h };
  };
  AC.planDone = function (el) { var id = el.getAttribute('data-id'), i = el.getAttribute('data-i'), prog = S.get('plans', {}); prog[id] = prog[id] || { done: {} }; if (prog[id].done[i]) delete prog[id].done[i]; else { prog[id].done[i] = 1; A.mark('read'); } S.set('plans', prog); A.refresh(); };
})();
