/* Offline image-pack browser. Only catalogued bundled assets are shown; no network calls. */
(function(){
  'use strict';
  var W=window,A=W.RWTW,SC=A.screens,AC=A.actions,esc=A.esc;
  var CATALOG={categories:[],assets:[]};
  try { /* Static catalog is embedded here so file:// WebView does not need fetch(). */
    CATALOG=window.RWTW_IMAGE_PACKS||CATALOG;
  } catch(e){}
  var items=[
    {id:'feature-home',path:'images/feature/home-hero.jpg',category:'feature-art',title:'Welcome Home',alt:'Warm devotional artwork used on the app home screen'},
    {id:'feature-bible',path:'images/feature/bible-reader.jpg',category:'feature-art',title:'Bible Reader',alt:'Artwork representing Bible reading'},
    {id:'feature-calendar',path:'images/feature/liturgy-calendar.jpg',category:'feature-art',title:'Liturgical Calendar',alt:'Artwork representing the liturgical calendar'},
    {id:'feature-prayer',path:'images/feature/prayer-chapel.jpg',category:'feature-art',title:'Prayer Chapel',alt:'Peaceful chapel-themed devotional artwork'},
    {id:'feature-saints',path:'images/feature/saints-gallery.jpg',category:'feature-art',title:'Saints Gallery',alt:'Artwork representing saints and feast days'},
    {id:'feature-catechism',path:'images/feature/catechism-study.jpg',category:'feature-art',title:'Catechism Study',alt:'Artwork representing Catholic learning and study'},
    {id:'wallpaper-heroes',path:'images/wallpapers/rwtw1.jpg',category:'wallpapers',title:'Heroes of the Bible',alt:'Portrait-format Bible-themed wallpaper'},
    {id:'wallpaper-sunset',path:'images/wallpapers/rwtw2.jpg',category:'wallpapers',title:'The Sermon at Sunset',alt:'Portrait-format devotional wallpaper showing a sunset scene'},
    {id:'reference-1',path:'images/refs/ref1.jpg',category:'reference-art',title:'Wallpaper Style Reference 1',alt:'Style reference image for wallpaper creation'},
    {id:'reference-2',path:'images/refs/ref2.jpg',category:'reference-art',title:'Wallpaper Style Reference 2',alt:'Style reference image for wallpaper creation'}
  ];
  var cats=[['all','All images'],['wallpapers','Wallpapers'],['feature-art','App artwork'],['reference-art','Style references']];
  var active='all';
  function card(x){return '<article class="image-pack-card"><img loading="lazy" src="'+esc(x.path)+'" alt="'+esc(x.alt)+'"><strong>'+esc(x.title)+'</strong><small>'+esc(cats.filter(function(c){return c[0]===x.category;})[0]?.[1]||'Image pack')+'</small></article>';}
  SC.imagepacks=function(){var shown=items.filter(function(x){return active==='all'||x.category===active;});var h='<p class="muted">Browse the artwork already bundled with the app. These images work offline.</p><div class="image-pack-filter" role="group" aria-label="Filter image packs">'+cats.map(function(c){return '<button class="chip '+(active===c[0]?'on':'')+'" data-act="imagePackFilter" data-v="'+c[0]+'" aria-pressed="'+(active===c[0]?'true':'false')+'">'+c[1]+'</button>';}).join('')+'</div><div class="image-pack-grid">'+shown.map(card).join('')+'</div><div class="card"><h3>More image packs planned</h3><p>Bible stories, Jesus’ parables and miracles, Old Testament, New Testament, saints and feast days, prayer and Rosary, liturgical seasons, kids’ learning, and Scripture-card backgrounds.</p><p class="small muted">New packs should include creator/source, reuse licence, image dimensions, file hash and descriptive alt text. Unverified reference images must not be redistributed.</p></div>';return {title:'Image Packs',html:h};};
  AC.imagePackFilter=function(el){active=el.getAttribute('data-v')||'all';A.refresh();};
  function addTile(name,tile){var original=SC[name];if(!original)return;SC[name]=function(){var o=original.apply(null,arguments),i=o.html.lastIndexOf('</div>');if(i>=0)o.html=o.html.slice(0,i)+tile+o.html.slice(i);else o.html+=tile;return o;};}
  var tile='<button class="tile" data-act="go" data-arg="imagepacks"><span class="ico" aria-hidden="true">🖼️</span><b>Image Packs</b><span>Browse offline artwork by category</span></button>';
  addTile('discover',tile);addTile('me',tile);
})();
