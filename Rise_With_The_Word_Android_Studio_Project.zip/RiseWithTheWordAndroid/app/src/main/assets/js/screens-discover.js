(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, t = A.t, Lit = W.Liturgy, Bible = W.Bible, LN = W.RWTW_LEARN;
  var SC = A.screens, AC = A.actions;

  /* ---------- data assembly (built-in + synced packs) ---------- */
  function buildStories() {
    var list = (W.RWTW_STORIES_RAW || []).map(function (line, i) {
      var p = line.split('|');
      return { id: 's' + (i + 1), t: p[0], tags: p[1], title: p[2], ref: p[3], summary: p[4], lesson: p[5], prayer: p.slice(6).join('|') };
    });
    var extra = A.packs.stories;
    if (Array.isArray(extra)) extra.forEach(function (s) { if (!s || !s.id) return; var i = list.findIndex(function (x) { return x.id === s.id; }); if (i >= 0) list[i] = Object.assign(list[i], s); else list.push(s); });
    W.RWTW_STORIES = list; return list;
  }
  W.RWTW_APPLY_PACKS = function () { buildStories(); W.RWTW_QUIZ = (A.packs.quiz && A.packs.quiz.length ? LN.quiz.concat(A.packs.quiz) : LN.quiz); W.RWTW_TRIVIA = (A.packs.trivia && A.packs.trivia.length ? LN.trivia.concat(A.packs.trivia) : LN.trivia); };
  A.initContent = function () { A.loadPacks(); W.RWTW_APPLY_PACKS(); };

  function F_COUNT() { return W.RWTW_FAITH.topics.length; }
  SC.discover = function () {
    function tile(ico, title, sub, arg) { return '<button class="tile" data-act="go" data-arg="' + arg + '"><span class="ico">' + ico + '</span><b>' + esc(title) + '</b><span>' + esc(sub) + '</span></button>'; }
    var featureCards = [
      ['home-hero.jpg', 'Home & Daily Word', 'home'],
      ['bible-reader.jpg', 'Bible Reader', 'bible'],
      ['liturgy-calendar.jpg', 'Liturgy Calendar', 'calendar'],
      ['saints-gallery.jpg', 'Saints & Feast Days', 'saints'],
      ['catechism-study.jpg', 'Catechism Study', 'catechism'],
      ['prayer-chapel.jpg', 'Prayer & Reflection', 'pray']
    ];
    var visual = '<div class="feature-gallery" aria-label="Explore app features">' + featureCards.map(function (f) { return '<button class="feature-card" data-act="go" data-arg="' + f[2] + '"><img loading="lazy" src="images/feature/' + f[0] + '" alt=""><span>' + esc(f[1]) + '</span></button>'; }).join('') + '</div><h3 class="section-heading">Explore</h3>';
    return { title: t('discover'), html: visual + '<div class="grid">' + tile('\uD83D\uDC51', t('saint'), 'Saints by date', 'saints') + tile('\uD83D\uDDD3\uFE0F', t('calendar'), '2026\u20132031', 'calendar') + tile('\uD83D\uDCDA', t('stories'), W.RWTW_STORIES.length + ' stories', 'stories') + tile('\u2753', t('quiz'), 'Test yourself', 'quiz') + tile('\uD83D\uDCA1', t('trivia'), 'Daily fact', 'trivia') + tile('\uD83D\uDC6A', t('kids'), 'Kids & family', 'kids') + '<button class="tile" data-act="openPlans"><span class="ico">\uD83D\uDCDC</span><b>' + esc(t('plans')) + '</b><span>Bible plans</span></button>' + tile('\uD83C\uDF1F', t('challenges'), 'Advent, Lent, Easter, Mary', 'challenges') + tile('\uD83D\uDD0E', t('library'), 'Search everything', 'library') + tile('\u26EA', 'Learn the Faith', F_COUNT() + ' topics', 'faith') + tile('\uD83D\uDCD8', 'Glossary', 'Catholic terms', 'glossary') + tile('\uD83D\uDD16', 'Scripture by Topic', 'Verses for every need', 'topics') + tile('\uD83D\uDCD6', 'Catechism Classes 1–12', 'Offline study guides', 'catechism') + tile('\u23F3', 'Timeline', 'Bible & Church history', 'timeline') + '</div>' };
  };
  AC.openPlans = function () { A.setBibleTab('plans'); A.root('bible'); };

  /* ---------- stories ---------- */
  var sf = { filter: 'all', q: '' };
  SC.stories = function () {
    var h = '<input type="search" id="sq" placeholder="' + esc(t('search')) + '" value="' + esc(sf.q) + '"><div class="row" style="margin:6px 0">' + [['all', 'All'], ['OT', 'Old Testament'], ['NT', 'New Testament'], ['k', 'Children'], ['b', 'Beginners'], ['d', 'Deeper study'], ['fav', t('favorites')]].map(function (x) { return '<button class="chip ' + (sf.filter === x[0] ? 'on' : '') + '" data-act="sFilter" data-v="' + x[0] + '">' + esc(x[1]) + '</button>'; }).join('') + '</div><div id="slist"></div>';
    return { title: t('stories'), html: h, after: function () { A.$('#sq').addEventListener('input', function (e) { sf.q = e.target.value; renderStories(); }); renderStories(); } };
  };
  function renderStories() {
    var fav = S.get('fav', []).filter(function (f) { return f.type === 'story'; }).map(function (f) { return f.id; }), done = S.get('storiesRead', {}), q = sf.q.toLowerCase();
    var list = W.RWTW_STORIES.filter(function (s) {
      if (sf.filter === 'OT' || sf.filter === 'NT') { if (s.t !== sf.filter) return false; } else if (sf.filter === 'fav') { if (fav.indexOf(s.id) < 0) return false; } else if (sf.filter !== 'all' && (s.tags || '').indexOf(sf.filter) < 0) return false;
      return !q || (s.title + ' ' + s.ref + ' ' + s.summary).toLowerCase().indexOf(q) >= 0;
    });
    A.$('#slist').innerHTML = '<p class="small muted">' + list.length + ' stories</p><div class="list">' + list.map(function (s) { return '<button class="item" data-act="openStory" data-id="' + s.id + '"><b>' + (done[s.id] ? '\u2713 ' : '') + (fav.indexOf(s.id) >= 0 ? '\u2605 ' : '') + esc(A.L(s, 'title')) + '</b><span>' + esc(s.ref) + ' \u00b7 ' + (s.t === 'OT' ? 'Old Testament' : 'New Testament') + '</span></button>'; }).join('') + '</div>';
  }
  AC.sFilter = function (el) { sf.filter = el.getAttribute('data-v'); A.refresh(); };
  AC.openStory = function (el) { A.go('story', el.getAttribute('data-id')); };
  SC.story = function (id) {
    var s = W.RWTW_STORIES.filter(function (x) { return x.id === id; })[0]; if (!s) return { html: '' };
    A.recent('story', id, s.title);
    var fav = S.get('fav', []).some(function (f) { return f.id === id && f.type === 'story'; }), ref = s.ref.replace(/\s*\(.*?\)/g, '').trim();
    var h = '<div class="card"><div class="small muted">' + esc(s.ref) + '</div><h3 style="font-size:1.2rem;margin:4px 0">' + esc(A.L(s, 'title')) + '</h3><p class="reader">' + esc(A.L(s, 'summary')) + '</p></div>';
    h += '<div class="card"><h3>Lesson</h3><p>' + esc(A.L(s, 'lesson')) + '</p></div><div class="card"><h3>Prayer</h3><p class="prayer-text">' + esc(A.L(s, 'prayer')) + '</p></div>';
    h += '<div class="row"><button class="btn" data-act="storyRead" data-ref="' + esc(ref) + '" data-id="' + id + '">\uD83D\uDCD6 Read the Bible passage</button><button class="btn alt" data-act="favToggle" data-type="story" data-id="' + id + '" data-title="' + esc(s.title) + '">' + (fav ? '\u2605' : '\u2606') + ' ' + esc(t('favorites')) + '</button><button class="btn alt" data-act="storyShare" data-id="' + id + '">' + esc(t('share')) + '</button></div>';
    if (A.settings.lang === 'ml' && !s.summary_ml) h += '<p class="small muted">Malayalam version of this story will arrive through Content Sync.</p>';
    return { title: s.title, html: h };
  };
  AC.storyRead = function (el) { var done = S.get('storiesRead', {}); done[el.getAttribute('data-id')] = 1; S.set('storiesRead', done); A.mark('read'); A.go('refmulti', el.getAttribute('data-ref')); };
  SC.refmulti = function (ref) {
    if (!Bible.ready) return { title: ref, html: A.bibleMissing() };
    var parts = ref.split(/;\s*(?=[1-3]?\s*[A-Z])/), h = '';
    parts.forEach(function (p) { var res = Bible.resolve(p); h += res && res.blocks.length ? '<div class="card"><h3>' + esc(p) + '</h3>' + A.passageHtml(res) + '</div>' : '<p class="muted small">' + esc(p) + ': open this passage in the Bible tab.</p>'; });
    return { title: ref, html: h };
  };
  AC.storyShare = function (el) { var s = W.RWTW_STORIES.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0]; A.bridge.share(s.title + ' (' + s.ref + ')\n\n' + s.summary + '\n\nLesson: ' + s.lesson + '\n\nRise With The Word'); };

  /* ---------- saints ---------- */
  var saintQ = '';
  SC.saints = function (key) {
    var dt = key ? A.dateFromKey(key) : new Date(), d = A.dayInfo(dt), all = Lit.saintsOn(dt.getMonth() + 1, dt.getDate()).concat((d.celebrations || []).filter(function (c) { return !Lit.saintsOn(dt.getMonth() + 1, dt.getDate()).some(function (x) { return x.name === c.name; }); }));
    if (!A.settings.indianSaints) all = all.filter(function (x) { return x.rank !== 'L'; });
    var prev = Lit.key(Lit.add(dt, -1)), next = Lit.key(Lit.add(dt, 1));
    var h = '<div class="row sp" style="margin-bottom:10px"><button class="btn alt" data-act="saintDate" data-k="' + prev + '">\u2190</button><b>' + esc(Lit.fullName(dt)) + '</b><button class="btn alt" data-act="saintDate" data-k="' + next + '">\u2192</button></div>';
    h += '<div class="card"><div class="small muted">' + esc(d.title) + ' \u00b7 ' + A.colorDot(d.color) + esc(d.colorName) + '</div></div>';
    h += all.length ? all.map(saintCard).join('') : '<div class="card"><p>No saint is assigned to this date in the built-in calendar. Today the Church celebrates: <b>' + esc(d.title) + '</b>.</p><p class="small muted">More saints can be added through Content Sync.</p></div>';
    h += '<h3 style="margin:14px 0 6px">Archive</h3><input type="search" id="saintq" placeholder="Search saints by name" value="' + esc(saintQ) + '"><div id="saintres" class="list" style="margin-top:6px"></div><div class="row" style="margin-top:8px"><button class="btn" data-act="go" data-arg="saintsAll">All saints by feast day</button><button class="btn alt" data-act="go" data-arg="patrons">Find a patron saint</button></div><button class="btn alt block" style="margin-top:8px" data-act="go" data-arg="calendar">' + esc(t('calendar')) + '</button>';
    return { title: t('saint'), html: h, after: function () { A.$('#saintq').addEventListener('input', function (e) { saintQ = e.target.value; saintSearch(); }); saintSearch(); } };
  };
  A.sid = function (s) { return s.md + '|' + s.name; };
  function saintCard(s) {
    var d = W.RWTW_SAINT_DETAILS(s);
    return '<div class="card"><div class="small muted">' + esc(Lit.RANKS[s.rank] || '') + ' \u00b7 ' + esc(s.md.replace('-', '/')) + (d.years ? ' \u00b7 ' + esc(d.years) : '') + '</div><h3 style="font-size:1.1rem">' + esc(s.name) + '</h3><div>' + d.cats.map(function (c) { return '<span class="chip">' + esc(c) + '</span>'; }).join('') + '</div><p>' + esc(s.bio) + '</p>' + (d.patron ? '<p class="small"><b>Patron of / invoked for:</b> ' + esc(d.patron) + '</p>' : '') + '<div class="row"><button class="btn alt" data-act="saintOpen" data-id="' + esc(A.sid(s)) + '">Full profile</button><button class="btn alt" data-act="saintShare" data-n="' + esc(s.name) + '" data-b="' + esc(s.bio) + '">' + esc(t('share')) + '</button></div></div>';
  }
  function saintSearch() {
    var q = saintQ.trim().toLowerCase(), box = A.$('#saintres'); if (!box) return; if (!q) { box.innerHTML = ''; return; }
    var hits = Lit.allSaints().filter(function (s) { return (s.name + ' ' + s.bio + ' ' + W.RWTW_SAINT_DETAILS(s).patron).toLowerCase().indexOf(q) >= 0; }).slice(0, 25);
    box.innerHTML = hits.map(function (s) { var p = s.md.split('-'); return '<button class="item" data-act="saintOpen" data-id="' + esc(A.sid(s)) + '"><b>' + esc(s.name) + '</b><span>' + (+p[1]) + ' ' + Lit.MONTHS[+p[0] - 1] + '</span></button>'; }).join('') || '<p class="muted small">No match.</p>';
  }
  AC.saintDate = function (el) { A.go('saints', el.getAttribute('data-k'), { replace: true }); };
  AC.saintShare = function (el) { A.bridge.share(el.getAttribute('data-n') + '\n\n' + el.getAttribute('data-b') + '\n\nRise With The Word'); };

  /* ---------- calendar ---------- */
  var cal = { y: new Date().getFullYear(), m: new Date().getMonth() };
  SC.calendar = function () {
    var y = cal.y, m = cal.m, first = new Date(y, m, 1).getDay(), days = Lit.month(y, m), todayK = A.todayKey();
    var years = []; for (var i = 2026; i <= 2031; i++) years.push(i);
    var h = '<div class="row" style="margin-bottom:6px">' + years.map(function (yy) { return '<button class="chip ' + (yy === y ? 'on' : '') + '" data-act="calYear" data-v="' + yy + '">' + yy + '</button>'; }).join('') + '</div>';
    h += '<div class="row sp" style="margin-bottom:8px"><button class="btn alt" data-act="calMonth" data-d="-1">\u2190</button><b>' + Lit.MONTHS[m] + ' ' + y + '</b><button class="btn alt" data-act="calMonth" data-d="1">\u2192</button></div><div class="cal">';
    h += ['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(function (x) { return '<div class="h">' + x + '</div>'; }).join('');
    for (var b = 0; b < first; b++) h += '<button class="empty"></button>';
    days.forEach(function (d) { var big = d.rank === 'S' || d.rank === 'F' || d.dow === 0; h += '<button class="' + (d.key === todayK ? 'today ' : '') + (big ? 'big' : '') + '" data-act="goDate" data-k="' + d.key + '" aria-label="' + esc(d.title) + '"><span>' + d.date.getDate() + '</span><i class="col-' + d.color + '"></i></button>'; });
    h += '</div><div class="row" style="margin:10px 0">' + [['w', 'White'], ['r', 'Red'], ['g', 'Green'], ['v', 'Violet'], ['p', 'Rose']].map(function (c) { return '<span class="small">' + A.colorDot(c[0]) + c[1] + '&nbsp;&nbsp;</span>'; }).join('') + '</div>';
    var hl = days.filter(function (d) { return d.rank === 'S' || d.rank === 'F' || d.rank === 'M' || d.dow === 0 || d.rank === 'D'; });
    h += '<div class="list">' + hl.map(function (d) {
      var rd = W.RWTW_READINGS.forDay(d), refs = [];
      if (rd.first) refs.push('First: ' + rd.first);
      if (rd.psalm) refs.push('Psalm: ' + rd.psalm);
      if (rd.second) refs.push('Second: ' + rd.second);
      if (rd.alleluia || rd.gospelAcclamation) refs.push('Acclamation: ' + (rd.alleluia || rd.gospelAcclamation));
      if (rd.gospel) refs.push('Gospel: ' + rd.gospel);
      var status = rd.verified ? ('Verified source: ' + (rd.sourceName || 'approved source')) : (rd.source === 'plan' ? 'Bible reading plan only — not official Mass readings' : 'Reading references need verification against the India/diocesan Ordo');
      return '<button class="item" data-act="goDate" data-k="' + d.key + '"><b>' + d.date.getDate() + ' ' + Lit.DAYS[d.dow].slice(0, 3) + ' · ' + A.colorDot(d.color) + esc(d.title) + '</b><span>' + esc(d.rankName) + ' · ' + esc(d.key) + '</span>' + (refs.length ? '<span style="white-space:normal">' + esc(refs.join(' · ')) + '</span>' : '<span>No reading references available in the offline dataset.</span>') + '<span class="small muted">' + esc(status) + '</span></button>';
    }).join('') + '</div>';
    var D = Lit.dates(y), fmt = function (x) { return Lit.DAYS[x.getDay()].slice(0, 3) + ' ' + x.getDate() + ' ' + Lit.MONTHS[x.getMonth()].slice(0, 3); };
    h += '<div class="card" style="margin-top:12px"><h3>' + y + ' key dates</h3><p class="small">Ash Wednesday: ' + fmt(D.ash) + '<br>Easter: ' + fmt(D.easter) + '<br>Ascension: ' + fmt(D.ascension) + '<br>Pentecost: ' + fmt(D.pentecost) + '<br>Corpus Christi: ' + fmt(D.corpus) + '<br>Christ the King: ' + fmt(D.christKing) + '<br>Advent begins: ' + fmt(D.advent1) + '</p></div>';
    h += '<div class="banner">Roman Rite calendar, computed on your device. Dates of Epiphany, Ascension and Corpus Christi differ by country \u2014 set yours in Me \u2192 Settings and check your diocesan ordo. The Syro-Malabar and Syro-Malankara calendars are not mixed into this Roman calendar.</div>';
    return { title: t('calendar'), html: h };
  };
  AC.calYear = function (el) { cal.y = +el.getAttribute('data-v'); A.refresh(); };
  AC.calMonth = function (el) { cal.m += +el.getAttribute('data-d'); if (cal.m < 0) { cal.m = 11; cal.y--; } if (cal.m > 11) { cal.m = 0; cal.y++; } if (cal.y < 2026) cal.y = 2026; if (cal.y > 2031) cal.y = 2031; A.refresh(); };

  /* ---------- quiz ---------- */
  var qz = null;
  SC.quiz = function () {
    if (!qz) return { title: t('quiz'), html: '<div class="card"><h3>Scripture & Catholic Quiz</h3><p>10 random questions from ' + W.RWTW_QUIZ.length + '.</p><p class="small muted">Best score: ' + S.get('quizBest', 0) + '/10</p></div><button class="btn block" data-act="quizStart">Start</button>' };
    if (qz.i >= qz.q.length) { var best = Math.max(S.get('quizBest', 0), qz.score); S.set('quizBest', best); return { title: t('quiz'), html: '<div class="card center"><h3>' + qz.score + ' / ' + qz.q.length + '</h3><p>' + (qz.score >= 8 ? 'Excellent!' : qz.score >= 5 ? 'Good work!' : 'Keep learning!') + '</p></div><button class="btn block" data-act="quizStart">Play again</button>' }; }
    var q = qz.q[qz.i];
    return { title: t('quiz'), html: '<p class="small muted">Question ' + (qz.i + 1) + ' / ' + qz.q.length + '</p><div class="card"><h3>' + esc(q[0]) + '</h3></div>' + q[1].map(function (o, i) { var cls = qz.ans === null ? '' : (i === q[2] ? ' right' : (i === qz.ans ? ' wrong' : '')); return '<button class="q-opt' + cls + '" data-act="quizAns" data-i="' + i + '"' + (qz.ans !== null ? ' disabled' : '') + '>' + esc(o) + '</button>'; }).join('') + (qz.ans !== null ? '<div class="banner">' + esc(q[3]) + '</div><button class="btn block" data-act="quizNext">' + esc(t('next')) + '</button>' : '') };
  };
  AC.quizStart = function () { var all = W.RWTW_QUIZ.map(function (q) { return Array.isArray(q) ? q : [q.q, q.options, q.answer, q.explain || '']; }).slice(); for (var i = all.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), x = all[i]; all[i] = all[j]; all[j] = x; } qz = { q: all.slice(0, 10), i: 0, score: 0, ans: null }; A.refresh(); };
  AC.quizAns = function (el) { if (qz.ans !== null) return; qz.ans = +el.getAttribute('data-i'); if (qz.ans === qz.q[qz.i][2]) qz.score++; A.refresh(); };
  AC.quizNext = function () { qz.i++; qz.ans = null; A.refresh(); };

  /* ---------- trivia ---------- */
  var triv = null;
  SC.trivia = function () {
    var list = W.RWTW_TRIVIA, i = triv === null ? Math.floor(Date.now() / 86400000) % list.length : triv;
    return { title: t('trivia'), html: '<div class="card"><h3>Did you know?</h3><p class="reader">' + esc(list[i]) + '</p></div><div class="row"><button class="btn" data-act="trivNext">Another fact</button><button class="btn alt" data-act="trivShare">' + esc(t('share')) + '</button></div>', };
  };
  AC.trivNext = function () { triv = Math.floor(Math.random() * W.RWTW_TRIVIA.length); A.refresh(); };
  AC.trivShare = function () { var list = W.RWTW_TRIVIA, i = triv === null ? Math.floor(Date.now() / 86400000) % list.length : triv; A.bridge.share('Did you know? ' + list[i] + '\n\nRise With The Word'); };

  /* ---------- kids ---------- */
  SC.kids = function () {
    var K = LN.kids, h = '<div class="card"><h3>Prayers for children</h3>' + K.prayers.map(function (p) { return '<p><b>' + esc(p[0]) + '</b><br>' + esc(p[1]) + '</p>'; }).join('') + '</div>';
    h += '<div class="card"><h3>Family faith ideas</h3><ul>' + K.ideas.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>';
    h += '<div class="list"><button class="item" data-act="kidStories"><b>' + esc(t('stories')) + ' for children</b><span>Child-friendly Bible stories</span></button><button class="item" data-act="go" data-arg="rosary"><b>Family Rosary</b><span>Pray one decade together</span></button><button class="item" data-act="go" data-arg="quiz"><b>' + esc(t('quiz')) + '</b><span>Play together</span></button></div>';
    return { title: t('kids'), html: h };
  };
  AC.kidStories = function () { sf.filter = 'k'; A.go('stories'); };

  /* ---------- library ---------- */
  A.librarySearch = function (q) {
    q = q.trim().toLowerCase(); if (q.length < 2) return '';
    var P = W.RWTW_PRAYERS, out = '';
    var pr = P.order.filter(function (id) { return (P.prayers[id].title + ' ' + P.prayers[id].text).toLowerCase().indexOf(q) >= 0; }).slice(0, 6);
    var st = W.RWTW_STORIES.filter(function (s) { return (s.title + ' ' + s.summary + ' ' + s.lesson + ' ' + s.ref).toLowerCase().indexOf(q) >= 0; }).slice(0, 8);
    var sa = Lit.allSaints().filter(function (s) { return (s.name + ' ' + s.bio + ' ' + W.RWTW_SAINT_DETAILS(s).patron).toLowerCase().indexOf(q) >= 0; }).slice(0, 8);
    var nv = P.novenas.filter(function (n) { return (n.title + ' ' + n.when).toLowerCase().indexOf(q) >= 0; });
    var fa = W.RWTW_FAITH.topics.filter(function (x) { return (x[1] + ' ' + x[2] + ' ' + x[3].join(' ')).toLowerCase().indexOf(q) >= 0; }).slice(0, 5);
    var gl = W.RWTW_FAITH.glossary.filter(function (x) { return (x[0] + ' ' + x[1]).toLowerCase().indexOf(q) >= 0; }).slice(0, 4);
    var tr = W.RWTW_TRIVIA.filter(function (x) { return x.toLowerCase().indexOf(q) >= 0; }).slice(0, 3);
    if (pr.length + st.length + sa.length + nv.length + tr.length + fa.length + gl.length) out += '<h3 style="margin:12px 0 4px">' + esc(t('library')) + '</h3>';
    out += pr.map(function (id) { return '<button class="item" data-act="openPrayer" data-id="' + id + '"><b>\uD83D\uDE4F ' + esc(P.prayers[id].title) + '</b><span>' + esc(t('prayers')) + '</span></button>'; }).join('');
    out += nv.map(function (n) { return '<button class="item" data-act="go" data-arg="novena" data-arg2="' + n.id + '"><b>\uD83D\uDCC5 ' + esc(n.title) + '</b><span>' + esc(t('novenas')) + '</span></button>'; }).join('');
    out += st.map(function (s) { return '<button class="item" data-act="openStory" data-id="' + s.id + '"><b>\uD83D\uDCDA ' + esc(s.title) + '</b><span>' + esc(s.ref) + '</span></button>'; }).join('');
    out += sa.map(function (s) { return '<button class="item" data-act="saintOpen" data-id="' + esc(A.sid(s)) + '"><b>\uD83D\uDC51 ' + esc(s.name) + '</b><span>' + esc(t('saint')) + '</span></button>'; }).join('');
    out += fa.map(function (x) { return '<button class="item" data-act="go" data-arg="topic" data-arg2="' + x[0] + '"><b>\u26EA ' + esc(x[1]) + '</b><span>Learn the Faith</span></button>'; }).join('');
    out += gl.map(function (x) { return '<div class="item"><b>' + esc(x[0]) + '</b><span style="color:var(--text)">' + esc(x[1]) + '</span></div>'; }).join('');
    out += tr.map(function (x) { return '<div class="item"><span>\uD83D\uDCA1 ' + esc(x) + '</span></div>'; }).join('');
    return out;
  };
  SC.library = function () {
    return { title: t('library'), html: '<input type="search" id="lq" placeholder="Search prayers, stories, saints, novenas\u2026"><div id="lres" class="list" style="margin-top:8px"></div>', after: function () { A.$('#lq').addEventListener('input', function (e) { A.$('#lres').innerHTML = A.librarySearch(e.target.value) || '<p class="muted small">Type at least 2 letters.</p>'; }); } };
  };

  /* ---------- challenges ---------- */
  SC.challenges = function () {
    var prog = S.get('challenges', {});
    return { title: t('challenges'), html: '<div class="list">' + LN.challenges.map(function (c) { var d = Object.keys(prog[c.id] || {}).length; return '<button class="item" data-act="go" data-arg="challenge" data-arg2="' + c.id + '"><b>' + esc(c.title) + '</b><span>' + esc(c.subtitle) + ' \u00b7 ' + d + '/' + c.days + '</span><div class="progress" style="margin-top:6px"><i style="width:' + Math.round(100 * d / c.days) + '%"></i></div></button>'; }).join('') + '</div>' };
  };
  SC.challenge = function (id) {
    var c = LN.challenges.filter(function (x) { return x.id === id; })[0], done = S.get('challenges', {})[id] || {};
    return { title: c.title, html: '<div class="list">' + c.items.map(function (it, i) { return '<div class="row"><button class="ib" data-act="chDone" data-id="' + id + '" data-i="' + i + '" aria-label="Done">' + (done[i] ? '\u2611' : '\u2610') + '</button><div style="flex:1" class="item"><b>Day ' + (i + 1) + '</b><span style="color:var(--text)">' + esc(it) + '</span></div></div>'; }).join('') + '</div>' };
  };
  AC.chDone = function (el) { var all = S.get('challenges', {}), id = el.getAttribute('data-id'), i = el.getAttribute('data-i'); all[id] = all[id] || {}; if (all[id][i]) delete all[id][i]; else { all[id][i] = 1; A.mark('prayer'); } S.set('challenges', all); A.refresh(); };
})();
