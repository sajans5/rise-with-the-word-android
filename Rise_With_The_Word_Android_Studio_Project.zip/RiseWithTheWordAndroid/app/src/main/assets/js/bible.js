/* Bible access layer. Uses window.RWTW_FULL_BIBLE (built by tools/build_bible.py).
   Each book: { code, slug, title, chapters:[{n, verses:[{n,t}]}] }                               */
(function () {
  'use strict';
  var W = window, Bible = W.Bible = { ready: false, books: [], byCode: {}, OT: [], NT: [] };

  // code -> [display aliases usable in references / search]
  var ALIASES = {
    gn: ['genesis', 'gn', 'gen'], ex: ['exodus', 'ex', 'exo'], lv: ['leviticus', 'lv', 'lev'], nm: ['numbers', 'nm', 'num'], dt: ['deuteronomy', 'dt', 'deut'], jos: ['joshua', 'josue', 'jos'], jgs: ['judges', 'jgs', 'judg'], ru: ['ruth', 'ru'],
    '1sm': ['1 samuel', '1sam', '1sm', '1 kings (1 samuel)'], '2sm': ['2 samuel', '2sam', '2sm', '2 kings (2 samuel)'], '1kgs': ['1 kings', '1kgs', '3 kings'], '2kgs': ['2 kings', '2kgs', '4 kings'],
    '1chr': ['1 chronicles', '1chr', '1 paralipomenon'], '2chr': ['2 chronicles', '2chr', '2 paralipomenon'], ezr: ['ezra', 'ezr', '1 esdras'], neh: ['nehemiah', 'neh', '2 esdras'], tb: ['tobit', 'tb', 'tobias'], jdt: ['judith', 'jdt'], est: ['esther', 'est'],
    jb: ['job', 'jb'], ps: ['psalms', 'psalm', 'ps', 'pss'], prv: ['proverbs', 'prv', 'prov'], eccl: ['ecclesiastes', 'eccl', 'qoheleth', 'eccles'], song: ['song of songs', 'song', 'sg', 'canticle of canticles', 'canticles'], wis: ['wisdom', 'wis'], sir: ['sirach', 'sir', 'ecclesiasticus'],
    is: ['isaiah', 'isaias', 'is'], jer: ['jeremiah', 'jeremias', 'jer'], lam: ['lamentations', 'lam'], bar: ['baruch', 'bar'], ez: ['ezekiel', 'ezechiel', 'ez', 'ezek'], dn: ['daniel', 'dn', 'dan'], hos: ['hosea', 'osee', 'hos'], jl: ['joel', 'jl'], am: ['amos', 'am'], ob: ['obadiah', 'abdias', 'ob'],
    jon: ['jonah', 'jonas', 'jon'], mi: ['micah', 'micheas', 'mi'], na: ['nahum', 'na'], hb: ['habakkuk', 'habacuc', 'hb'], zep: ['zephaniah', 'sophonias', 'zep'], hg: ['haggai', 'aggeus', 'hg'], zec: ['zechariah', 'zacharias', 'zec'], mal: ['malachi', 'malachias', 'mal'],
    '1mc': ['1 maccabees', '1 machabees', '1mc', '1macc'], '2mc': ['2 maccabees', '2 machabees', '2mc', '2macc'],
    mt: ['matthew', 'mt', 'matt'], mk: ['mark', 'mk'], lk: ['luke', 'lk'], jn: ['john', 'jn'], acts: ['acts', 'acts of the apostles'], rom: ['romans', 'rom'], '1cor': ['1 corinthians', '1cor'], '2cor': ['2 corinthians', '2cor'], gal: ['galatians', 'gal'], eph: ['ephesians', 'eph'], phil: ['philippians', 'phil'], col: ['colossians', 'col'],
    '1thes': ['1 thessalonians', '1thes', '1thess'], '2thes': ['2 thessalonians', '2thes', '2thess'], '1tm': ['1 timothy', '1tm', '1tim'], '2tm': ['2 timothy', '2tm', '2tim'], ti: ['titus', 'ti'], phlm: ['philemon', 'phlm'], heb: ['hebrews', 'heb'], jas: ['james', 'jas'],
    '1pt': ['1 peter', '1pt', '1pet'], '2pt': ['2 peter', '2pt', '2pet'], '1jn': ['1 john', '1jn'], '2jn': ['2 john', '2jn'], '3jn': ['3 john', '3jn'], jude: ['jude'], rv: ['revelation', 'apocalypse', 'rv', 'rev']
  };
  var aliasMap = {};
  Object.keys(ALIASES).forEach(function (code) { ALIASES[code].forEach(function (a) { aliasMap[norm(a)] = code; }); });
  function norm(s) { return String(s).toLowerCase().replace(/[^a-z0-9]/g, ''); }
  Bible.codeFor = function (name) { return aliasMap[norm(name)] || null; };

  Bible.init = function () {
    var d = W.RWTW_FULL_BIBLE;
    if (!d || !Array.isArray(d.books) || !d.books.length) { Bible.ready = false; return false; }
    Bible.data = d; Bible.books = d.books; Bible.byCode = {};
    d.books.forEach(function (b, i) { b.idx = i; if (b.code) Bible.byCode[b.code] = b; });
    Bible.OT = d.books.slice(0, 46); Bible.NT = d.books.slice(46);
    Bible.ready = true; return true;
  };

  Bible.chapter = function (code, ch) {
    var b = Bible.byCode[code]; if (!b) return null;
    for (var i = 0; i < b.chapters.length; i++) if (b.chapters[i].n === ch) return b.chapters[i];
    return null;
  };

  /* Psalm numbering: lectionary uses Hebrew numbers; Douay-Rheims uses Vulgate numbers. */
  Bible.psalmToDR = function (n) {
    if (n <= 8) return [n]; if (n === 9 || n === 10) return [9]; if (n <= 113) return [n - 1]; if (n === 114 || n === 115) return [113]; if (n === 116) return [114, 115];
    if (n <= 146) return [n - 1]; if (n === 147) return [146, 147]; return [n];
  };

  /* Parse a reference like "Jn 3:16-21", "Lk 1:1-4; 4:14-21", "Is 52:13-53:12", "Ps 51:3-6,12-14", "Mark 4". */
  Bible.parseRef = function (str) {
    if (!str) return null;
    var s = String(str).replace(/[\u2013\u2014]/g, '-').trim();
    var m = s.match(/^((?:[1-3]\s*)?[A-Za-z][A-Za-z .]*?(?:\s+of\s+(?:the\s+)?[A-Za-z]+)*)\s*(\d.*)?$/);
    if (!m) return null;
    var code = Bible.codeFor(m[1]); if (!code) return null;
    var rest = (m[2] || '').trim(), parts = rest ? rest.split(';') : [], ranges = [], cur = null;
    if (!parts.length) return { code: code, ranges: [{ c1: 1, v1: 1, c2: 9999, v2: 9999, whole: true }], whole: true };
    parts.forEach(function (part) {
      part = part.trim(); if (!part) return;
      var mm = part.match(/^(\d+):(.*)$/);
      if (mm) { cur = +mm[1]; part = mm[2]; }
      else if (/^\d+(-\d+)?$/.test(part) && cur === null) {
        var cc = part.split('-'); ranges.push({ c1: +cc[0], v1: 1, c2: +(cc[1] || cc[0]), v2: 9999 }); return;
      }
      if (cur === null) return;
      part.split(',').forEach(function (piece) {
        piece = piece.trim(); if (!piece) return;
        var x = piece.match(/^(\d+)[a-z]*-(\d+):(\d+)[a-z]*$/i);
        if (x) { ranges.push({ c1: cur, v1: +x[1], c2: +x[2], v2: +x[3] }); cur = +x[2]; return; }
        x = piece.match(/^(\d+)[a-z]*(?:-(\d+)[a-z]*)?$/i);
        if (x) { ranges.push({ c1: cur, v1: +x[1], c2: cur, v2: +(x[2] || x[1]) }); return; }
        x = piece.match(/^(\d+):(\d+)[a-z]*$/i);
        if (x) { cur = +x[1]; ranges.push({ c1: cur, v1: +x[2], c2: cur, v2: +x[2] }); }
      });
    });
    if (!ranges.length) return null;
    return { code: code, ranges: ranges };
  };

  /* Resolve the same citation against the bundled Malayalam catalogue. This does not
     claim that the catalogue contains all 73 texts; seven Deuterocanonical books remain metadata-only. */
  Bible.resolveMalayalam = function (refStr) {
    var data = W.RWTW_MALAYALAM_BIBLE;
    if (!data || !Array.isArray(data.books)) return null;
    var p = Bible.parseRef(refStr); if (!p) return null;
    var book = null;
    for (var i = 0; i < data.books.length; i++) {
      var candidate = data.books[i];
      if (Bible.codeFor(candidate.englishTitle || candidate.title || '') === p.code) { book = candidate; break; }
    }
    if (!book) return { title: refStr, book: null, blocks: [], notes: ['ഈ പുസ്തകത്തിന്റെ മലയാളം പാഠം നിലവിലെ ഓഫ്‌ലൈൻ ഡാറ്റാബേസിൽ ലഭ്യമല്ല.'] };
    function chNum(chNo) { for (var j=0;j<book.chapters.length;j++) if (+book.chapters[j].n === +chNo) return book.chapters[j]; return null; }
    var out = { title: refStr, book: book, code: p.code, blocks: [], notes: [] };
    p.ranges.forEach(function (r) {
      var last = Math.min(r.c2, book.chapters.length);
      for (var cn=r.c1; cn<=last; cn++) {
        var ch=chNum(cn); if (!ch) continue;
        var verses=ch.verses.filter(function(v){
          if (cn===r.c1 && v.n<r.v1) return false;
          if (cn===r.c2 && v.n>r.v2) return false;
          return true;
        }).map(function(v){ return {c:cn,n:v.n,t:v.t}; });
        if (verses.length) out.blocks.push({label:(book.malayalamTitle || book.title)+' '+cn, code:p.code, chapter:cn, verses:verses});
      }
    });
    if (!out.blocks.length) out.notes.push('ഈ ഭാഗം നിലവിലെ മലയാളം ഓഫ്‌ലൈൻ പാഠത്തിൽ കണ്ടെത്താനായില്ല.');
    return out;
  };

  /* Resolve a reference string to text. Returns {title, blocks:[{label, verses:[{c,n,t}]}], notes:[]} or null. */
  Bible.resolve = function (refStr) {
    if (!Bible.ready) return null;
    var p = Bible.parseRef(refStr); if (!p) return null;
    var b = Bible.byCode[p.code]; if (!b) return null;
    var out = { title: refStr, book: b, code: p.code, blocks: [], notes: [] };
    if (p.code === 'ps') {
      var seen = {};
      p.ranges.forEach(function (r) {
        Bible.psalmToDR(r.c1).forEach(function (dr) {
          if (seen[dr]) return; seen[dr] = 1; var ch = Bible.chapter('ps', dr); if (!ch) return;
          out.blocks.push({ label: 'Psalm ' + dr, code: 'ps', chapter: dr, verses: ch.verses.map(function (v) { return { c: dr, n: v.n, t: v.t }; }) });
          if (dr !== r.c1) out.notes.push('Psalm ' + r.c1 + ' (Hebrew numbering) is Psalm ' + dr + ' in the Douay\u2013Rheims. Verse numbers can differ, so the whole psalm is shown.');
        });
      });
      return out;
    }
    p.ranges.forEach(function (r) {
      var vs = [], last = Math.min(r.c2, b.chapters[b.chapters.length - 1].n);
      b.chapters.forEach(function (ch) {
        if (ch.n < r.c1 || ch.n > last) return;
        ch.verses.forEach(function (v) {
          if (ch.n === r.c1 && v.n < r.v1) return;
          if (ch.n === r.c2 && v.n > r.v2) return;
          vs.push({ c: ch.n, n: v.n, t: v.t });
        });
      });
      if (vs.length) {
        var chapterOnly = r.v2 >= 9999;
        var lab = b.title.replace(/\s*\(.*\)$/, '') + ' ' + r.c1 + (p.whole || chapterOnly ? '' : ':' + r.v1) + (r.c2 !== r.c1 || r.v2 !== r.v1 ? (r.c2 !== r.c1 ? '\u2013' + r.c2 + (chapterOnly ? '' : ':' + r.v2) : (chapterOnly ? '' : '\u2013' + r.v2)) : '');
        out.blocks.push({ label: lab, code: p.code, chapter: r.c1, verses: vs });
      }
    });
    if (!out.blocks.length) { out.notes.push('This passage was not found in the Douay\u2013Rheims numbering.'); }
    else if (/^(Ps|Psalm)/i.test(refStr) === false && ['jl', 'mal', 'hos', 'mi', 'zec', 'est', 'dn', 'jer', 'prv', 'sir'].indexOf(p.code) >= 0) out.notes.push('Chapter or verse numbers in this book may differ slightly from modern Bibles.');
    return out;
  };

  Bible.shortTitle = function (b) { return b.title.replace(/\s*\(.*\)$/, ''); };

  /* Full-text search. */
  var flat = null;
  function buildFlat() {
    flat = [];
    Bible.books.forEach(function (b) { b.chapters.forEach(function (c) { c.verses.forEach(function (v) { flat.push({ b: b, c: c.n, v: v.n, t: v.t, l: v.t.toLowerCase() }); }); }); });
  }
  Bible.search = function (q, limit) {
    limit = limit || 60; q = (q || '').trim(); if (!q || !Bible.ready) return { ref: null, hits: [], total: 0 };
    var ref = Bible.parseRef(q);
    if (ref) return { ref: q, hits: [], total: 0 };
    if (!flat) buildFlat();
    var words = q.toLowerCase().split(/\s+/).filter(function (w) { return w.length > 0; });
    var phrase = q.toLowerCase(), hits = [], phraseHits = [], total = 0;
    for (var i = 0; i < flat.length; i++) {
      var e = flat[i], ok = true;
      for (var k = 0; k < words.length; k++) if (e.l.indexOf(words[k]) < 0) { ok = false; break; }
      if (!ok) continue; total++;
      if (words.length > 1 && e.l.indexOf(phrase) >= 0) { if (phraseHits.length < limit) phraseHits.push(e); } else if (hits.length < limit) hits.push(e);
    }
    return { ref: null, hits: phraseHits.concat(hits).slice(0, limit), total: total, words: words };
  };
  W.Bible = Bible;
})();
