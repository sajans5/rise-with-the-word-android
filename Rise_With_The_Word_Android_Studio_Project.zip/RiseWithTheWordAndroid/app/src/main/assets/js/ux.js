/* Friendly, accessible interface:
   - Easy mode (big buttons, fewer items), high contrast, bold text, extra spacing, reduced motion, larger buttons
   - Read aloud (the phone's own text-to-speech: English and Malayalam when the voice is installed)
   - Welcome guide for first-time users, simpler Home with big buttons, search & ask
   - Easy "set up with GitHub" helper for automatic content updates */
(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, SC = A.screens, AC = A.actions, AB = W.AndroidBridge || null, Lit = W.Liturgy;

  /* ---------- accessibility attributes ---------- */
  var apply0 = A.applySettings;
  A.applySettings = function () {
    apply0(); var r = document.documentElement, s = A.settings;
    r.setAttribute('data-bold', s.boldText ? '1' : ''); r.setAttribute('data-space', s.spacing ? '1' : '');
    r.setAttribute('data-motion', s.reduceMotion ? 'reduce' : ''); r.setAttribute('data-big', (s.bigButtons || s.easy) ? '1' : '');
  };
  A.applySettings();

  var oSettings = SC.settings;
  SC.settings = function () {
    var o = oSettings(), s = A.settings;
    function chk(k, label) { return '<p><label style="color:var(--text)"><input type="checkbox" data-a11y="' + k + '"' + (s[k] ? ' checked' : '') + '> ' + esc(label) + '</label></p>'; }
    var card = '<div class="card"><h3>\u267F Easier to use</h3>' + chk('easy', 'Easy mode: big buttons and a simpler Home') +
      '<label>Text size</label><div class="row">' + [['Normal', 1], ['Large', 1.25], ['Extra large', 1.5], ['Huge', 1.8]].map(function (x) { return '<button class="chip ' + (s.fs === x[1] ? 'on' : '') + '" data-act="a11yFs" data-v="' + x[1] + '">' + x[0] + '</button>'; }).join('') + '</div>' +
      chk('contrastTheme', 'High contrast (black and yellow)') + chk('boldText', 'Bold text') + chk('spacing', 'Extra line and letter spacing') + chk('reduceMotion', 'Reduce motion') + chk('bigButtons', 'Larger buttons') +
      '<p class="small muted">Read aloud: tap the round \uD83D\uDD0A button on reading screens. It uses your phone\u2019s voice; for Malayalam install the voice in Android Settings \u2192 Text-to-speech.</p><button class="btn alt" data-act="testVoice">\uD83D\uDD0A Test voice</button></div>';
    o.html = card + o.html; return o;
  };
  document.addEventListener('change', function (e) {
    var k = e.target && e.target.getAttribute && e.target.getAttribute('data-a11y'); if (!k) return;
    if (k === 'contrastTheme') { A.settings.theme = e.target.checked ? 'contrast' : 'auto'; } else A.settings[k] = e.target.checked;
    A.saveSettings(); A.refresh();
  });
  AC.a11yFs = function (el) { A.settings.fs = parseFloat(el.getAttribute('data-v')); A.saveSettings(); A.refresh(); };
  AC.testVoice = function () { speak(A.settings.lang === 'ml' ? '\u0D28\u0D2E\u0D38\u0D4D\u0D15\u0D3E\u0D30\u0D02' : 'Hello. This is the read aloud voice of Rise With The Word.'); };

  /* ---------- read aloud ---------- */
  var speaking = false;
  function speak(text) {
    if (!AB || !AB.speak) { A.toast('Read aloud works in the installed app'); return; }
    var r = AB.speak(text, A.settings.lang === 'ml' ? 'ml' : 'en');
    if (r === 'ok') { speaking = true; } else if (r === 'nolang') A.toast('Voice not installed. Android Settings \u2192 Text-to-speech \u2192 install the voice.'); else A.toast('The voice is starting. Tap again in a moment.');
  }
  function stopSpeak() { if (speaking && AB && AB.stopSpeaking) AB.stopSpeaking(); speaking = false; }
  var LISTEN = ['today', 'story', 'prayer', 'saintPage', 'faqView', 'problem', 'topic', 'need', 'news', 'ask', 'refview', 'refmulti', 'vtopic', 'chapter', 'litany', 'saints', 'aiLibrary', 'exam', 'novena'];
  A.onRendered = function (c) {
    stopSpeak(); var old = document.querySelector('.listen'); if (old) old.remove();
    if (LISTEN.indexOf(c.name) < 0) return;
    var b = document.createElement('button'); b.className = 'listen'; b.setAttribute('aria-label', 'Read this page aloud'); b.textContent = '\uD83D\uDD0A';
    b.addEventListener('click', function () {
      if (speaking) { stopSpeak(); b.classList.remove('on'); return; }
      var m = document.querySelector('main').cloneNode(true);
      Array.prototype.slice.call(m.querySelectorAll('button, select, textarea, input, sup, .chip, .kbd, nav')).forEach(function (n) { n.remove(); });
      m.innerHTML = m.innerHTML.replace(/<\/(p|div|h[1-6]|li|b|span|label)>/gi, '</$1> ');
      var t = (m.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 14000); if (!t) return;
      speak(t); if (speaking) b.classList.add('on');
    });
    document.body.appendChild(b);
  };

  /* ---------- Home (friendly) ---------- */
  function big(ico, title, sub, act, arg, arg2) { return '<button class="bigbtn" data-act="' + act + '" data-arg="' + arg + '"' + (arg2 ? ' data-arg2="' + arg2 + '"' : '') + '><span class="ico">' + ico + '</span><span><b>' + esc(title) + '</b>' + (sub ? '<span class="s">' + esc(sub) + '</span>' : '') + '</span></button>'; }
  function tile(ico, label, act, arg, arg2) { return '<button class="tile" style="min-height:96px;align-items:center;text-align:center" data-act="' + act + '" data-arg="' + arg + '"' + (arg2 ? ' data-arg2="' + arg2 + '"' : '') + '><span class="ico" style="font-size:2rem">' + ico + '</span><b>' + esc(label) + '</b></button>'; }
  function plain(md) { return String(md || '').replace(/^#+\s.*$/gm, '').replace(/[*_>`#-]/g, '').replace(/\s+/g, ' ').trim(); }
  function autoCard(kind, key, title, arg) {
    var v = A.aiStore.all()[kind + ':' + key + ':' + (A.settings.lang === 'ml' ? 'ml' : 'en')]; if (!v) return '';
    return '<button class="item" style="margin-bottom:10px" data-act="go" data-arg="' + arg + '" data-arg2="' + key + '"><b>\u2728 ' + esc(title) + '</b><span style="color:var(--text)">' + esc(plain(v.text).slice(0, 170)) + '\u2026</span><span>AI-written \u00b7 tap to read</span></button>';
  }
  SC.home = function () {
    var now = new Date(), d = A.dayInfo(now), rd = W.RWTW_READINGS.forDay(d), hr = now.getHours(), s = A.settings, key = A.todayKey();
    var greet = hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening';
    var h = '<h2 style="margin:2px 0">' + greet + ' \uD83D\uDE4F</h2><p class="muted" style="margin:0 0 10px">' + esc(Lit.fullName(now)) + '</p>';
    h += '<button class="item" style="margin-bottom:10px" data-act="go" data-arg="search"><b>\uD83D\uDD0D Search or ask a question</b><span>Bible, prayers, saints, answers and the internet</span></button>';
    h += '<div class="hero"><div class="eyebrow">' + esc(d.seasonName) + '</div><h2>' + esc(d.title) + '</h2><p>' + A.colorDot(d.color) + esc(d.colorName) + ' \u00b7 ' + esc(d.rankName) + '</p></div>';
    h += big('\uD83D\uDCD6', 'Today\u2019s Gospel', rd.gospel || '', 'go', 'today');
    h += '<div class="grid" style="margin-bottom:12px">' + tile('\uD83D\uDCD6', 'Bible', 'tab', 'bible') + tile('\uD83D\uDCFF', 'Rosary', 'go', 'rosary') + tile('\uD83D\uDE4F', 'Prayers', 'tab', 'pray') + tile('\uD83D\uDC51', 'Saint of the Day', 'go', 'saints') +
      tile('\uD83D\uDCAC', 'Ask a Question', 'go', 'ask') + tile('\uD83E\uDDED', 'Catholic Guide', 'go', 'guide') + tile('\uD83D\uDCDA', 'Bible Stories', 'go', 'stories') + tile('\uD83D\uDDD3\uFE0F', 'Calendar', 'go', 'calendar') + '</div>';
    if (!s.easy) {
      h += autoCard('day', key, 'Today\u2019s reflection', 'today') + autoCard('news', key, 'Today in the Church', 'news');
      if (W.RWTW_CONFIG !== undefined && A.ai && A.ai.hasKey() && !A.aiStore.all()['news:' + key + ':' + (s.lang === 'ml' ? 'ml' : 'en')]) h += '<button class="item" style="margin-bottom:10px" data-act="go" data-arg="news"><b>\uD83D\uDCF0 Today in the Church</b><span>Get today\u2019s Church news</span></button>';
      var vref = A.verseOfDay(now), vres = W.Bible.ready ? W.Bible.resolve(vref) : null, vt = vres && vres.blocks[0] ? vres.blocks[0].verses.map(function (v) { return v.t; }).join(' ') : '';
      h += '<div class="card"><h3>' + esc(A.t('verse')) + '</h3>' + (vt ? '<p class="reader">\u201C' + esc(vt) + '\u201D</p>' : '') + '<p class="small muted">' + esc(vref) + '</p><div class="row"><button class="btn alt" data-act="cardFromRef" data-ref="' + esc(vref) + '">' + esc(A.t('cards')) + '</button><button class="btn alt" data-act="shareRef" data-ref="' + esc(vref) + '">' + esc(A.t('share')) + '</button></div></div>';
      var last = S.get('lastRead', null); if (last) h += big('\u25B6\uFE0F', 'Continue reading', last.title, 'openChapter', 'x').replace('data-act="openChapter" data-arg="x"', 'data-act="openChapter" data-code="' + last.code + '" data-ch="' + last.ch + '"');
      var cu = A.comingUp ? A.comingUp() : []; if (cu.length) h += '<div class="card"><h3>Coming up</h3>' + cu.map(function (x) { return '<button class="item" style="margin-bottom:6px" data-act="goDate" data-k="' + x.d.key + '"><b>' + A.colorDot(x.d.color) + esc(x.d.title) + '</b><span>' + (x.n === 1 ? 'Tomorrow' : 'In ' + x.n + ' days') + '</span></button>'; }).join('') + '</div>';
      if (s.streaksOn) { var did = !!S.get('days', {})[key]; h += '<div class="card"><div class="row sp"><div><h3>' + esc(A.t('streak')) + '</h3><span class="muted small">' + A.streak() + ' day(s) \u00b7 ' + A.weekCount() + '/' + s.weeklyGoal + ' this week</span></div>' + (did ? '<span class="chip on">\u2713 ' + esc(A.t('today')) + '</span>' : '<button class="btn alt" data-act="prayedToday">I prayed today</button>') + '</div></div>'; }
      if (A.social) { var so = A.social(); h += '<div class="card"><h3>Stay connected</h3><div class="row">' + ['youtube', 'instagram', 'facebook'].map(function (k) { return '<button class="chip" data-act="socOpen" data-u="' + esc(so[k].url) + '" data-t="' + esc(so[k].label) + '">' + esc(so[k].label) + '</button>'; }).join('') + '<button class="chip on" data-act="go" data-arg="social">Videos</button></div></div>'; if (A.ytRefresh) setTimeout(function () { A.ytRefresh(false); }, 1500); }
    } else {
      h += big('\u2699\uFE0F', 'More', 'Everything else in the app', 'tab', 'discover');
    }
    return { title: 'Rise With The Word', html: h, actions: '<button class="ib" data-act="go" data-arg="search" aria-label="Search">\uD83D\uDD0D</button>' };
  };

  /* search screen gets friendlier heading */
  var oSearch = SC.search; SC.search = function (arg) { var o = oSearch(arg); o.title = 'Search & Ask'; return o; };

  /* ---------- welcome guide ---------- */
  SC.welcome = function () {
    var s = A.settings, h = '<div class="hero"><div class="eyebrow">Welcome</div><h2>Rise With The Word</h2><p>Let\u2019s set up the app so it is comfortable for you. You can change everything later in Me \u2192 Settings.</p></div>';
    function row(label, items) { return '<div class="card"><h3>' + esc(label) + '</h3><div class="row">' + items.map(function (x) { return '<button class="chip ' + (x[2] ? 'on' : '') + '" style="font-size:1.05rem;padding:12px 18px" data-act="' + x[0] + '" data-v="' + x[1] + '">' + x[3] + '</button>'; }).join('') + '</div></div>'; }
    h += row('1. Language', [['wzLang', 'en', s.lang === 'en', 'English'], ['wzLang', 'ml', s.lang === 'ml', '\u0D2E\u0D32\u0D2F\u0D3E\u0D33\u0D02']]);
    h += row('2. Text size', [['wzFs', '1', s.fs === 1, 'Normal'], ['wzFs', '1.25', s.fs === 1.25, 'Large'], ['wzFs', '1.5', s.fs === 1.5, 'Extra large']]);
    h += row('3. Style', [['wzMode', 'easy', !!s.easy, 'Easy (big buttons)'], ['wzMode', 'full', !s.easy, 'Full (all features)']]);
    h += row('4. Colours', [['wzTheme', 'light', s.theme === 'light', 'Light'], ['wzTheme', 'dark', s.theme === 'dark', 'Dark'], ['wzTheme', 'contrast', s.theme === 'contrast', 'High contrast'], ['wzTheme', 'auto', s.theme === 'auto', 'Automatic']]);
    h += '<div class="card"><h3>5. Daily prayer reminder (optional)</h3><button class="btn alt" data-act="go" data-arg="reminders">Set reminders</button></div>';
    h += '<div class="card"><h3>6. Internet features (optional)</h3><p class="small muted">Search the internet, ask questions and get new daily content written automatically. Needs a free Google Gemini key (takes 2 minutes).</p><button class="btn alt" data-act="go" data-arg="ask">Set up internet features</button></div>';
    h += '<button class="btn block" style="min-height:56px;font-size:1.1rem" data-act="wzDone">Start using the app</button>';
    return { title: 'Welcome', html: h };
  };
  AC.wzLang = function (el) { A.settings.lang = el.getAttribute('data-v'); A.saveSettings(); A.refresh(); };
  AC.wzFs = function (el) { A.settings.fs = parseFloat(el.getAttribute('data-v')); A.saveSettings(); A.refresh(); };
  AC.wzMode = function (el) { A.settings.easy = el.getAttribute('data-v') === 'easy'; if (A.settings.easy && A.settings.fs < 1.25) A.settings.fs = 1.25; A.saveSettings(); A.refresh(); };
  AC.wzTheme = function (el) { A.settings.theme = el.getAttribute('data-v'); A.saveSettings(); A.refresh(); };
  AC.wzDone = function () { A.settings.onboarded = true; A.saveSettings(); A.root('home'); };
  setTimeout(function () { if (!A.settings.onboarded && A.cur && A.cur.name === 'home') A.go('welcome'); }, 600);
  var oMe = SC.me; SC.me = function () { var o = oMe(), i = o.html.lastIndexOf('</div>'); o.html = o.html.slice(0, i) + '<button class="tile" data-act="go" data-arg="welcome"><span class="ico">\uD83D\uDC4B</span><b>Welcome guide</b><span>Language, text size, style</span></button>' + o.html.slice(i); return o; };

  /* ---------- Discover: add Guide tiles ---------- */
  var oDisc = SC.discover; SC.discover = function () {
    var o = oDisc(), i = o.html.lastIndexOf('</div>');
    o.html = o.html.slice(0, i) + '<button class="tile" data-act="go" data-arg="guide"><span class="ico">\uD83E\uDDED</span><b>Catholic Guide</b><span>Answers, Problem Solver, India</span></button><button class="tile" data-act="go" data-arg="ask"><span class="ico">\uD83C\uDF10</span><b>Ask the Web</b><span>Google-powered answers</span></button><button class="tile" data-act="go" data-arg="news"><span class="ico">\uD83D\uDCF0</span><b>Today in the Church</b><span>Daily news</span></button><button class="tile" data-act="go" data-arg="sites"><span class="ico">\uD83C\uDF0D</span><b>Trusted websites</b><span>Vatican, USCCB, CBCI\u2026</span></button>' + o.html.slice(i);
    return o;
  };

  /* ---------- friendlier Content Sync ---------- */
  var oSync = SC.sync;
  SC.sync = function () {
    var o = oSync(), m = S.get('syncMeta', {}), cur = A.feedUrl(), mm = cur.match(/github\.com\/([^/]+)\/([^/]+)/) || cur.match(/https:\/\/([^.]+)\.github\.io\/([^/]+)/) || [];
    var hint = m.status === 'error' ? '<div class="banner" style="border-left-color:var(--danger)"><b>Could not update.</b> ' + esc(m.message || '') + '<br>Tips: make sure the repository is public and <span class="kbd">manifest.json</span> is in it. Or use the easy setup below.</div>' : '';
    var helper = '<div class="card"><h3>Easy setup with GitHub</h3><label>GitHub username</label><input type="text" id="ghU" value="' + esc(mm[1] || '') + '" autocapitalize="none"><label>Repository name</label><input type="text" id="ghR" value="' + esc(mm[2] || '') + '" autocapitalize="none"><button class="btn block" style="margin-top:8px" data-act="ghSet">Use this repository and check now</button><p class="small muted">Example: <span class="kbd">sajans5</span> and <span class="kbd">rise-with-the-word-content</span>. The app finds <span class="kbd">manifest.json</span> by itself (works with or without GitHub Pages).</p></div>';
    o.html = hint + o.html + helper; return o;
  };
  AC.ghSet = function () {
    var u = A.$('#ghU').value.trim(), r = A.$('#ghR').value.trim().replace(/\.git$/, '');
    if (!/^[A-Za-z0-9][A-Za-z0-9-]*$/.test(u) || !/^[A-Za-z0-9._-]+$/.test(r)) { A.toast('Please enter your GitHub name and repository name'); return; }
    A.settings.feedUrl = 'https://github.com/' + u + '/' + r + '/manifest.json'; A.saveSettings(); A.bridge.setFeedUrl(A.feedUrl());
    if (!A.bridge.syncNow(A.feedUrl(), false)) A.toast('Sync works in the installed app'); else A.toast('Checking\u2026');
  };
})();
