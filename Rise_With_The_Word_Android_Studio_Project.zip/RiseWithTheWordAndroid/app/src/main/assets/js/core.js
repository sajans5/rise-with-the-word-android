/* Core: configuration, storage, translations, native bridge, router. */
(function () {
  'use strict';
  var W = window;
  var APP = W.RWTW = { version: '2.3.0', screens: {}, actions: {}, stack: [], cur: null };

  /* ---------- config ---------- */
  var cfg = W.RWTW_CONFIG || {};
  APP.cfg = cfg;

  /* ---------- helpers ---------- */
  APP.$ = function (s, r) { return (r || document).querySelector(s); };
  APP.$$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  APP.esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  APP.pad = function (n) { return (n < 10 ? '0' : '') + n; };
  APP.todayKey = function () { return W.Liturgy.key(new Date()); };
  APP.uid = function () { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); };

  /* ---------- storage (localStorage, namespaced) ---------- */
  APP.store = {
    get: function (k, d) { try { var v = localStorage.getItem('rwtw.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('rwtw.' + k, JSON.stringify(v)); return true; } catch (e) { APP.toast('Storage is full'); return false; } },
    del: function (k) { try { localStorage.removeItem('rwtw.' + k); } catch (e) {} },
    all: function () { var o = {}; for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k.indexOf('rwtw.') === 0) o[k.slice(5)] = localStorage.getItem(k); } return o; }
  };
  var S = APP.store;

  /* ---------- settings ---------- */
  var defaults = { lang: 'en', theme: 'auto', fs: 1, epiphanySunday: false, ascensionSunday: false, corpusSunday: false, indianSaints: true, feedUrl: '', weeklyGoal: 5, streaksOn: true, weekStart: 0 };
  APP.settings = Object.assign({}, defaults, S.get('settings', {}));
  APP.saveSettings = function () { S.set('settings', APP.settings); APP.applySettings(); };
  APP.applySettings = function () {
    var st = APP.settings, th = st.theme;
    if (th === 'auto') th = (W.matchMedia && W.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', th);
    document.documentElement.style.setProperty('--fs', st.fs);
    document.documentElement.lang = st.lang;
    W.Liturgy.options.epiphanySunday = !!st.epiphanySunday; W.Liturgy.options.ascensionSunday = !!st.ascensionSunday; W.Liturgy.options.corpusSunday = !!st.corpusSunday;
  };

  /* ---------- translations ---------- */
  var EN = {
    home: 'Home', bible: 'Bible', pray: 'Pray', discover: 'Discover', me: 'Me', today: 'Today', gospel: "Today's Gospel", saint: 'Saint of the Day', calendar: 'Liturgical Calendar', stories: 'Bible Stories',
    rosary: 'Holy Rosary', mercy: 'Divine Mercy Chaplet', prayers: 'Prayers', litanies: 'Litanies', novenas: 'Novenas', stations: 'Stations of the Cross', routines: 'Daily Routines', timer: 'Prayer Timer',
    journal: 'Prayer Journal', intentions: 'Prayer Intentions', settings: 'Settings', search: 'Search', save: 'Save', saved: 'Saved', share: 'Share', back: 'Back', next: 'Next', prev: 'Previous',
    language: 'Language', theme: 'Theme', textsize: 'Text size', reminders: 'Reminders', backup: 'Backup & Restore', sync: 'Content Sync', quiz: 'Scripture Quiz', trivia: 'Catholic Trivia', kids: 'Kids & Family',
    plans: 'Reading Plans', challenges: 'Seasonal Challenges', bookmarks: 'Bookmarks', notes: 'Notes', highlights: 'Highlights', streak: 'Prayer Streak', library: 'Devotional Library', parish: 'My Parish', groups: 'Prayer Groups',
    cards: 'Scripture Cards', recent: 'Recently Read', favorites: 'Favorites', continue: 'Continue reading', verse: 'Verse of the Day', offline: 'Works offline', morning: 'Morning', evening: 'Evening', sleep: 'Sleep',
    privacy: 'Privacy', about: 'About'
  };
  var ML = {
    home: 'ഹോം', bible: 'ബൈബിൾ', pray: 'പ്രാർത്ഥന', discover: 'കണ്ടെത്തുക', me: 'ഞാൻ', today: 'ഇന്ന്', gospel: 'ഇന്നത്തെ സുവിശേഷം', saint: 'ഇന്നത്തെ വിശുദ്ധർ', calendar: 'ആരാധനക്രമ കലണ്ടർ', stories: 'ബൈബിൾ കഥകൾ',
    rosary: 'ജപമാല', mercy: 'ദൈവകരുണയുടെ ജപമാല', prayers: 'പ്രാർത്ഥനകൾ', litanies: 'ലുത്തിനിയകൾ', novenas: 'നൊവേനകൾ', stations: 'കുരിശിന്റെ വഴി', routines: 'ദിനചര്യാ പ്രാർത്ഥനകൾ', timer: 'പ്രാർത്ഥനാ ടൈമർ',
    journal: 'പ്രാർത്ഥനാ ഡയറി', intentions: 'പ്രാർത്ഥനാ നിയോഗങ്ങൾ', settings: 'ക്രമീകരണങ്ങൾ', search: 'തിരയുക', save: 'സൂക്ഷിക്കുക', saved: 'സൂക്ഷിച്ചു', share: 'പങ്കിടുക', back: 'തിരികെ', next: 'അടുത്തത്', prev: 'മുമ്പത്തേത്',
    language: 'ഭാഷ', theme: 'തീം', textsize: 'അക്ഷര വലുപ്പം', reminders: 'ഓർമ്മപ്പെടുത്തലുകൾ', backup: 'ബാക്കപ്പ്', sync: 'ഉള്ളടക്ക സമന്വയം', quiz: 'ബൈബിൾ ക്വിസ്', trivia: 'കത്തോലിക്കാ വിശേഷങ്ങൾ', kids: 'കുട്ടികളും കുടുംബവും',
    plans: 'വായനാ പദ്ധതികൾ', challenges: 'കാലികമായ വെല്ലുവിളികൾ', bookmarks: 'ബുക്ക്മാർക്കുകൾ', notes: 'കുറിപ്പുകൾ', highlights: 'ഹൈലൈറ്റുകൾ', streak: 'പ്രാർത്ഥനാ തുടർച്ച', library: 'ഭക്തി ഗ്രന്ഥാലയം', parish: 'എന്റെ ഇടവക', groups: 'പ്രാർത്ഥനാ ഗ്രൂപ്പുകൾ',
    cards: 'വചന കാർഡുകൾ', recent: 'അടുത്തിടെ വായിച്ചത്', favorites: 'ഇഷ്ടങ്ങൾ', continue: 'വായന തുടരുക', verse: 'ഇന്നത്തെ വചനം', offline: 'ഓഫ്‌ലൈനിൽ പ്രവർത്തിക്കും', morning: 'പ്രഭാതം', evening: 'സായാഹ്നം', sleep: 'ഉറക്കം',
    privacy: 'സ്വകാര്യത', about: 'വിവരം'
  };
  APP.t = function (k) { var d = APP.settings.lang === 'ml' ? ML : EN; return d[k] || EN[k] || k; };
  APP.L = function (o, f) { if (!o) return ''; return (APP.settings.lang === 'ml' && o[f + '_ml']) ? o[f + '_ml'] : o[f]; };

  /* ---------- native bridge (safe in a normal browser) ---------- */
  var AB = W.AndroidBridge || null;
  APP.native = !!AB;
  APP.bridge = {
    share: function (text) { if (AB && AB.shareText) AB.shareText(text); else if (navigator.share) navigator.share({ text: text }).catch(function () {}); else APP.copy(text); },
    shareImage: function (b64, name) { if (AB && AB.shareImage) AB.shareImage(b64, name); else APP.toast('Sharing images works in the installed app'); },
    saveImage: function (b64, name) { if (AB && AB.saveImage) AB.saveImage(b64, name); else APP.toast('Saving images works in the installed app'); },
    saveText: function (name, text) { if (AB && AB.saveTextFile) AB.saveTextFile(name, text); else { APP.copy(text); } },
    pickBackup: function () { if (AB && AB.pickBackup) AB.pickBackup(); else APP.toast('Restore works in the installed app'); },
    setReminder: function (id, h, m, on, title, text) { if (AB && AB.setReminder) AB.setReminder(id, h, m, on, title, text); },
    notifyPermission: function () { if (AB && AB.requestNotificationPermission) AB.requestNotificationPermission(); },
    readPack: function (n) { try { return AB && AB.readPack ? AB.readPack(n) : ''; } catch (e) { return ''; } },
    syncNow: function (url, silent) { if (AB && AB.syncContent) { AB.syncContent(url, !!silent); return true; } return false; },
    setFeedUrl: function (u) { if (AB && AB.setFeedUrl) AB.setFeedUrl(u || ''); },
    dbInfo: function () { try { return AB && AB.dbInfo ? JSON.parse(AB.dbInfo()) : null; } catch (e) { return null; } },
    vibrate: function () { if (AB && AB.vibrate) AB.vibrate(); else if (navigator.vibrate) navigator.vibrate(20); }
  };
  APP.copy = function (text) {
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text); APP.toast('Copied'); return; } } catch (e) {}
    var ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); APP.toast('Copied'); } catch (e) {} ta.remove();
  };
  var toastT;
  APP.toast = function (msg) { var el = document.getElementById('toast'); if (!el) return; el.textContent = msg; el.style.display = 'block'; clearTimeout(toastT); toastT = setTimeout(function () { el.style.display = 'none'; }, 2200); };

  /* ---------- AI results store: built-in database on the phone (falls back to localStorage in a browser) ---------- */
  APP.aiStore = {
    all: function () { if (AB && AB.dbAiAll) { try { return JSON.parse(AB.dbAiAll()); } catch (e) { return {}; } } return S.get('ai', {}); },
    put: function (k, v) { if (AB && AB.dbAiPut) AB.dbAiPut(k, JSON.stringify(v)); else { var a = S.get('ai', {}); a[k] = v; S.set('ai', a); } },
    del: function (k) { if (AB && AB.dbAiDelete) AB.dbAiDelete(k); else { var a = S.get('ai', {}); delete a[k]; S.set('ai', a); } },
    migrate: function () { if (AB && AB.dbAiPut) { var old = S.get('ai', null); if (old) { Object.keys(old).forEach(function (k) { AB.dbAiPut(k, JSON.stringify(old[k])); }); S.del('ai'); } } }
  };

  /* ---------- content packs (from Content Sync) ---------- */
  APP.packs = W.RWTW_PACKS = { readings: {}, calendar: {}, meta: {} };
  APP.loadPacks = function () {
    ['stories', 'saints', 'readings', 'calendar', 'quiz', 'trivia', 'videos', 'social'].forEach(function (name) {
      var txt = APP.bridge.readPack(name); if (!txt) return;
      try {
        var data = JSON.parse(txt);
        if (name === 'readings' || name === 'calendar') APP.packs[name] = data.items || data;
        else APP.packs[name] = data.items || data;
      } catch (e) { /* ignore damaged pack */ }
    });
    var P = APP.packs;
    if (Array.isArray(P.saints)) { W.RWTW_SAINTS_EXTRA = P.saints; W.Liturgy.resetSaints(); }
    APP.packs.meta = S.get('syncMeta', {});
  };

  /* ---------- router ---------- */
  var TABS = ['home', 'bible', 'pray', 'discover', 'me'];
  var TABICON = { home: '\u2302', bible: '\uD83D\uDCD6', pray: '\uD83D\uDE4F', discover: '\u2728', me: '\u263A' };
  function renderTabs(active) {
    var el = document.getElementById('tabs'); if (!el) return;
    el.innerHTML = '<div>' + TABS.map(function (k) { return '<button data-act="tab" data-arg="' + k + '" class="' + (k === active ? 'on' : '') + '" aria-label="' + APP.esc(APP.t(k)) + '"><b>' + TABICON[k] + '</b>' + APP.esc(APP.t(k)) + '</button>'; }).join('') + '</div>';
  }
  APP.tabOf = function (name) { var m = { home: 'home', today: 'home', bible: 'bible', chapter: 'bible', plans: 'bible', pray: 'pray', discover: 'discover', me: 'me' }; return m[name] || (APP.cur && APP.cur.tab) || 'home'; };
  APP.go = function (name, arg, opts) {
    opts = opts || {};
    if (APP.cur && !opts.replace) { APP.cur.scroll = W.scrollY; APP.stack.push(APP.cur); if (APP.stack.length > 60) APP.stack.shift(); }
    APP.cur = { name: name, arg: arg, tab: opts.tab || (TABS.indexOf(name) >= 0 ? name : (APP.cur && APP.cur.tab) || 'home') };
    APP.render(); W.scrollTo(0, 0);
  };
  APP.root = function (tab) { APP.stack = []; APP.cur = null; APP.go(tab, null, { tab: tab }); };
  APP.back = function () {
    if (APP.closeSheet && APP.closeSheet()) return true;
    if (APP.onBackHook && APP.onBackHook()) return true;
    if (APP.stack.length) { APP.cur = APP.stack.pop(); APP.render(); W.scrollTo(0, APP.cur.scroll || 0); return true; }
    if (APP.cur && APP.cur.name !== 'home') { APP.root('home'); return true; }
    return false;
  };
  APP.render = function () {
    APP.onBackHook = null; if (APP.stopTimers) APP.stopTimers();
    var c = APP.cur, fn = APP.screens[c.name]; if (!fn) fn = APP.screens.home;
    var out = fn(c.arg) || {};
    var canBack = APP.stack.length > 0;
    var isTab = TABS.indexOf(c.name) >= 0;
    var head = '<header class="bar">' + (canBack && !isTab ? '<button class="ib" data-act="back" aria-label="' + APP.esc(APP.t('back')) + '">\u2190</button>' : '') + '<h1>' + APP.esc(out.title || APP.t(c.name)) + '</h1>' + (out.actions || '') + '</header>';
    document.getElementById('app').innerHTML = head + '<main>' + (out.html || '') + '</main>';
    renderTabs(c.tab);
    if (out.after) out.after();
  };
  APP.refresh = function () { var y = W.scrollY; APP.render(); W.scrollTo(0, y); };

  /* ---------- event delegation ---------- */
  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null; if (!el) return;
    var act = el.getAttribute('data-act'), a = APP.actions[act];
    if (act === 'back') { APP.back(); return; }
    if (act === 'tab') { APP.root(el.getAttribute('data-arg')); return; }
    if (act === 'go') { APP.go(el.getAttribute('data-arg'), el.getAttribute('data-arg2') || null); return; }
    if (a) a(el, e);
  });

  /* ---------- sheet ---------- */
  APP.openSheet = function (html) { APP.closeSheet(); var d = document.createElement('div'); d.className = 'sheet'; d.id = 'sheet'; d.innerHTML = html; document.body.appendChild(d); };
  APP.closeSheet = function () { var s = document.getElementById('sheet'); if (s) { s.remove(); return true; } return false; };

  /* ---------- progress/streak ---------- */
  APP.mark = function (kind) { // 'prayer' | 'read'
    var days = S.get('days', {}), k = APP.todayKey(); days[k] = days[k] || {}; days[k][kind] = (days[k][kind] || 0) + 1; S.set('days', days);
  };
  APP.streak = function () {
    var days = S.get('days', {}), n = 0, d = new Date(); d.setHours(12);
    if (!days[W.Liturgy.key(d)]) d.setDate(d.getDate() - 1);
    while (days[W.Liturgy.key(d)]) { n++; d.setDate(d.getDate() - 1); }
    return n;
  };
  APP.weekCount = function () { var days = S.get('days', {}), d = new Date(), n = 0; d.setHours(12); d.setDate(d.getDate() - ((d.getDay() - (APP.settings.weekStart || 0) + 7) % 7)); for (var i = 0; i < 7; i++) { if (days[W.Liturgy.key(d)]) n++; d.setDate(d.getDate() + 1); } return n; };
  APP.recent = function (type, id, title) {
    var r = S.get('recent', []).filter(function (x) { return !(x.type === type && x.id === id); });
    r.unshift({ type: type, id: id, title: title, ts: Date.now() }); S.set('recent', r.slice(0, 25));
  };

  /* ---------- sync callbacks from Android ---------- */
  W.onSyncResult = function (json) {
    try {
      var r = typeof json === 'string' ? JSON.parse(json) : json;
      var meta = S.get('syncMeta', {}); meta.last = Date.now(); meta.status = r.status; meta.message = r.message || ''; meta.packs = Object.assign(meta.packs || {}, r.packs || {}); meta.checked = Date.now(); S.set('syncMeta', meta);
      if (r.status === 'updated') { APP.loadPacks(); if (W.RWTW_APPLY_PACKS) W.RWTW_APPLY_PACKS(); }
      if (!r.silent) APP.toast(r.status === 'updated' ? 'Content updated' : (r.status === 'current' ? 'Everything is up to date' : (r.message || 'Sync problem')));
      if (APP.cur && APP.cur.name === 'sync') APP.refresh();
    } catch (e) { APP.toast('Sync result could not be read'); }
  };
  W.onBackupPicked = function (text) { if (APP.actions._restore) APP.actions._restore(text); };
  W.onNativeBack = function () { return APP.back(); };
  W.RWTW_BACK = function () { return APP.back(); };
})();
