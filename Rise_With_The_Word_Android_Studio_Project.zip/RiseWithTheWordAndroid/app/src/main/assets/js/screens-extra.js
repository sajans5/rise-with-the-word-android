(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, t = A.t, F = W.RWTW_FAITH, Lit = W.Liturgy;
  var SC = A.screens, AC = A.actions;

  /* ---------- Learn the Faith ---------- */
  SC.faith = function () {
    var h = '<input type="search" id="fq" placeholder="Search the faith library"><div id="flist" class="list" style="margin-top:8px"></div>';
    return { title: 'Learn the Faith', html: h, after: function () { var draw = function () { var q = A.$('#fq').value.toLowerCase(); A.$('#flist').innerHTML = F.topics.filter(function (x) { return !q || (x[1] + ' ' + x[2] + ' ' + x[3].join(' ')).toLowerCase().indexOf(q) >= 0; }).map(function (x) { return '<button class="item" data-act="go" data-arg="topic" data-arg2="' + x[0] + '"><b>' + esc(x[1]) + '</b><span>' + esc(x[2]) + '</span></button>'; }).join(''); }; A.$('#fq').addEventListener('input', draw); draw(); } };
  };
  SC.topic = function (id) {
    var x = F.topics.filter(function (y) { return y[0] === id; })[0]; if (!x) return { html: '' };
    A.recent('topic', id, x[1]);
    var body = x[4] ? '<ul>' + x[3].map(function (i) { return '<li style="margin:6px 0">' + esc(i) + '</li>'; }).join('') + '</ul>' : x[3].map(function (p) { return '<p>' + esc(p) + '</p>'; }).join('');
    return { title: x[1], html: '<div class="card"><p class="muted">' + esc(x[2]) + '</p>' + body + '<p class="small muted">Source: ' + esc(x[5]) + '</p></div><div class="row"><button class="btn alt" data-act="topicShare" data-id="' + id + '">' + esc(t('share')) + '</button></div>' };
  };
  AC.topicShare = function (el) { var x = F.topics.filter(function (y) { return y[0] === el.getAttribute('data-id'); })[0]; A.bridge.share(x[1] + '\n\n' + x[2] + '\n\n' + x[3].join('\n') + '\n\nRise With The Word'); };

  /* ---------- Glossary ---------- */
  SC.glossary = function () {
    return { title: 'Glossary', html: '<input type="search" id="gq" placeholder="Search terms"><div id="glist" class="list" style="margin-top:8px"></div>', after: function () { var draw = function () { var q = A.$('#gq').value.toLowerCase(); A.$('#glist').innerHTML = F.glossary.filter(function (g) { return !q || (g[0] + ' ' + g[1]).toLowerCase().indexOf(q) >= 0; }).map(function (g) { return '<div class="item"><b>' + esc(g[0]) + '</b><span style="color:var(--text)">' + esc(g[1]) + '</span></div>'; }).join(''); }; A.$('#gq').addEventListener('input', draw); draw(); } };
  };

  /* ---------- Confession guide + examination (nothing stored) ---------- */
  SC.confession = function () {
    var h = '<div class="banner">\uD83D\uDD12 This guide is private and nothing you tick is saved.</div><div class="list"><button class="item" data-act="go" data-arg="topic" data-arg2="confession"><b>How to make a good confession</b><span>Step by step</span></button><button class="item" data-act="go" data-arg="exam"><b>Examination of conscience</b><span>Questions based on the Ten Commandments</span></button><button class="item" data-act="openPrayer" data-id="contrition"><b>Act of Contrition</b><span>Prayer</span></button></div>';
    return { title: 'Confession Guide', html: h };
  };
  SC.exam = function () {
    var h = '<div class="banner">Take a few quiet minutes. Ask the Holy Spirit for light, and answer honestly. God is merciful.</div>';
    h += F.examination.map(function (e) { return '<div class="card"><h3>' + esc(e[0]) + '</h3>' + e[1].map(function (q) { return '<label style="display:block;color:var(--text);margin:6px 0"><input type="checkbox"> ' + esc(q) + '</label>'; }).join('') + '</div>'; }).join('');
    h += '<button class="btn block" data-act="openPrayer" data-id="contrition">Act of Contrition</button>';
    return { title: 'Examination of Conscience', html: h };
  };

  /* ---------- Help in need ---------- */
  SC.needs = function () { return { title: 'Help in Need', html: '<div class="list">' + F.situations.map(function (s, i) { return '<button class="item" data-act="go" data-arg="need" data-arg2="' + i + '"><b>' + esc(s[0]) + '</b><span>Scripture and a short prayer</span></button>'; }).join('') + '</div>' }; };
  SC.need = function (i) {
    var s = F.situations[+i], h = '<div class="card"><h3>Prayer</h3><p class="prayer-text">' + esc(s[2]) + '</p></div>';
    h += s[1].map(function (r) { return A.refBlock('Scripture', r); }).join('');
    h += '<div class="row"><button class="btn" data-act="prayerDone">\u2713 I prayed this</button><button class="btn alt" data-act="needShare" data-i="' + i + '">' + esc(t('share')) + '</button></div>';
    return { title: s[0], html: h };
  };
  AC.needShare = function (el) { var s = F.situations[+el.getAttribute('data-i')]; A.bridge.share(s[0] + '\n\n' + s[2] + '\n\nScripture: ' + s[1].join('; ') + '\n\nRise With The Word'); };

  /* ---------- Verses by topic ---------- */
  SC.topics = function () { return { title: 'Scripture by Topic', html: '<div class="grid">' + F.verseTopics.map(function (v, i) { return '<button class="tile" style="min-height:70px" data-act="go" data-arg="vtopic" data-arg2="' + i + '"><b>' + esc(v[0]) + '</b><span>' + v[1].length + ' passages</span></button>'; }).join('') + '</div>' }; };
  SC.vtopic = function (i) { var v = F.verseTopics[+i]; return { title: v[0], html: (W.Bible.ready ? '' : A.bibleMissing()) + v[1].map(function (r) { return A.refBlock(r, r); }).join('') }; };

  /* ---------- Timeline ---------- */
  SC.timeline = function () {
    return { title: 'Biblical & Church Timeline', html: '<div class="banner">Dates before AD 100 are approximate or traditional and are debated by scholars.</div><div class="list">' + F.timeline.map(function (x) { return '<div class="item"><b>' + esc(x[0]) + '</b><span style="color:var(--text)">' + esc(x[1]) + '</span>' + (x[2] ? '<span>' + esc(x[2]) + '</span>' : '') + '</div>'; }).join('') + '</div>' };
  };

  /* ---------- Coming up (computed, so accurate) ---------- */
  A.comingUp = function () {
    var out = [], d0 = new Date(); d0.setHours(12);
    for (var i = 1; i <= 75 && out.length < 4; i++) {
      var d = A.dayInfo(Lit.add(d0, i)), t0 = d.title;
      if (d.rank === 'S' || d.rank === 'D' || (d.rank === 'F' && d.dow !== 0) || /^(Ash Wednesday|Palm Sunday|First Sunday of Advent|First Sunday of Lent)/.test(t0.replace('1st','First'))) out.push({ d: d, n: i });
    }
    return out;
  };
  A.fastNote = function (d) {
    if (/^Ash Wednesday|^Good Friday/.test(d.title)) return 'Day of fasting and abstinence from meat (general law of the Latin Church).';
    if (d.season === 'lent' && d.dow === 5) return 'Friday of Lent: abstinence from meat (general law; check your country).';
    return '';
  };
})();
