/* AI Story Studio: uses a separately hosted HTTPS backend; no API key in the app. */
(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, SC = A.screens, AC = A.actions;
  function paragraphs(text) {
    return String(text || '').split(/\n\s*\n/).map(function (p) {
      return p.trim() ? '<p>' + esc(p).replace(/\n/g, '<br>') + '</p>' : '';
    }).join('');
  }
  SC.aiStory = function () {
    var saved = S.get('aiStories', []);
    var h = '<div class="hero"><div class="eyebrow">RESEARCH · SCRIPTURE · STORYTELLING</div><h2>Bring a Bible story to life.</h2><p>Generate a detailed, readable story using web research and Scripture references.</p></div>';
    h += '<div class="card"><label for="aiTopic">Bible story or person</label><input id="aiTopic" maxlength="180" placeholder="e.g. Joseph forgives his brothers"><label for="aiLang">Language</label><select id="aiLang"><option>English</option><option>Malayalam</option></select><label for="aiLength">Length</label><select id="aiLength"><option value="1200">Short chapter · about 1,200 words</option><option value="2200">Extended chapter · about 2,200 words</option><option value="3500" selected>Full chapter · about 3,500 words</option></select><button class="btn block" style="margin-top:12px" data-act="generateAiStory">✨ Research and write story</button><p class="small muted">Requires internet and a configured AI service. Usage may incur charges. This generates an original retelling, not verbatim Scripture.</p></div>';
    if (!A.settings.aiEndpoint) h += '<div class="banner">Setup required: Me → Settings → AI Story Studio. Add the HTTPS service URL. Never enter an API key here.</div>';
    h += '<div id="aiResult"></div>';
    if (saved.length) h += '<h3>Saved AI stories</h3><div class="list">' + saved.slice().reverse().map(function (x) {
      return '<button class="item" data-act="openSavedAiStory" data-id="' + esc(x.id) + '"><b>' + esc(x.topic) + '</b><span>' + esc(x.date || '') + ' · ' + (x.words || 0) + ' words</span></button>';
    }).join('') + '</div>';
    return { title: 'AI Story Studio', html: h };
  };
  AC.generateAiStory = function () {
    var endpoint = String(A.settings.aiEndpoint || '').trim();
    var topic = (A.$('#aiTopic') && A.$('#aiTopic').value || '').trim();
    var language = A.$('#aiLang') ? A.$('#aiLang').value : 'English';
    var wordCount = A.$('#aiLength') ? parseInt(A.$('#aiLength').value, 10) : 3500;
    var result = A.$('#aiResult');
    if (!endpoint) { A.toast('Set the AI endpoint in Me → Settings'); return; }
    if (!/^https:\/\//i.test(endpoint)) { A.toast('The AI endpoint must use HTTPS'); return; }
    if (!topic) { A.toast('Enter a Bible story or person'); return; }
    if (result) result.innerHTML = '<div class="card"><p>Researching sources and writing your story…</p><p class="small muted">A long chapter can take a little while.</p></div>';
    fetch(endpoint.replace(/\/+$/, '') + '/story', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic: topic, language: language, wordCount: wordCount })
    }).then(function (r) {
      return r.text().then(function (txt) {
        var data; try { data = JSON.parse(txt); } catch (e) { throw new Error('AI service returned an unreadable response. Check deployment.'); }
        if (!r.ok) throw new Error(data.error || ('Request failed (' + r.status + ')'));
        return data;
      });
    }).then(function (data) {
      if (!data.story) throw new Error('No story was returned.');
      var story = { id: A.uid(), topic: topic, language: language, date: new Date().toLocaleDateString(), story: data.story, sources: Array.isArray(data.sources) ? data.sources : [], words: String(data.story).trim().split(/\s+/).length };
      S.set('aiStoryCurrent', story);
      var sources = story.sources.length ? '<h3>Research sources</h3><ul>' + story.sources.map(function (x) {
        return '<li><a href="' + esc(x.url) + '" target="_blank" rel="noopener noreferrer">' + esc(x.title || x.url) + '</a></li>';
      }).join('') + '</ul>' : '<p class="small muted">No source links were returned. Verify historical details with trusted references.</p>';
      if (result) result.innerHTML = '<article class="card story-chapter"><div class="eyebrow">AI-ASSISTED BIBLE STORY</div><h2>' + esc(story.topic) + '</h2><p class="small muted">' + story.words + ' words · ' + esc(story.language) + '</p>' + paragraphs(story.story) + '<button class="btn block" data-act="saveAiStory">☆ Save story</button></article><div class="card">' + sources + '<p class="small muted">Original retelling with research assistance. Check Scripture references before sharing.</p></div>';
    }).catch(function (err) {
      if (result) result.innerHTML = '<div class="card"><h3>Could not generate story</h3><p>' + esc(err.message || 'Connection error') + '</p><p class="small muted">Check the HTTPS service URL and its server-side key.</p></div>';
    });
  };
  function renderExpandedMarkdown(text) {
    return String(text || '').split(/\n\s*\n/).map(function (chunk) {
      var x = esc(chunk.trim());
      if (!x) return '';
      if (/^###?\s/.test(x)) return '<h3>' + x.replace(/^###?\s+/, '') + '</h3>';
      if (/^[-*]\s/m.test(x)) return '<ul>' + x.split('\n').map(function (line) { return line.replace(/^[-*]\s+/, '').trim(); }).filter(Boolean).map(function (line) { return '<li>' + line + '</li>'; }).join('') + '</ul>';
      return '<p>' + x.replace(/\n/g, '<br>') + '</p>';
    }).join('');
  }
  AC.expandContent = function (el) {
    var endpoint = String(A.settings.aiEndpoint || '').trim();
    var type = el.getAttribute('data-type') || 'story';
    var key = el.getAttribute('data-key') || (type + '-' + Date.now());
    var title = el.getAttribute('data-title') || 'Rise With The Word';
    var targetId = 'ai-expand-' + key;
    var target = document.getElementById(targetId);
    if (!endpoint) { A.toast('Set the HTTPS AI service in Me → Settings'); return; }
    if (!/^https:\/\//i.test(endpoint)) { A.toast('The AI endpoint must use HTTPS'); return; }
    var cache = S.get('aiExpandedContent', {});
    if (cache[key] && target) {
      target.innerHTML = '<article class="story-chapter">' + renderExpandedMarkdown(cache[key].content) + sourceHtml(cache[key].sources) + '<p class="small muted">AI-assisted expansion · saved on this device</p></article>';
      el.textContent = '↻ Regenerate expanded content';
      return;
    }
    if (target) target.innerHTML = '<div class="banner">Researching trusted references and expanding this content… Please keep the app open.</div>';
    el.disabled = true; el.textContent = 'Working…';
    var payload = { type: type, title: title, language: A.settings.lang === 'ml' ? 'Malayalam' : 'English', date: el.getAttribute('data-date') || '', reference: el.getAttribute('data-ref') || el.getAttribute('data-reference') || '', summary: el.getAttribute('data-summary') || '', lesson: el.getAttribute('data-lesson') || '', gospel: el.getAttribute('data-gospel') || '', psalm: el.getAttribute('data-psalm') || '', second: el.getAttribute('data-second') || '', context: el.getAttribute('data-context') || '' };
    fetch(endpoint.replace(/\/+$/, '') + '/expand', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      .then(function (r) { return r.text().then(function (txt) { var d; try { d = JSON.parse(txt); } catch (e) { throw new Error('AI service returned an unreadable response.'); } if (!r.ok) throw new Error(d.error || ('Request failed (' + r.status + ')')); return d; }); })
      .then(function (data) {
        if (!data.content) throw new Error('No expanded content was returned.');
        var item = { content: data.content, sources: Array.isArray(data.sources) ? data.sources : [], updated: new Date().toISOString(), title: title, type: type };
        cache[key] = item; S.set('aiExpandedContent', cache);
        if (target) target.innerHTML = '<article class="story-chapter">' + renderExpandedMarkdown(item.content) + sourceHtml(item.sources) + '<p class="small muted">AI-assisted expansion · verify liturgical dates and references with trusted Catholic sources.</p><button class="btn alt block" data-act="saveExpandedContent" data-key="' + esc(key) + '">✓ Saved on this device</button></article>';
        el.textContent = '✓ Expanded';
      }).catch(function (err) {
        if (target) target.innerHTML = '<div class="banner">Could not expand this content: ' + esc(err.message || 'Connection error') + '. Check internet and the AI service setup.</div>';
        el.textContent = 'Try again';
      }).finally(function () { el.disabled = false; });
  };
  function sourceHtml(sources) {
    if (!sources || !sources.length) return '<p class="small muted">No source links were returned. Please verify details independently.</p>';
    return '<h3>Research sources</h3><ul>' + sources.slice(0, 10).map(function (x) { var u = String(x.url || ''); if (!/^https:\/\//i.test(u)) return ''; return '<li><a href="' + esc(u) + '" target="_blank" rel="noopener noreferrer">' + esc(x.title || u) + '</a></li>'; }).join('') + '</ul>';
  }
  AC.saveExpandedContent = function (el) { var key = el.getAttribute('data-key'), cache = S.get('aiExpandedContent', {}); if (cache[key]) { cache[key].pinned = true; S.set('aiExpandedContent', cache); A.toast('Expansion saved on this device'); } };
  AC.saveAiStory = function () {
    var x = S.get('aiStoryCurrent', null); if (!x) { A.toast('Generate a story first'); return; }
    var list = S.get('aiStories', []);
    if (!list.some(function (y) { return y.id === x.id; })) list.push(x);
    S.set('aiStories', list); A.toast('Story saved on this device'); A.refresh();
  };
  AC.openSavedAiStory = function (el) { A.go('savedAiStory', el.getAttribute('data-id')); };
  SC.savedAiStory = function (id) {
    var x = S.get('aiStories', []).filter(function (y) { return y.id === id; })[0];
    if (!x) return { title: 'Saved story', html: '<p>Story not found on this device.</p>' };
    return { title: x.topic, html: '<article class="card story-chapter"><div class="small muted">' + esc(x.date || '') + ' · ' + (x.words || 0) + ' words</div><h2>' + esc(x.topic) + '</h2>' + paragraphs(x.story) + '</article><button class="btn danger block" data-act="deleteAiStory" data-id="' + esc(x.id) + '">Delete saved story</button>' };
  };
  AC.deleteAiStory = function (el) { var id = el.getAttribute('data-id'); S.set('aiStories', S.get('aiStories', []).filter(function (x) { return x.id !== id; })); A.back(); };
})();