/* Learning content: Scripture quiz, Catholic trivia, kids/family resources, seasonal challenges. */
window.RWTW_LEARN = (function () {
  // [question, [options], correctIndex, explanation]
  var quiz = [
    ['Who built the ark?', ['Moses', 'Noah', 'Abraham', 'David'], 1, 'Genesis 6\u20139: Noah built the ark at God\u2019s command.'],
    ['How many commandments did God give Moses on Mount Sinai?', ['Seven', 'Ten', 'Twelve', 'Five'], 1, 'Exodus 20: The Ten Commandments.'],
    ['Who defeated Goliath?', ['Saul', 'Jonathan', 'David', 'Samson'], 2, '1 Samuel 17.'],
    ['In which town was Jesus born?', ['Nazareth', 'Jerusalem', 'Bethlehem', 'Capernaum'], 2, 'Luke 2:4\u20137.'],
    ['Who baptized Jesus?', ['Peter', 'John the Baptist', 'Paul', 'Andrew'], 1, 'Matthew 3:13\u201317.'],
    ['How many apostles did Jesus choose?', ['Seven', 'Ten', 'Twelve', 'Seventy'], 2, 'Luke 6:12\u201316.'],
    ['At which wedding did Jesus turn water into wine?', ['Bethany', 'Cana', 'Jericho', 'Emmaus'], 1, 'John 2:1\u201311.'],
    ['Which disciple walked on water toward Jesus?', ['John', 'Thomas', 'Peter', 'James'], 2, 'Matthew 14:28\u201329.'],
    ['Who was swallowed by a great fish?', ['Jonah', 'Elijah', 'Daniel', 'Job'], 0, 'Jonah 1:17.'],
    ['Which apostle doubted the Resurrection until he saw Jesus\u2019 wounds?', ['Philip', 'Thomas', 'Matthew', 'Bartholomew'], 1, 'John 20:24\u201329.'],
    ['Who was the mother of John the Baptist?', ['Anna', 'Elizabeth', 'Martha', 'Salome'], 1, 'Luke 1:57\u201360.'],
    ['What did the Magi bring to the infant Jesus?', ['Gold, frankincense and myrrh', 'Wheat, wine and oil', 'Bread and fish', 'Silver and spices'], 0, 'Matthew 2:11.'],
    ['In the parable, who helped the wounded man on the road?', ['The priest', 'The Levite', 'The Samaritan', 'The Pharisee'], 2, 'Luke 10:33\u201334.'],
    ['Who was the first martyr of the Church?', ['James', 'Stephen', 'Paul', 'Barnabas'], 1, 'Acts 7:54\u201360.'],
    ['On the road to Damascus, who was struck blind?', ['Peter', 'Saul', 'Cornelius', 'Silas'], 1, 'Acts 9:1\u20139.'],
    ['Who was thrown into the lions\u2019 den?', ['Daniel', 'Joseph', 'Elijah', 'Isaiah'], 0, 'Daniel 6.'],
    ['What is the last book of the Bible?', ['Acts', 'Revelation (Apocalypse)', 'Jude', 'Hebrews'], 1, 'The Book of Revelation, or Apocalypse in the Douay\u2013Rheims.'],
    ['Which Gospel is written by a physician and companion of Paul?', ['Matthew', 'Mark', 'Luke', 'John'], 2, 'Luke is traditionally the physician (Colossians 4:14).'],
    ['Who told Mary she would be the mother of Jesus?', ['Michael', 'Gabriel', 'Raphael', 'Uriel'], 1, 'Luke 1:26\u201331.'],
    ['What did Jesus say on the cross: \u201CFather, ____ them\u201D?', ['bless', 'forgive', 'save', 'protect'], 1, 'Luke 23:34.'],
    ['How many days did Jesus fast in the desert?', ['Seven', 'Twenty', 'Forty', 'Fifty'], 2, 'Matthew 4:2.'],
    ['Which prophet was taken up in a fiery chariot?', ['Elisha', 'Elijah', 'Isaiah', 'Jeremiah'], 1, '2 Kings 2:11.'],
    ['Who was sold into slavery by his brothers?', ['Benjamin', 'Joseph', 'Judah', 'Reuben'], 1, 'Genesis 37.'],
    ['What is the shortest verse in many English Bibles?', ['Jesus wept.', 'God is love.', 'Pray always.', 'Rejoice.'], 0, 'John 11:35.'],
    ['Which of these books is deuterocanonical (not found in most Protestant Bibles)?', ['Proverbs', 'Wisdom', 'Psalms', 'Ecclesiastes'], 1, 'Wisdom is one of the deuterocanonical books.'],
    ['How many books are in the Catholic Bible?', ['66', '72', '73', '80'], 2, '46 Old Testament + 27 New Testament.'],
    ['Which sacrament forgives sins after Baptism?', ['Confirmation', 'Reconciliation (Confession)', 'Anointing of the Sick', 'Matrimony'], 1, 'John 20:22\u201323; CCC 1440.'],
    ['How many mysteries are in the traditional Rosary set for one day?', ['Three', 'Five', 'Seven', 'Ten'], 1, 'Each set has five mysteries.'],
    ['Which season of the Church year comes before Christmas?', ['Lent', 'Advent', 'Easter', 'Epiphany'], 1, 'Advent prepares for Christmas.'],
    ['What colour is worn in Advent and Lent?', ['Green', 'Violet', 'Red', 'Gold'], 1, 'Violet signifies penance and preparation.'],
    ['By tradition, which apostle first brought Christianity to Kerala?', ['St Peter', 'St Thomas the Apostle', 'St Paul', 'St Francis Xavier'], 1, 'Tradition says St Thomas arrived in Kerala in AD 52.'],
    ['Which saint founded the Franciscans?', ['Dominic', 'Francis of Assisi', 'Ignatius', 'Benedict'], 1, 'St Francis (1181\u20131226).'],
    ['Who is known as the Apostle to the Gentiles?', ['Peter', 'Paul', 'Barnabas', 'Philip'], 1, 'Galatians 2:8.'],
    ['What do we celebrate at Pentecost?', ['The Resurrection', 'The coming of the Holy Spirit', 'The Ascension', 'The Nativity'], 1, 'Acts 2.'],
    ['Who is the first woman of Indian origin to be canonized?', ['St Alphonsa', 'St Teresa of Calcutta', 'St Euphrasia', 'St Mariam Thresia'], 0, 'St Alphonsa was canonized in 2008.'],
    ['Which book contains the Magnificat?', ['Matthew', 'Luke', 'Mark', 'John'], 1, 'Luke 1:46\u201355.'],
    ['Which Mass response means \u201CSo be it\u201D?', ['Alleluia', 'Amen', 'Hosanna', 'Kyrie'], 1, 'Amen is Hebrew for \u201Cso be it.\u201D'],
    ['Who anointed David as king?', ['Eli', 'Samuel', 'Nathan', 'Elijah'], 1, '1 Samuel 16:13.'],
    ['Who wrote most of the New Testament letters?', ['Peter', 'John', 'Paul', 'James'], 2, 'Thirteen letters are attributed to Paul.'],
    ['Which feast celebrates the visit of Mary to Elizabeth?', ['Annunciation', 'Visitation', 'Presentation', 'Assumption'], 1, 'Celebrated on 31 May.'],
    ['What is the name of the prayer beginning \u201CHail Mary, full of grace\u201D?', ['Ave Maria', 'Gloria', 'Credo', 'Kyrie'], 0, 'Ave Maria in Latin.'],
    ['Which apostle was a tax collector?', ['Matthew', 'Andrew', 'Philip', 'Jude'], 0, 'Matthew 9:9.'],
    ['Which mountain did Moses climb to receive the Law?', ['Sinai', 'Carmel', 'Tabor', 'Zion'], 0, 'Exodus 19\u201320.'],
    ['How many days of the Easter Triduum are celebrated?', ['Two', 'Three', 'Four', 'Forty'], 1, 'Holy Thursday evening to Easter Sunday evening.'],
    ['What does \u201CEmmanuel\u201D mean?', ['God with us', 'Prince of Peace', 'Holy One', 'King of Kings'], 0, 'Matthew 1:23.']
  ];

  var trivia = [
    'The word \u201CCatholic\u201D comes from the Greek katholikos, meaning \u201Cuniversal.\u201D',
    'The Catholic Bible has 73 books: 46 in the Old Testament and 27 in the New Testament.',
    'The Rosary has been prayed for centuries and combines vocal prayer with meditation on the life of Christ.',
    'Divine Mercy Sunday is celebrated on the Second Sunday of Easter and was established by St John Paul II in 2000.',
    'Lent lasts forty days (not counting Sundays) in memory of the forty days Jesus fasted in the desert.',
    'The colour rose is worn only twice a year: on Gaudete Sunday in Advent and Laetare Sunday in Lent.',
    'The Vatican City is the smallest independent state in the world.',
    'The Psalms are the prayer book of the Bible; 150 psalms (with different numbering in the Vulgate/Douay).',
    'Saint Thomas the Apostle is traditionally believed to have brought Christianity to Kerala in AD 52.',
    'The word \u201CAmen\u201D comes from Hebrew and means \u201Ctruly\u201D or \u201Cso be it.\u201D',
    'The Latin Vulgate Bible was translated mostly by St Jerome in the late fourth century.',
    'The Douay\u2013Rheims Bible was translated from the Latin Vulgate, the New Testament published in 1582 and the Old Testament in 1609\u20131610.',
    'There are seven sacraments: Baptism, Confirmation, Eucharist, Reconciliation, Anointing of the Sick, Holy Orders and Matrimony.',
    'The Holy Year (Jubilee) is traditionally celebrated every 25 years.',
    'Advent has four Sundays and begins the new liturgical year.',
    'The Angelus is traditionally prayed at 6 a.m., noon and 6 p.m.',
    'Mary has more than 50 titles in the Litany of Loreto.',
    'The first Christians were called Christians at Antioch (Acts 11:26).',
    'St Francis Xavier is buried in Goa, India, at the Basilica of Bom Jesus.',
    'Mother Teresa was canonized by Pope Francis on 4 September 2016.',
    'The Sunday readings follow a three-year cycle: Year A (Matthew), Year B (Mark), Year C (Luke), with John read throughout.',
    'The Church has named more than 35 Doctors of the Church, including four women: Teresa of Avila, Catherine of Siena, Thérèse of Lisieux and Hildegard of Bingen.',
    'Pentecost is celebrated fifty days after Easter; its name comes from the Greek word for \u201Cfiftieth.\u201D',
    'The Stations of the Cross originated in the Christian custom of walking the Via Dolorosa in Jerusalem.',
    'Matthew, Mark and Luke are called the Synoptic Gospels because they share a similar view.',
    'The Chaplet of Divine Mercy is prayed on rosary beads and takes about seven to ten minutes.',
    'The Church honours Mary on Saturdays and in October (month of the Rosary) and May.',
    'Malankara and Malabar Catholics in Kerala belong to the Eastern Catholic Churches, which have their own liturgical traditions.',
    'The complete Bible has been translated into hundreds of languages, and parts of it into thousands more.',
    'The Christmas season lasts from Christmas Day until the Baptism of the Lord.',
    'All Souls\u2019 Day (2 November) is a day to pray for the faithful departed.'
  ];

  var kids = {
    prayers: [
      ['Morning prayer', 'Dear God, thank you for this new day. Be with me at school, at play and at home. Help me to be kind. Amen.'],
      ['Grace before meals', 'Bless us, O Lord, and these thy gifts, which we are about to receive from thy bounty. Amen.'],
      ['Night prayer', 'Thank you, God, for today. Please forgive me when I was unkind. Keep my family safe tonight. Amen.'],
      ['Guardian angel', 'Angel of God, my guardian dear, to whom God\u2019s love commits me here, ever this day be at my side, to light and guard, to rule and guide. Amen.']
    ],
    ideas: [
      'Choose one Bible story each week and act it out as a family.',
      'Pray a decade of the Rosary together before dinner.',
      'Make a family prayer jar: each person writes a prayer intention and you pull one out each night.',
      'Draw a picture of your favourite parable and explain it to a family member.',
      'Do one secret act of kindness each day this week.',
      'Light a candle during family prayer time on Sundays.',
      'Learn one Bible verse a week and say it together at bedtime.'
    ],
    tags: 'k'
  };

  var challenges = [
    { id: 'advent', title: 'Advent Journey', subtitle: '24 days of preparation for Christmas', days: 24, items: [
      'Pray the Our Father slowly, thinking about \u201Cthy kingdom come.\u201D', 'Read Isaiah 9:1-6 and reflect on light in darkness.', 'Call or message someone you have not spoken to in a while.', 'Light a candle and pray for peace.',
      'Read Luke 1:26-38 (Annunciation) and say a Hail Mary.', 'Do something kind for a neighbour.', 'Pray for someone who is lonely this season.', 'Read Isaiah 11:1-9 and ask for God\u2019s peace.',
      'Pray the Memorare today.', 'Give to someone in need.', 'Read Luke 1:39-56 (Visitation).', 'Forgive someone in your heart.',
      'Go to Mass or pray for 10 minutes in silence.', 'Read Micah 5:1-4 (Bethlehem).', 'Write a thank-you note to someone.', 'Pray the Litany of Loreto.',
      'Read Luke 1:57-80 and pray the Benedictus words in your own way.', 'Offer a small sacrifice for someone you love.', 'Read Matthew 1:18-25 (Joseph).', 'Pray an evening examen.',
      'Visit or call an elderly person.', 'Read Luke 2:1-7 and imagine the stable.', 'Make peace where you can.', 'Read Luke 2:8-20 on Christmas Eve. Come, Lord Jesus!'
    ] },
  { id: 'lent', title: 'Lenten Journey', subtitle: '40 days of prayer, fasting and almsgiving', days: 40, items: [
      'Ash Wednesday: begin with a simple fast and prayer.', 'Read Psalm 50 (Miserere) slowly.', 'Give up something small for the day.', 'Pray for someone you find difficult.', 'Read Matthew 4:1-11 (the temptations).', 'Do one hidden act of kindness.', 'Go to Confession this week.',
      'Read Luke 15:11-32 (the Prodigal Son).', 'Fast from complaining today.', 'Pray the Stations of the Cross.', 'Give to the poor.', 'Read Matthew 6:1-6.', 'Spend 10 minutes in silent prayer.', 'Forgive someone.',
      'Read John 4:1-42.', 'Pray for the sick.', 'Fast from social media for the day.', 'Visit someone alone.', 'Read Psalm 22 (23).', 'Pray the Rosary.', 'Examine your conscience tonight.',
      'Read John 9:1-41.', 'Pray for peace in the world.', 'Offer an act of service to your family.', 'Skip a treat and give the money to charity.', 'Read Luke 18:9-14.', 'Thank God for three blessings.', 'Pray with your family.',
      'Read John 11:1-45.', 'Fast from criticism.', 'Pray the Divine Mercy Chaplet.', 'Do a good deed in secret.', 'Read Isaiah 53.', 'Pray for those who suffer.', 'Prepare your heart for Holy Week.',
      'Palm Sunday: read Matthew 21:1-11.', 'Holy Monday: read John 12:1-11.', 'Holy Tuesday: read John 13:21-33.', 'Holy Wednesday: read Matthew 26:14-25.'
    ] },
  { id: 'easter', title: 'Easter Joy', subtitle: '7 weeks of Easter, one small joy each day', days: 49, items: [], weekly: [
      ['Resurrection', 'Read John 20:1-18.'], ['Mercy', 'Do one merciful act today.'], ['Emmaus', 'Read Luke 24:13-35.'], ['The Good Shepherd', 'Pray for your pastor and parish.'], ['The True Vine', 'Read John 15:1-8.'], ['Love', 'Tell someone you love them.'], ['The Spirit', 'Pray Come, Holy Spirit.']
    ] },
  { id: 'marian', title: 'Month with Mary', subtitle: '31 days with Our Lady (May or October)', days: 31, items: [
      'Say one Hail Mary slowly.', 'Read Luke 1:26-38.', 'Pray the Angelus.', 'Read Luke 1:39-56.', 'Pray a decade of the Rosary.', 'Read Luke 2:1-7.', 'Pray the Memorare.', 'Read Luke 2:22-35.',
      'Pray the Litany of Loreto.', 'Read Luke 2:41-52.', 'Say a Hail Mary for a friend.', 'Read John 2:1-11.', 'Pray the Salve Regina.', 'Read John 19:25-27.', 'Consecrate your day to Mary.', 'Read Acts 1:12-14.',
      'Pray the Rosary.', 'Read Revelation 12:1-6.', 'Offer a small sacrifice for Mary.', 'Say the Magnificat in your own words.', 'Pray for your mother.', 'Read Luke 11:27-28.', 'Pray for peace.',
      'Pray for the sick.', 'Pray for those in sorrow.', 'Pray for families.', 'Pray for the Church.', 'Pray for children.', 'Pray for priests.', 'Pray for the dying.', 'Entrust your life to Mary.'
    ] }
  ];
  challenges.forEach(function (c) {
    if (c.weekly) { c.items = []; for (var i = 0; i < c.days; i++) { var w = c.weekly[Math.floor(i / 7)]; c.items.push('Week ' + (Math.floor(i / 7) + 1) + ' \u2013 ' + w[0] + ': ' + w[1]); } }
  });

  return { quiz: quiz, trivia: trivia, kids: kids, challenges: challenges };
})();
