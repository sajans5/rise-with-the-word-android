/* Social media integration for Rise With The Word.
   - Your channels open INSIDE the app (a protected viewer that only allows YouTube, Facebook and Instagram).
   - Latest YouTube videos are read from your channel's public feed (no API key) and kept offline in the built-in database.
   - A "social" content pack can change handles/links later without a new APK; a "videos" pack links a video to a story, saint or day.
   - Optional (Settings): open links in the real YouTube/Facebook/Instagram apps instead. */
(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, S = A.store, SC = A.screens, AC = A.actions, AB = W.AndroidBridge || null;

  var DEFAULTS = {
    name: 'Rise With The Word', tagline: 'EVERY DAY WITH GOD\u2019S WORD',
    youtube: { label: 'YouTube', handle: '@risewiththeword', url: 'https://www.youtube.com/@risewiththeword', videos: 'https://www.youtube.com/@risewiththeword/videos' },
    instagram: { label: 'Instagram', handle: '@rise.withtheword', url: 'https://www.instagram.com/rise.withtheword/' },
    facebook: { label: 'Facebook', handle: 'risewiththeword1', url: 'https://www.facebook.com/risewiththeword1' },
    about: 'Faith, inspiration and daily hope. Join our community for Scripture, prayer and reflections.'
  };
  var ICON = { youtube: '\u25B6\uFE0F', instagram: '\uD83D\uDCF7', facebook: '\uD83D\uDC4D' };

  A.social = function () {
    var o = JSON.parse(JSON.stringify(DEFAULTS)), p = A.packs.social;
    if (p && typeof p === 'object') {
      var src = p.items && !Array.isArray(p.items) ? p.items : p;
      ['youtube', 'instagram', 'facebook'].forEach(function (k) { if (src[k] && typeof src[k] === 'object') Object.keys(src[k]).forEach(function (f) { if (/^https:\/\//.test(String(src[k].url || 'https://')) ) o[k][f] = src[k][f]; }); });
      if (src.about) o.about = String(src.about); if (src.tagline) o.tagline = String(src.tagline); if (src.channelId) o.channelId = String(src.channelId);
    }
    if (A.settings.channelId) o.channelId = A.settings.channelId;
    return o;
  };

  A.openSocial = function (url, title) {
    if (!/^https:\/\//.test(url)) return;
    if (A.settings.socialExternal) { if (AB && AB.openExternal) AB.openExternal(url); else A.toast('Works in the installed app'); return; }
    if (AB && AB.openInApp) AB.openInApp(url, title || ''); else A.toast('Opens inside the installed app');
  };
  A.playVideo = function (id, title) { if (AB && AB.playVideo) AB.playVideo(id, title || ''); else A.toast('Videos play inside the installed app'); };

  /* ---------- latest videos ---------- */
  function cached() { try { var t = AB && AB.ytCached ? AB.ytCached() : ''; return t ? JSON.parse(t) : null; } catch (e) { return null; } }
  A.ytRefresh = function (force) {
    if (!AB || !AB.ytRefresh) return; var last = S.get('ytChecked', 0);
    if (!force && Date.now() - last < 6 * 3600 * 1000) return;
    S.set('ytChecked', Date.now()); var so = A.social(); AB.ytRefresh(so.youtube.videos || so.youtube.url, so.channelId || '');
  };
  W.onYtResult = function (json) {
    var r; try { r = JSON.parse(json); } catch (e) { return; }
    if (!r.ok) { S.set('ytError', r.error || 'error'); if (A.cur && A.cur.name === 'social') A.toast('Could not load videos: ' + (r.error || 'error')); } else S.del('ytError');
    if (A.cur && (A.cur.name === 'social' || A.cur.name === 'home')) A.refresh();
  };
  function videoRow(v) {
    var d = ''; try { d = new Date(v.published).toLocaleDateString(); } catch (e) {}
    return '<button class="item" style="display:flex;gap:10px;align-items:center" data-act="ytPlay" data-id="' + esc(v.id) + '" data-t="' + esc(v.title) + '">' + (v.thumb ? '<img src="' + esc(v.thumb) + '" alt="" width="96" height="54" style="border-radius:8px;flex:none;object-fit:cover" onerror="this.style.display=\'none\'">' : '') + '<span style="color:var(--text)"><b>' + esc(v.title) + '</b><span style="display:block;color:var(--muted);font-size:.8rem">' + esc(d) + ' \u00b7 \u25B6 Watch in the app</span></span></button>';
  }
  AC.ytPlay = function (el) { A.playVideo(el.getAttribute('data-id'), el.getAttribute('data-t')); };
  AC.ytReload = function () { A.toast('Checking for new videos\u2026'); A.ytRefresh(true); };
  AC.socOpen = function (el) { A.openSocial(el.getAttribute('data-u'), el.getAttribute('data-t')); };

  /* ---------- Stay connected screen ---------- */
  SC.social = function () {
    var so = A.social(), c = cached(), err = S.get('ytError', '');
    var h = '<div class="hero"><div class="eyebrow">' + esc(so.tagline) + '</div><h2>' + esc(so.name) + '</h2><p>' + esc(so.about) + '</p></div>';
    h += '<div class="list">' + ['youtube', 'instagram', 'facebook'].map(function (k) { var x = so[k]; return '<button class="item" data-act="socOpen" data-u="' + esc(x.url) + '" data-t="' + esc(x.label) + '"><b>' + ICON[k] + ' ' + esc(x.label) + '</b><span>' + esc(x.handle) + ' \u00b7 ' + (A.settings.socialExternal ? 'opens in the ' + esc(x.label) + ' app' : 'opens inside this app') + '</span></button>'; }).join('') + '</div>';
    h += '<h3 style="margin:16px 0 6px">Latest videos</h3>';
    if (c && c.videos) h += '<div class="list">' + c.videos.slice(0, 10).map(videoRow).join('') + '</div><p class="small muted">Updated ' + new Date(c.ts).toLocaleString() + '. Saved for offline browsing; videos need internet to play.</p>';
    else h += '<div class="banner">' + (AB && AB.ytRefresh ? (err ? 'Could not load videos yet: ' + esc(err) : 'Loading your latest videos\u2026') : 'Your latest videos appear here in the installed app.') + '</div>';
    h += '<div class="row" style="margin-top:8px"><button class="btn" data-act="ytReload">Refresh videos</button><button class="btn alt" data-act="socOpen" data-u="' + esc(so.youtube.url + '?sub_confirmation=1') + '" data-t="YouTube">Subscribe</button></div>';
    h += '<div class="banner">Facebook, Instagram and YouTube may ask you to sign in, and they can refuse sign-in inside an app. If so, switch on \u201COpen in the real apps\u201D in Settings \u2192 Social.</div>';
    h += '<button class="btn alt block" data-act="inviteFriend">Invite a friend to the app</button>';
    return { title: 'Stay Connected', html: h, after: function () { A.ytRefresh(false); } };
  };
  AC.inviteFriend = function () { A.bridge.share('Join me with Rise With The Word \u2014 daily Gospel, Bible, prayer and saints in one app.'); };

  /* ---------- hook into Home, Discover, Me ---------- */
  var oHome = SC.home;
  SC.home = function () {
    var o = oHome(), so = A.social(), c = cached(), v = c && c.videos && c.videos[0];
    o.html = '<p class="center small" style="letter-spacing:.14em;color:var(--gold);margin:2px 0 10px">' + esc(so.tagline) + '</p>' + o.html;
    o.html += '<div class="card" style="margin-top:12px"><h3>Stay connected</h3>' + (v ? '<button class="item" style="margin-bottom:8px;display:flex;gap:10px;align-items:center" data-act="ytPlay" data-id="' + esc(v.id) + '" data-t="' + esc(v.title) + '">' + (v.thumb ? '<img src="' + esc(v.thumb) + '" alt="" width="96" height="54" style="border-radius:8px;flex:none" onerror="this.style.display=\'none\'">' : '') + '<span style="color:var(--text)"><span class="small muted">Latest video</span><b style="display:block">' + esc(v.title) + '</b></span></button>' : '') +
      '<div class="row">' + ['youtube', 'instagram', 'facebook'].map(function (k) { return '<button class="chip" data-act="socOpen" data-u="' + esc(so[k].url) + '" data-t="' + esc(so[k].label) + '">' + ICON[k] + ' ' + esc(so[k].label) + '</button>'; }).join('') + '<button class="chip on" data-act="go" data-arg="social">All</button></div></div>';
    setTimeout(function () { A.ytRefresh(false); }, 1500);
    return o;
  };
  function addTile(name, tile) { var o0 = SC[name]; SC[name] = function () { var o = o0.apply(null, arguments), i = o.html.lastIndexOf('</div>'); o.html = o.html.slice(0, i) + tile + o.html.slice(i); return o; }; }
  addTile('discover', '<button class="tile" data-act="go" data-arg="social"><span class="ico">\uD83D\uDCFA</span><b>Videos &amp; Social</b><span>YouTube, Instagram, Facebook</span></button>');
  addTile('me', '<button class="tile" data-act="go" data-arg="social"><span class="ico">\uD83D\uDCFA</span><b>Stay Connected</b><span>Our channels</span></button>');

  /* ---------- link a video to a story, saint or day (via the "videos" pack) ---------- */
  function vidFor(key) { var p = A.packs.videos, m = p && (p.items && !Array.isArray(p.items) ? p.items : p); var v = m && m[key]; return v && /^[A-Za-z0-9_-]{11}$/.test(v) ? v : null; }
  function vidCard(id, label) { return '<div class="card"><button class="btn block" data-act="ytPlay" data-id="' + esc(id) + '" data-t="' + esc(label) + '">\u25B6 Watch our video: ' + esc(label) + '</button></div>'; }
  var oStory = SC.story;
  SC.story = function (id) { var o = oStory(id), v = vidFor('story:' + id), s = W.RWTW_STORIES.filter(function (x) { return x.id === id; })[0]; if (v && s && o.html) o.html = o.html.replace('<div class="row"><button class="btn" data-act="storyRead"', vidCard(v, s.title) + '<div class="row"><button class="btn" data-act="storyRead"'); return o; };
  var oToday = SC.today;
  SC.today = function (key) { var o = oToday(key), v = vidFor('day:' + key); if (v) o.html += vidCard(v, 'today\u2019s Gospel'); return o; };
  var oSaints = SC.saints;
  SC.saints = function (key) { var o = oSaints(key), dt = key ? A.dateFromKey(key) : new Date(), l = W.Liturgy.saintsOn(dt.getMonth() + 1, dt.getDate()); l.forEach(function (s) { var v = vidFor('saint:' + s.md + '|' + s.name); if (v) o.html += vidCard(v, s.name); }); return o; };

  /* ---------- share signature ---------- */
  var share0 = A.bridge.share;
  A.bridge.share = function (text) {
    if (A.settings.addSig !== false) { var so = A.social(); text += '\n\n\u25B6 YouTube ' + so.youtube.handle + ' \u00b7 Instagram ' + so.instagram.handle + '\n' + so.youtube.url; }
    share0(text);
  };

  /* ---------- settings ---------- */
  var oSettings = SC.settings;
  SC.settings = function () {
    var o = oSettings(), s = A.settings;
    o.html += '<div class="card"><h3>Social</h3>' +
      '<p><label style="color:var(--text)"><input type="checkbox" id="soExt"' + (s.socialExternal ? ' checked' : '') + '> Open links in the real YouTube / Facebook / Instagram apps (instead of inside this app)</label></p>' +
      '<p><label style="color:var(--text)"><input type="checkbox" id="soSig"' + (s.addSig !== false ? ' checked' : '') + '> Add my channel links when I share</label></p>' +
      '<p><label style="color:var(--text)"><input type="checkbox" id="soNote"' + (s.ytNotify !== false ? ' checked' : '') + '> Notify me when a new video is published</label></p>' +
      '<label>YouTube channel ID (optional, starts with UC \u2014 only needed if videos do not load)</label><input type="text" id="soCid" value="' + esc(s.channelId || '') + '" placeholder="UC\u2026">' +
      '<button class="btn" data-act="socSave">Save social settings</button></div>';
    return o;
  };
  AC.socSave = function () {
    var cid = A.$('#soCid').value.trim(); if (cid && !/^UC[A-Za-z0-9_-]{22}$/.test(cid)) { A.toast('A channel ID has 24 characters and starts with UC'); return; }
    var s = A.settings; s.socialExternal = A.$('#soExt').checked; s.addSig = A.$('#soSig').checked; s.ytNotify = A.$('#soNote').checked; s.channelId = cid; A.saveSettings();
    if (AB && AB.setYtNotify) AB.setYtNotify(s.ytNotify); if (s.ytNotify && A.bridge.notifyPermission) A.bridge.notifyPermission();
    S.set('ytChecked', 0); A.toast('\u2713 Saved');
  };
  setTimeout(function () { if (AB && AB.setYtNotify) AB.setYtNotify(A.settings.ytNotify !== false); }, 1200);
})();
