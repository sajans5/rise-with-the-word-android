(function () {
  'use strict';
  var A = window.RWTW, B = window.Bible;
  try { B.init(); } catch (e) { console.log('Bible init failed', e); }
  A.applySettings();
  A.initContent();
  A.root('home');
  setTimeout(function () { try { A.aiStore.migrate(); A.syncReminders(); A.bridge.setFeedUrl(A.feedUrl()); A.autoSync(); } catch (e) {} }, 2500);
})();
