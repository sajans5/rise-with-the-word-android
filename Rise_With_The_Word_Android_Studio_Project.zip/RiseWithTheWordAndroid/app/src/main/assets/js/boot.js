(function () {
  'use strict';
  var A = window.RWTW, B = window.Bible;
  try { B.init(); } catch (e) { console.log('Bible init failed', e); }
  A.applySettings();
  A.initContent();
  A.root('home');
  setTimeout(function () { try { A.syncReminders(); A.autoSync(); } catch (e) {} }, 2500);
})();
