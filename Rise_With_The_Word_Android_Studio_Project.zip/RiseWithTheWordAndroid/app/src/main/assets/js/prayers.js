/* Traditional Catholic prayers and devotions (public-domain / traditional texts).
   Fields ending in _ml hold Malayalam text. Malayalam texts here are provided as a starting
   point: please have a native speaker or your parish priest review them before publishing. */
window.RWTW_PRAYERS = (function () {
  var P = {};
  function add(id, title, text, extra) { P[id] = Object.assign({ id: id, title: title, text: text }, extra || {}); }

  add('sign', 'Sign of the Cross', 'In the name of the Father, and of the Son, and of the Holy Spirit. Amen.',
    { title_ml: 'കുരിശടയാളം', text_ml: 'പിതാവിന്റെയും പുത്രന്റെയും പരിശുദ്ധാത്മാവിന്റെയും നാമത്തിൽ. ആമ്മേൻ.' });
  add('our-father', 'Our Father', 'Our Father, who art in heaven, hallowed be thy name; thy kingdom come; thy will be done on earth as it is in heaven. Give us this day our daily bread; and forgive us our trespasses as we forgive those who trespass against us; and lead us not into temptation, but deliver us from evil. Amen.',
    { title_ml: 'സ്വർഗ്ഗസ്ഥനായ പിതാവേ', text_ml: 'സ്വർഗ്ഗസ്ഥനായ ഞങ്ങളുടെ പിതാവേ, അങ്ങയുടെ നാമം പൂജിതമാകണമേ. അങ്ങയുടെ രാജ്യം വരണമേ. അങ്ങയുടെ തിരുവിഷ്ടം സ്വർഗ്ഗത്തിലെപ്പോലെ ഭൂമിയിലും ആകണമേ. ഞങ്ങൾക്കാവശ്യമായ ആഹാരം ഇന്നു ഞങ്ങൾക്കു തരണമേ. ഞങ്ങളോടു തെറ്റു ചെയ്യുന്നവരോടു ഞങ്ങൾ ക്ഷമിക്കുന്നതുപോലെ ഞങ്ങളുടെ തെറ്റുകൾ ഞങ്ങളോടും ക്ഷമിക്കണമേ. ഞങ്ങളെ പ്രലോഭനത്തിൽ ഉൾപ്പെടുത്തരുതേ. തിന്മയിൽ നിന്നു ഞങ്ങളെ രക്ഷിക്കണമേ. ആമ്മേൻ.' });
  add('hail-mary', 'Hail Mary', 'Hail Mary, full of grace, the Lord is with thee; blessed art thou among women, and blessed is the fruit of thy womb, Jesus. Holy Mary, Mother of God, pray for us sinners, now and at the hour of our death. Amen.',
    { title_ml: 'നന്മ നിറഞ്ഞ മറിയമേ', text_ml: 'നന്മ നിറഞ്ഞ മറിയമേ, സ്വസ്തി! കർത്താവു നിന്നോടുകൂടെ. സ്ത്രീകളിൽ നീ അനുഗ്രഹീതയാകുന്നു. നിന്റെ ഉദരത്തിന്റെ ഫലമായ ഈശോയും അനുഗ്രഹീതനാകുന്നു. പരിശുദ്ധ മറിയമേ, തമ്പുരാന്റെ അമ്മേ, പാപികളായ ഞങ്ങൾക്കുവേണ്ടി ഇപ്പോഴും ഞങ്ങളുടെ മരണസമയത്തും പ്രാർത്ഥിക്കണമേ. ആമ്മേൻ.' });
  add('glory-be', 'Glory Be', 'Glory be to the Father, and to the Son, and to the Holy Spirit, as it was in the beginning, is now, and ever shall be, world without end. Amen.',
    { title_ml: 'പിതാവിനും പുത്രനും മഹത്വം', text_ml: 'പിതാവിനും പുത്രനും പരിശുദ്ധാത്മാവിനും മഹത്വം. ആദിയിലെപ്പോലെ ഇപ്പോഴും എപ്പോഴും എന്നേക്കും. ആമ്മേൻ.' });
  add('creed', 'The Apostles\u2019 Creed', 'I believe in God, the Father almighty, Creator of heaven and earth, and in Jesus Christ, his only Son, our Lord, who was conceived by the Holy Spirit, born of the Virgin Mary, suffered under Pontius Pilate, was crucified, died and was buried; he descended into hell; on the third day he rose again from the dead; he ascended into heaven, and is seated at the right hand of God the Father almighty; from there he will come to judge the living and the dead. I believe in the Holy Spirit, the holy Catholic Church, the communion of saints, the forgiveness of sins, the resurrection of the body, and life everlasting. Amen.');
  add('fatima', 'Fatima Prayer', 'O my Jesus, forgive us our sins, save us from the fires of hell, lead all souls to heaven, especially those in most need of thy mercy.');
  add('salve', 'Hail, Holy Queen (Salve Regina)', 'Hail, holy Queen, Mother of mercy, our life, our sweetness and our hope. To thee do we cry, poor banished children of Eve; to thee do we send up our sighs, mourning and weeping in this valley of tears. Turn then, most gracious advocate, thine eyes of mercy toward us; and after this our exile, show unto us the blessed fruit of thy womb, Jesus. O clement, O loving, O sweet Virgin Mary. Pray for us, O holy Mother of God, that we may be made worthy of the promises of Christ. Amen.');
  add('rosary-close', 'Closing Prayer of the Rosary', 'O God, whose only-begotten Son, by his life, death and resurrection, has purchased for us the rewards of eternal life, grant, we beseech thee, that meditating on these mysteries of the most holy Rosary of the Blessed Virgin Mary, we may imitate what they contain and obtain what they promise, through the same Christ our Lord. Amen.');
  add('contrition', 'Act of Contrition', 'O my God, I am heartily sorry for having offended Thee, and I detest all my sins because of Thy just punishments, but most of all because they offend Thee, my God, who art all good and deserving of all my love. I firmly resolve, with the help of Thy grace, to sin no more and to avoid the near occasions of sin. Amen.');
  add('angelus', 'The Angelus', 'V. The Angel of the Lord declared unto Mary.\nR. And she conceived of the Holy Spirit.\n(Hail Mary\u2026)\nV. Behold the handmaid of the Lord.\nR. Be it done unto me according to thy word.\n(Hail Mary\u2026)\nV. And the Word was made flesh.\nR. And dwelt among us.\n(Hail Mary\u2026)\nV. Pray for us, O holy Mother of God.\nR. That we may be made worthy of the promises of Christ.\nLet us pray: Pour forth, we beseech thee, O Lord, thy grace into our hearts, that we, to whom the incarnation of Christ thy Son was made known by the message of an angel, may by his passion and cross be brought to the glory of his resurrection. Through the same Christ our Lord. Amen.');
  add('regina', 'Regina Caeli (Easter Season)', 'Queen of Heaven, rejoice, alleluia. For He whom you did merit to bear, alleluia, has risen as He said, alleluia. Pray for us to God, alleluia.\nV. Rejoice and be glad, O Virgin Mary, alleluia.\nR. For the Lord has truly risen, alleluia.');
  add('memorare', 'The Memorare', 'Remember, O most gracious Virgin Mary, that never was it known that anyone who fled to thy protection, implored thy help, or sought thy intercession was left unaided. Inspired by this confidence, I fly unto thee, O Virgin of virgins, my Mother; to thee do I come, before thee I stand, sinful and sorrowful. O Mother of the Word Incarnate, despise not my petitions, but in thy mercy hear and answer me. Amen.');
  add('michael', 'Prayer to St Michael the Archangel', 'Saint Michael the Archangel, defend us in battle. Be our protection against the wickedness and snares of the devil. May God rebuke him, we humbly pray; and do thou, O Prince of the heavenly host, by the power of God, cast into hell Satan and all the evil spirits who prowl about the world seeking the ruin of souls. Amen.');
  add('angel', 'Prayer to the Guardian Angel', 'Angel of God, my guardian dear, to whom God\u2019s love commits me here, ever this day be at my side, to light and guard, to rule and guide. Amen.');
  add('anima', 'Anima Christi', 'Soul of Christ, sanctify me. Body of Christ, save me. Blood of Christ, inebriate me. Water from the side of Christ, wash me. Passion of Christ, strengthen me. O good Jesus, hear me. Within thy wounds hide me. Suffer me not to be separated from thee. From the malicious enemy defend me. In the hour of my death call me, and bid me come to thee, that with thy saints I may praise thee for ever and ever. Amen.');
  add('spirit', 'Come, Holy Spirit', 'Come, Holy Spirit, fill the hearts of thy faithful and kindle in them the fire of thy love.\nV. Send forth thy Spirit and they shall be created.\nR. And thou shalt renew the face of the earth.\nLet us pray: O God, who didst instruct the hearts of the faithful by the light of the Holy Spirit, grant that by the same Spirit we may be truly wise and ever rejoice in his consolation, through Christ our Lord. Amen.');
  add('grace-before', 'Grace before Meals', 'Bless us, O Lord, and these thy gifts, which we are about to receive from thy bounty, through Christ our Lord. Amen.');
  add('grace-after', 'Grace after Meals', 'We give thee thanks, almighty God, for all thy benefits, who livest and reignest for ever. Amen.');
  add('eternal-rest', 'Prayer for the Dead', 'Eternal rest grant unto them, O Lord, and let perpetual light shine upon them. May they rest in peace. Amen.');
  add('faith-hope-charity', 'Acts of Faith, Hope and Love', 'O my God, I believe in thee and all that thy holy Church teaches, because thou hast revealed it, who canst neither deceive nor be deceived. O my God, relying on thy almighty power and infinite mercy and promises, I hope to gain pardon of my sins, the help of thy grace, and life everlasting, through the merits of Jesus Christ, my Lord and Redeemer. O my God, I love thee above all things, with my whole heart and soul, because thou art all-good and worthy of all love. I love my neighbour as myself for the love of thee. Amen.');
  add('francis', 'Peace Prayer (attributed to St Francis)', 'Lord, make me an instrument of your peace: where there is hatred, let me sow love; where there is injury, pardon; where there is doubt, faith; where there is despair, hope; where there is darkness, light; and where there is sadness, joy. O Divine Master, grant that I may not so much seek to be consoled as to console; to be understood as to understand; to be loved as to love. For it is in giving that we receive; it is in pardoning that we are pardoned; and it is in dying that we are born to eternal life. Amen.');
  add('morning-offering', 'Morning Offering', 'O Jesus, through the Immaculate Heart of Mary, I offer you my prayers, works, joys and sufferings of this day for all the intentions of your Sacred Heart, in union with the Holy Sacrifice of the Mass throughout the world, for the salvation of souls, the reparation for sins, the reunion of all Christians, and in particular for the intentions of the Holy Father this month. Amen.');
  add('st-joseph', 'Prayer to St Joseph', 'To thee, O blessed Joseph, we have recourse in our affliction, and having implored the help of thy most holy Spouse, we confidently invoke thy patronage also. Through that charity which bound thee to the Immaculate Virgin Mother of God, and through the paternal love with which thou didst embrace the Child Jesus, we humbly beseech thee graciously to regard the inheritance which Jesus Christ has purchased by his blood, and to aid us in our necessities by thy power and strength. Amen.');
  add('trust', 'Jesus, I Trust in You', 'Jesus, I trust in You. Jesus, I trust in You. Jesus, I trust in You.');

  var order = ['sign', 'our-father', 'hail-mary', 'glory-be', 'creed', 'fatima', 'salve', 'rosary-close', 'contrition', 'angelus', 'regina', 'memorare', 'michael', 'angel', 'anima', 'spirit', 'grace-before', 'grace-after', 'eternal-rest', 'faith-hope-charity', 'francis', 'morning-offering', 'st-joseph', 'trust'];

  /* ---------- Rosary ---------- */
  var mysteries = {
    joyful: { name: 'Joyful Mysteries', days: [1, 6], list: [
      ['The Annunciation', 'Luke 1:26-38', 'Humility'], ['The Visitation', 'Luke 1:39-56', 'Love of neighbour'],
      ['The Nativity', 'Luke 2:1-20', 'Poverty of spirit and trust in God'], ['The Presentation in the Temple', 'Luke 2:22-38', 'Obedience and purity'],
      ['The Finding of Jesus in the Temple', 'Luke 2:41-52', 'Joy in finding Jesus'] ] },
    luminous: { name: 'Luminous Mysteries', days: [4], list: [
      ['The Baptism of Jesus', 'Matthew 3:13-17', 'Openness to the Holy Spirit'], ['The Wedding at Cana', 'John 2:1-12', 'To Jesus through Mary'],
      ['The Proclamation of the Kingdom', 'Mark 1:14-15', 'Repentance and trust in God'], ['The Transfiguration', 'Luke 9:28-36', 'Desire for holiness'],
      ['The Institution of the Eucharist', 'Luke 22:14-20', 'Adoration'] ] },
    sorrowful: { name: 'Sorrowful Mysteries', days: [2, 5], list: [
      ['The Agony in the Garden', 'Matthew 26:36-46', 'Sorrow for sin'], ['The Scourging at the Pillar', 'Matthew 27:15-26', 'Purity'],
      ['The Crowning with Thorns', 'Matthew 27:27-31', 'Courage'], ['The Carrying of the Cross', 'John 19:17', 'Patience in suffering'],
      ['The Crucifixion', 'Luke 23:33-46', 'Salvation of souls'] ] },
    glorious: { name: 'Glorious Mysteries', days: [0, 3], list: [
      ['The Resurrection', 'John 20:1-18', 'Faith'], ['The Ascension', 'Acts 1:6-11', 'Hope'],
      ['The Descent of the Holy Spirit', 'Acts 2:1-13', 'Love of God'], ['The Assumption of Mary', 'Revelation 12:1', 'Grace of a happy death'],
      ['The Coronation of Mary', 'Revelation 12:1', 'Devotion to Mary'] ] }
  };
  mysteries.joyful.name_ml = 'ആനന്ദ രഹസ്യങ്ങൾ'; mysteries.luminous.name_ml = 'പ്രകാശ രഹസ്യങ്ങൾ';
  mysteries.sorrowful.name_ml = 'ദുഃഖ രഹസ്യങ്ങൾ'; mysteries.glorious.name_ml = 'മഹിമ രഹസ്യങ്ങൾ';

  function rosarySteps(setId) {
    var m = mysteries[setId], s = [];
    s.push({ h: 'Begin', p: 'sign' }, { h: 'Apostles\u2019 Creed', p: 'creed' }, { h: 'Our Father', p: 'our-father' });
    for (var i = 1; i <= 3; i++) s.push({ h: 'Hail Mary (' + i + ' of 3)', p: 'hail-mary', note: i === 1 ? 'For an increase in faith' : i === 2 ? 'For an increase in hope' : 'For an increase in love' });
    s.push({ h: 'Glory Be', p: 'glory-be' });
    m.list.forEach(function (x, d) {
      s.push({ h: (d + 1) + ordS(d + 1) + ' Mystery: ' + x[0], p: 'our-father', mystery: x, dec: d + 1, note: 'Scripture: ' + x[1] + ' \u00b7 Fruit: ' + x[2] });
      for (var k = 1; k <= 10; k++) s.push({ h: 'Hail Mary ' + k + ' of 10', p: 'hail-mary', dec: d + 1, mystery: x, bead: k });
      s.push({ h: 'Glory Be', p: 'glory-be', dec: d + 1, mystery: x });
      s.push({ h: 'Fatima Prayer', p: 'fatima', dec: d + 1, mystery: x });
    });
    s.push({ h: 'Hail, Holy Queen', p: 'salve' }, { h: 'Closing Prayer', p: 'rosary-close' }, { h: 'Sign of the Cross', p: 'sign' });
    return s;
  }
  function ordS(n) { return ['th', 'st', 'nd', 'rd', 'th', 'th'][n] || 'th'; }

  /* ---------- Divine Mercy Chaplet ---------- */
  var mercy = {
    title: 'Chaplet of Divine Mercy',
    intro: 'Given to St Faustina Kowalska. Traditionally prayed on ordinary rosary beads, especially at 3 o\u2019clock, the hour of mercy.',
    open: 'You expired, Jesus, but the source of life gushed forth for souls, and the ocean of mercy opened up for the whole world. O Fount of Life, unfathomable Divine Mercy, envelop the whole world and empty Yourself out upon us.\n\nO Blood and Water, which gushed forth from the Heart of Jesus as a fount of mercy for us, I trust in You! (three times)',
    big: 'Eternal Father, I offer You the Body and Blood, Soul and Divinity of Your Dearly Beloved Son, Our Lord Jesus Christ, in atonement for our sins and those of the whole world.',
    small: 'For the sake of His sorrowful Passion, have mercy on us and on the whole world.',
    end: 'Holy God, Holy Mighty One, Holy Immortal One, have mercy on us and on the whole world. (three times)\n\nO Blood and Water, which gushed forth from the Heart of Jesus as a fount of mercy for us, I trust in You!'
  };
  function mercySteps() {
    var s = [{ h: 'Begin', p: 'sign' }, { h: 'Opening Prayer', text: mercy.open }, { h: 'Our Father', p: 'our-father' }, { h: 'Hail Mary', p: 'hail-mary' }, { h: 'The Creed', p: 'creed' }];
    for (var d = 1; d <= 5; d++) {
      s.push({ h: 'Decade ' + d + ' \u2013 large bead', text: mercy.big, dec: d });
      for (var k = 1; k <= 10; k++) s.push({ h: 'Decade ' + d + ' \u2013 bead ' + k + ' of 10', text: mercy.small, dec: d, bead: k });
    }
    s.push({ h: 'Closing', text: mercy.end }, { h: 'Sign of the Cross', p: 'sign' });
    return s;
  }

  /* ---------- Litanies ---------- */
  function litany(title, intro, invocations, response) { return { title: title, intro: intro, items: invocations, response: response }; }
  var litanies = {
    loreto: litany('Litany of the Blessed Virgin Mary (Loreto)', 'Leader says the invocation, all respond.', [
      'Holy Mary', 'Holy Mother of God', 'Holy Virgin of virgins', 'Mother of Christ', 'Mother of the Church', 'Mother of divine grace', 'Mother most pure', 'Mother most chaste', 'Mother inviolate', 'Mother undefiled', 'Mother most amiable', 'Mother most admirable', 'Mother of good counsel', 'Mother of our Creator', 'Mother of our Saviour', 'Virgin most prudent', 'Virgin most venerable', 'Virgin most renowned', 'Virgin most powerful', 'Virgin most merciful', 'Virgin most faithful', 'Mirror of justice', 'Seat of wisdom', 'Cause of our joy', 'Spiritual vessel', 'Vessel of honour', 'Singular vessel of devotion', 'Mystical rose', 'Tower of David', 'Tower of ivory', 'House of gold', 'Ark of the covenant', 'Gate of heaven', 'Morning star', 'Health of the sick', 'Refuge of sinners', 'Comforter of the afflicted', 'Help of Christians', 'Queen of angels', 'Queen of patriarchs', 'Queen of prophets', 'Queen of apostles', 'Queen of martyrs', 'Queen of confessors', 'Queen of virgins', 'Queen of all saints', 'Queen conceived without original sin', 'Queen assumed into heaven', 'Queen of the most holy Rosary', 'Queen of families', 'Queen of peace'], 'pray for us.'),
    joseph: litany('Litany of St Joseph', 'Leader says the invocation, all respond.', [
      'Saint Joseph', 'Renowned offspring of David', 'Light of patriarchs', 'Spouse of the Mother of God', 'Chaste guardian of the Virgin', 'Foster father of the Son of God', 'Diligent protector of Christ', 'Head of the Holy Family', 'Joseph most just', 'Joseph most chaste', 'Joseph most prudent', 'Joseph most strong', 'Joseph most obedient', 'Joseph most faithful', 'Mirror of patience', 'Lover of poverty', 'Model of workers', 'Glory of home life', 'Guardian of virgins', 'Pillar of families', 'Solace of the wretched', 'Hope of the sick', 'Patron of the dying', 'Terror of demons', 'Protector of Holy Church'], 'pray for us.'),
    humility: litany('Litany of Humility', 'A prayer attributed to Cardinal Rafael Merry del Val. Pray slowly.', [
      'From the desire of being esteemed, deliver me, Jesus', 'From the desire of being loved, deliver me, Jesus', 'From the desire of being extolled, deliver me, Jesus', 'From the desire of being honoured, deliver me, Jesus', 'From the desire of being praised, deliver me, Jesus', 'From the desire of being preferred to others, deliver me, Jesus', 'From the desire of being consulted, deliver me, Jesus', 'From the desire of being approved, deliver me, Jesus', 'From the fear of being humiliated, deliver me, Jesus', 'From the fear of being despised, deliver me, Jesus', 'From the fear of suffering rebukes, deliver me, Jesus', 'From the fear of being forgotten, deliver me, Jesus', 'From the fear of being ridiculed, deliver me, Jesus', 'From the fear of being wronged, deliver me, Jesus', 'From the fear of being suspected, deliver me, Jesus'], 'Jesus, meek and humble of heart, make my heart like yours.')
  };

  /* ---------- Stations of the Cross ---------- */
  var stationsRefrain = ['V. We adore you, O Christ, and we bless you.', 'R. Because by your holy cross you have redeemed the world.'];
  var stations = [
    ['Jesus is condemned to death', 'Pilate yields to the crowd and hands Jesus over. The innocent One is silent before injustice.', 'Lord, give me courage to stand for truth even when the crowd is against it.'],
    ['Jesus takes up his cross', 'Jesus accepts the wood that will bear the sins of the world, freely and with love.', 'Lord, help me carry my own crosses with trust in you.'],
    ['Jesus falls the first time', 'Weakened by suffering, Jesus falls under the weight of the cross, and rises again.', 'Lord, when I fall into sin or discouragement, help me rise again.'],
    ['Jesus meets his Mother', 'Mary and her Son look at each other in silent love. Her heart is pierced as Simeon foretold.', 'Mary, mother of sorrows, stay with all who suffer and all who grieve.'],
    ['Simon of Cyrene helps Jesus carry the cross', 'A stranger is pressed into service and carries the cross behind Jesus.', 'Lord, make me ready to help others carry their burdens.'],
    ['Veronica wipes the face of Jesus', 'A woman steps through the crowd to offer a simple act of tenderness.', 'Lord, let me see your face in the poor and suffering.'],
    ['Jesus falls the second time', 'Again Jesus falls, showing that he understands our repeated weakness.', 'Lord, when I fall again, never let me give up hope in your mercy.'],
    ['Jesus meets the women of Jerusalem', 'Jesus comforts the weeping women and calls them to repentance and to care for their children.', 'Lord, teach me to weep for sin and to hand on the faith.'],
    ['Jesus falls the third time', 'Exhausted, Jesus falls a third time near the end of the journey and still rises.', 'Lord, give me perseverance to the end.'],
    ['Jesus is stripped of his garments', 'He who clothes the lilies of the field is stripped and shamed.', 'Lord, free me from pride and from attachment to possessions.'],
    ['Jesus is nailed to the cross', 'Jesus stretches out his arms and is nailed to the cross; he prays for those who crucify him.', 'Lord, help me forgive those who have hurt me.'],
    ['Jesus dies on the cross', 'Jesus cries out, commends his spirit to the Father and dies. The whole world is changed.', 'Lord, by your death, give me life. Into your hands I commend my spirit.'],
    ['Jesus is taken down from the cross', 'Mary receives the lifeless body of her Son in her arms.', 'Mary, help me to hold Jesus close in every sorrow.'],
    ['Jesus is laid in the tomb', 'Friends lay Jesus in a new tomb. Silence falls, but the story is not over.', 'Lord, let me wait in hope for your resurrection.']
  ];

  /* ---------- Novenas ---------- */
  function nov(id, title, when, opening, days, closing) { return { id: id, title: title, when: when, opening: opening, days: days, closing: closing }; }
  var novenas = [
    nov('holy-spirit', 'Novena to the Holy Spirit', 'The original novena: nine days between Ascension and Pentecost.', 'Come, Holy Spirit, fill the hearts of your faithful and kindle in them the fire of your love.', [
      ['Day 1 \u2013 Come, Holy Spirit', 'Acts 1:12-14', 'Holy Spirit, as the apostles waited in prayer with Mary, I wait for you. Open my heart.'],
      ['Day 2 \u2013 Gift of Wisdom', 'Wisdom 7:7-14', 'Spirit of Wisdom, help me to value what is eternal above what passes away.'],
      ['Day 3 \u2013 Gift of Understanding', 'Luke 24:44-48', 'Spirit of Understanding, open the Scriptures and the mysteries of faith to me.'],
      ['Day 4 \u2013 Gift of Counsel', 'Proverbs 3:5-6', 'Spirit of Counsel, guide my decisions and help me to choose what is right.'],
      ['Day 5 \u2013 Gift of Fortitude', '2 Timothy 1:6-8', 'Spirit of Fortitude, give me courage to live and speak my faith.'],
      ['Day 6 \u2013 Gift of Knowledge', 'Ephesians 1:17-19', 'Spirit of Knowledge, show me how to see all things in the light of God.'],
      ['Day 7 \u2013 Gift of Piety', 'Romans 8:14-17', 'Spirit of Piety, teach me to pray as a beloved child of the Father.'],
      ['Day 8 \u2013 Gift of Fear of the Lord', 'Psalm 111:10', 'Spirit of holy fear, give me reverence and a deep desire never to offend God.'],
      ['Day 9 \u2013 Fruits of the Spirit', 'Galatians 5:22-25', 'Spirit of God, bring forth in me love, joy, peace, patience, kindness, goodness, faithfulness, gentleness and self-control.']
    ], 'Come, Holy Spirit, renew the face of the earth. Amen.'),
    nov('divine-mercy', 'Divine Mercy Novena', 'Begins on Good Friday and ends the day before Divine Mercy Sunday. Can be prayed at any time.', 'Jesus, I trust in You. Eternal Father, look upon us with mercy through the Passion of Your Son.', [
      ['Day 1 \u2013 All humanity, especially sinners', 'Luke 15:1-7', 'Most Merciful Jesus, whose very nature it is to have compassion on us, do not look upon our sins but upon our trust in Your goodness.'],
      ['Day 2 \u2013 Priests and religious', 'Matthew 9:36-38', 'Most Merciful Jesus, from whom comes all that is good, increase Your grace in priests and consecrated persons.'],
      ['Day 3 \u2013 Devout and faithful souls', 'John 15:9-12', 'Most Merciful Jesus, grant that Your faithful may grow in love and in perseverance.'],
      ['Day 4 \u2013 Those who do not yet know Jesus', 'Acts 17:22-28', 'Most Compassionate Jesus, draw to Yourself all who have not yet known You.'],
      ['Day 5 \u2013 Those separated from the Church', 'John 17:20-23', 'Most Merciful Jesus, heal the divisions among Christians and bring us to unity.'],
      ['Day 6 \u2013 Meek and humble souls and children', 'Matthew 18:1-5', 'Most Merciful Jesus, bless the little ones and the humble of heart.'],
      ['Day 7 \u2013 Those who venerate and proclaim Mercy', 'Psalm 89:2', 'Most Merciful Jesus, whose Heart is Love itself, let those who proclaim Your mercy grow in trust.'],
      ['Day 8 \u2013 The souls in purgatory', '2 Maccabees 12:43-46', 'Most Merciful Jesus, have mercy on the souls in purgatory and bring them to Your glory.'],
      ['Day 9 \u2013 Souls who have grown lukewarm', 'Revelation 3:14-22', 'Most Compassionate Jesus, enkindle the fire of Your love in cold and indifferent hearts.']
    ], 'Jesus, I trust in You. Amen.'),
    nov('st-joseph', 'Novena to St Joseph', 'Pray before 19 March, before 1 May, or whenever you need a father\u2019s help.', 'St Joseph, guardian of the Holy Family, pray for us.', [
      ['Day 1 \u2013 Joseph the just man', 'Matthew 1:18-25', 'St Joseph, help me to be honest and kind in every decision.'],
      ['Day 2 \u2013 Joseph who listens to God', 'Matthew 2:13-15', 'St Joseph, teach me to listen for God\u2019s voice and to obey quickly.'],
      ['Day 3 \u2013 Joseph the protector', 'Matthew 2:19-23', 'St Joseph, protect my family and everyone I love.'],
      ['Day 4 \u2013 Joseph the worker', 'Matthew 13:53-58', 'St Joseph, bless my work and the work of all who labour.'],
      ['Day 5 \u2013 Joseph the father', 'Luke 2:41-52', 'St Joseph, make me a loving parent, mentor and friend.'],
      ['Day 6 \u2013 Joseph the silent', 'Psalm 62:1-2', 'St Joseph, teach me the strength of silence and prayer.'],
      ['Day 7 \u2013 Joseph of faith', 'Genesis 15:1-6', 'St Joseph, strengthen my faith when the path is unclear.'],
      ['Day 8 \u2013 Joseph the poor man', 'Luke 2:22-24', 'St Joseph, free me from greed and teach me to trust in Providence.'],
      ['Day 9 \u2013 Patron of a happy death', 'John 14:1-3', 'St Joseph, stay with me at the hour of my death.']
    ], 'St Joseph, pray for us. Amen.'),
    nov('immaculate', 'Novena to Our Lady (Immaculate Conception)', 'Traditionally 29 November \u2013 7 December.', 'Hail Mary, full of grace.', [
      ['Day 1', 'Genesis 3:15', 'Mary, Immaculate, help me to turn away from sin.'], ['Day 2', 'Luke 1:26-28', 'Mary, full of grace, obtain for me a heart open to God\u2019s grace.'],
      ['Day 3', 'Luke 1:38', 'Mary, handmaid of the Lord, teach me to say yes to God.'], ['Day 4', 'Luke 1:46-55', 'Mary, help me to magnify the Lord in every circumstance.'],
      ['Day 5', 'Luke 2:19', 'Mary, who pondered all things in your heart, teach me to pray.'], ['Day 6', 'John 2:1-5', 'Mary, lead me to do whatever Jesus tells me.'],
      ['Day 7', 'John 19:25-27', 'Mary, mother of all, be with all who suffer.'], ['Day 8', 'Acts 1:14', 'Mary, mother of the Church, pray for the unity of Christians.'],
      ['Day 9', 'Revelation 12:1', 'Mary, Queen of heaven, obtain for me perseverance to the end.']
    ], 'Immaculate Mary, pray for us. Amen.'),
    nov('christmas', 'Christmas Novena', '16\u201324 December, preparing hearts for the birth of Christ.', 'Come, Lord Jesus.', [
      ['Day 1 \u2013 16 Dec', 'Isaiah 9:1-6', 'Prince of Peace, bring peace to my home.'], ['Day 2 \u2013 17 Dec', 'Genesis 49:8-10', 'Wisdom of God, teach me your ways.'],
      ['Day 3 \u2013 18 Dec', 'Jeremiah 23:5-8', 'Lord of Might, lead us to freedom.'], ['Day 4 \u2013 19 Dec', 'Judges 13:2-7', 'Root of Jesse, rise among us.'],
      ['Day 5 \u2013 20 Dec', 'Isaiah 7:10-14', 'Key of David, open the doors of my heart.'], ['Day 6 \u2013 21 Dec', 'Song of Songs 2:8-14', 'Dawn from on high, shine on those in darkness.'],
      ['Day 7 \u2013 22 Dec', '1 Samuel 1:24-28', 'King of the nations, be king of my life.'], ['Day 8 \u2013 23 Dec', 'Isaiah 7:10-14', 'Emmanuel, God with us, stay with me.'],
      ['Day 9 \u2013 24 Dec', 'Luke 1:67-79', 'Lord Jesus, come and be born in my heart tonight.']
    ], 'Come, Lord Jesus. Amen.')
  ];

  /* ---------- Routines ---------- */
  var routines = {
    morning: { title: 'Morning Prayer', steps: [
      { h: 'Begin with the Sign of the Cross', p: 'sign' }, { h: 'Give the day to God', p: 'morning-offering' },
      { h: 'Our Father', p: 'our-father' }, { h: 'Guardian Angel', p: 'angel' }, { h: 'Come, Holy Spirit', p: 'spirit' },
      { h: 'Your intentions', text: 'Take a quiet moment to name the people and needs you carry today.' }, { h: 'Close', p: 'glory-be' }] },
    evening: { title: 'Evening Prayer', steps: [
      { h: 'Begin with the Sign of the Cross', p: 'sign' },
      { h: 'Thank God', text: 'Recall the good things of the day and thank God for them.' },
      { h: 'Ask for light', text: 'Holy Spirit, show me how this day looked in your eyes.' },
      { h: 'Review the day', text: 'Where did I love well? Where did I fall short? Name it honestly, without fear.' },
      { h: 'Act of Contrition', p: 'contrition' }, { h: 'Look to tomorrow', text: 'Ask God for help with tomorrow\u2019s tasks and relationships.' },
      { h: 'Hail Mary', p: 'hail-mary' }, { h: 'For the departed', p: 'eternal-rest' }] },
    sleep: { title: 'Prayers before Sleep', steps: [
      { h: 'Sign of the Cross', p: 'sign' }, { h: 'Entrust the night', text: 'Into your hands, Lord, I commend my spirit. Watch over me as I sleep and let me rest in your peace.' },
      { h: 'Psalm 4:9', text: 'In peace I will lie down and sleep, for you alone, O Lord, make me dwell in safety.' },
      { h: 'Guardian Angel', p: 'angel' }, { h: 'Hail Mary', p: 'hail-mary' },
      { h: 'Night blessing', text: 'May the Lord grant us a restful night and a peaceful end. Amen.' }] }
  };

  return { prayers: P, order: order, mysteries: mysteries, rosarySteps: rosarySteps, mercy: mercy, mercySteps: mercySteps, litanies: litanies, stations: stations, stationsRefrain: stationsRefrain, novenas: novenas, routines: routines };
})();
