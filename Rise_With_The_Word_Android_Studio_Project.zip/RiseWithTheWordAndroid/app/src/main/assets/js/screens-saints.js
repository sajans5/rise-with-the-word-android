/* All saints sorted by feast day, saint profile pages, and the patron-saint finder. */
(function () {
  'use strict';
  var W = window, A = W.RWTW, esc = A.esc, SC = A.screens, AC = A.actions, Lit = W.Liturgy;
  var f = { month: new Date().getMonth() + 1, cat: 'All', q: '' };
  var ORDER = { S: 0, F: 1, M: 2, O: 3, L: 4, C: 5 };
  function all() { return Lit.allSaints().filter(function (s) { return A.settings.indianSaints || s.rank !== 'L'; }).sort(function (a, b) { return a.md < b.md ? -1 : a.md > b.md ? 1 : (ORDER[a.rank] - ORDER[b.rank]) || (a.name < b.name ? -1 : 1); }); }
  function dateLabel(md) { var p = md.split('-'); return (+p[1]) + ' ' + Lit.MONTHS[+p[0] - 1].slice(0, 3); }

  SC.saintsAll = function () {
    var list = all(), cats = ['All'];
    list.forEach(function (s) { W.RWTW_SAINT_DETAILS(s).cats.forEach(function (c) { if (cats.indexOf(c) < 0) cats.push(c); }); });
    var h = '<input type="search" id="sa-q" placeholder="Search name, biography or patronage" value="' + esc(f.q) + '"><div class="row" style="margin:8px 0">' +
      '<button class="chip ' + (f.month === 0 ? 'on' : '') + '" data-act="saMonth" data-v="0">Whole year</button>' + Lit.MONTHS.map(function (m, i) { return '<button class="chip ' + (f.month === i + 1 ? 'on' : '') + '" data-act="saMonth" data-v="' + (i + 1) + '">' + m.slice(0, 3) + '</button>'; }).join('') + '</div>' +
      '<div class="row">' + cats.map(function (c) { return '<button class="chip ' + (f.cat === c ? 'on' : '') + '" data-act="saCat" data-v="' + esc(c) + '">' + esc(c) + '</button>'; }).join('') + '</div><p class="small muted" id="sa-count"></p><div id="sa-list" class="list"></div>';
    return { title: 'All Saints by Feast Day', html: h, after: function () { var q = A.$('#sa-q'); q.addEventListener('input', function (e) { f.q = e.target.value; draw(); }); draw(); } };
  };
  function draw() {
    var q = f.q.trim().toLowerCase(), box = A.$('#sa-list'); if (!box) return;
    var res = all().filter(function (s) {
      if (f.month && +s.md.slice(0, 2) !== f.month) return false;
      var d = W.RWTW_SAINT_DETAILS(s); if (f.cat !== 'All' && d.cats.indexOf(f.cat) < 0) return false;
      return !q || (s.name + ' ' + s.bio + ' ' + d.patron).toLowerCase().indexOf(q) >= 0;
    });
    A.$('#sa-count').textContent = res.length + ' saint(s) and feast(s)';
    box.innerHTML = res.map(function (s) { var d = W.RWTW_SAINT_DETAILS(s); return '<button class="item" data-act="saintOpen" data-id="' + esc(A.sid(s)) + '"><b>' + dateLabel(s.md) + ' \u00b7 ' + esc(s.name) + '</b><span>' + esc(Lit.RANKS[s.rank] || '') + (d.years ? ' \u00b7 ' + esc(d.years) : '') + (d.patron ? ' \u00b7 ' + esc(d.patron) : '') + '</span></button>'; }).join('') || '<p class="muted">No match.</p>';
  }
  AC.saMonth = function (el) { f.month = +el.getAttribute('data-v'); A.refresh(); };
  AC.saCat = function (el) { f.cat = el.getAttribute('data-v'); A.refresh(); };
  AC.saintOpen = function (el) { A.go('saintPage', el.getAttribute('data-id')); };

  SC.saintPage = function (id) {
    var p = (id || '').split('|'), rec = Lit.allSaints().filter(function (x) { return x.md === p[0] && x.name === p.slice(1).join('|'); })[0];
    if (!rec) return { html: '<p>Not found.</p>' };
    var d = W.RWTW_SAINT_DETAILS(rec), mm = rec.md.split('-'), same = Lit.saintsOn(+mm[0], +mm[1]).filter(function (x) { return x !== rec; });
    A.recent('saint', id, rec.name);
    var h = '<div class="card"><div class="small muted">' + (+mm[1]) + ' ' + Lit.MONTHS[+mm[0] - 1] + ' \u00b7 ' + esc(Lit.RANKS[rec.rank] || '') + '</div><h3 style="font-size:1.25rem;margin:4px 0">' + esc(rec.name) + '</h3><div>' + d.cats.map(function (c) { return '<span class="chip">' + esc(c) + '</span>'; }).join('') + '</div>' +
      (d.years ? '<p><b>Lived:</b> ' + esc(d.years) + '</p>' : '') + '<p class="reader">' + esc(rec.bio) + '</p>' + (d.patron ? '<p><b>Patron of / invoked for:</b> ' + esc(d.patron) + '</p>' : '') +
      '<p class="small muted">Patronages are traditional devotions, not doctrines. ' + (rec.rank === 'C' ? 'This saint is honoured in the Roman Martyrology or popular devotion and is not part of the General Roman Calendar.' : '') + '</p></div>';
    h += '<div class="card"><h3>Prayer</h3><p class="prayer-text">' + esc(rec.name.replace(/, .*$/, '')) + ', pray for us.\nThat we may be made worthy of the promises of Christ.</p></div>';
    h += (A.ai && A.ai.card ? A.ai.card('saint', id, 'Expand this saint\u2019s profile') : '');
    if (same.length) h += '<h3 style="margin:12px 0 6px">Also on this day</h3><div class="list">' + same.map(function (x) { return '<button class="item" data-act="saintOpen" data-id="' + esc(A.sid(x)) + '"><b>' + esc(x.name) + '</b><span>' + esc(Lit.RANKS[x.rank] || '') + '</span></button>'; }).join('') + '</div>';
    h += '<div class="row" style="margin-top:10px"><button class="btn alt" data-act="saintShare" data-n="' + esc(rec.name) + '" data-b="' + esc(rec.bio + (d.patron ? ' Patron of: ' + d.patron + '.' : '')) + '">' + esc(A.t('share')) + '</button><button class="btn alt" data-act="saintDate" data-k="2026-' + rec.md + '">Day page</button></div>';
    return { title: rec.name, html: h };
  };

  /* patron-saint finder */
  var NEEDS = [['Students', /student|school|universit|teacher|educat/i], ['Mothers and families', /mother|famil|wives|expectant|grandparent|married|marriage/i], ['Children and youth', /youth|child|first communicant|adolescent/i], ['The sick and nurses', /sick|nurse|hospital|leprosy|illness|physician|disease|health|healing/i],
    ['Travellers and pilgrims', /travel|pilgrim|sailor|seafar/i], ['Animals and nature', /animal|ecolog/i], ['Lost things', /lost things/i], ['Musicians', /music/i], ['Priests and clergy', /priest|seminar|confessor|preacher|catechist/i], ['Workers and farmers', /worker|farmer|labour|carpent|builder|miner|domestic/i],
    ['Soldiers and police', /soldier|police/i], ['Writers and journalists', /writer|journalist|editor|translat|librar|historian/i], ['Hopeless causes', /impossible|hopeless|desperate|difficult marriage/i], ['Missionaries', /mission/i], ['Anxiety and mental health', /anxiety|mental/i], ['Immigrants and the poor', /immigrant|the poor|charit|social justice|slavery|trafficking/i], ['Mystics and theologians', /mystic|theolog/i], ['Countries and places', /india|kerala|ireland|france|italy|spain|poland|europe|japan|korea|peru|americas|sri lanka|goa/i]];
  var pq = '';
  SC.patrons = function () {
    return { title: 'Find a Patron Saint', html: '<div class="row">' + NEEDS.map(function (n, i) { return '<button class="chip ' + (pq === String(i) ? 'on' : '') + '" data-act="patronPick" data-v="' + i + '">' + esc(n[0]) + '</button>'; }).join('') + '</div><div id="pat-res" class="list" style="margin-top:8px"></div>', after: patDraw };
  };
  AC.patronPick = function (el) { pq = el.getAttribute('data-v'); A.refresh(); };
  function patDraw() {
    var box = A.$('#pat-res'); if (!box) return; if (pq === '') { box.innerHTML = '<p class="muted small">Choose a need to see saints traditionally invoked for it.</p>'; return; }
    var re = NEEDS[+pq][1], res = all().filter(function (s) { var d = W.RWTW_SAINT_DETAILS(s); return d.patron && re.test(d.patron); });
    box.innerHTML = '<p class="small muted">' + res.length + ' saint(s)</p>' + res.map(function (s) { var d = W.RWTW_SAINT_DETAILS(s); return '<button class="item" data-act="saintOpen" data-id="' + esc(A.sid(s)) + '"><b>' + esc(s.name) + '</b><span>' + esc(d.patron) + ' \u00b7 ' + dateLabel(s.md) + '</span></button>'; }).join('');
  }
})();
