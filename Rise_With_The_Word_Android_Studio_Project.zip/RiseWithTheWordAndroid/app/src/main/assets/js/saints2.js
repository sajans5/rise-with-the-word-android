/* More saints, and extra details (life dates, patronage) for the saints in saints.js.
   Rank C = a saint or blessed honoured in the Roman Martyrology / popular devotion, not part of the General Roman Calendar
   (shown on the Saint pages, never changing the liturgical day).
   Years are the commonly accepted dates; "c." means approximate. Please check against official sources before publishing. */
window.RWTW_SAINTS_MORE = [
"01-04|C|w|Elizabeth Ann Seton|First native-born American saint; a widow and mother who founded the Sisters of Charity and Catholic parish schools.",
"01-05|C|w|John Neumann|Bohemian-born bishop of Philadelphia who organised the first Catholic diocesan school system in the United States.",
"01-06|C|w|André Bessette|Humble Holy Cross brother and doorkeeper in Montreal who led countless people to St Joseph; he built St Joseph's Oratory.",
"01-10|C|w|Gregory of Nyssa|Bishop and theologian, brother of St Basil, who defended the Trinity and wrote on the spiritual life.",
"01-12|C|w|Marguerite Bourgeoys|French-born teacher who founded the Congregation of Notre Dame in Montreal and educated the young settlers.",
"01-15|C|w|Paul the Hermit|Egyptian hermit, traditionally the first Christian hermit, visited by St Anthony the Abbot.",
"01-23|C|w|Marianne Cope|German-born American Franciscan sister who cared for people with leprosy in Hawaii alongside St Damien.",
"02-04|L|r|St John de Britto|Portuguese Jesuit missionary to Tamil Nadu who lived as an Indian ascetic, was beheaded at Oriyur in 1693 and canonized in 1947.",
"02-06|L|r|St Gonsalo Garcia|Born near Vasai (Bassein), India, he was a lay missionary martyred at Nagasaki in 1597 with St Paul Miki and was canonized in 1862.",
"02-09|C|r|Apollonia|Elderly deaconess martyred in Alexandria around 249 after her teeth were broken.",
"02-14|C|r|Valentine|Early Roman martyr (third century) whose feast is widely associated with love and friendship; little is certain about his life.",
"02-25|L|r|Blessed Rani Maria Vattalil|Syro-Malabar Franciscan Clarist sister from Kerala who served poor villagers in Madhya Pradesh and was martyred on 25 February 1995. Beatified 2017.",
"02-27|C|w|Gregory of Narek|Armenian monk, poet and mystic, author of the Book of Lamentations; named a Doctor of the Church in 2015.",
"02-27|C|w|Gabriel of Our Lady of Sorrows|Young Italian Passionist (1838\u20131862) loved for his joyful, hidden holiness; patron of students.",
"03-03|C|w|Katharine Drexel|Philadelphia heiress who gave her fortune and life to serve Native Americans and African Americans, founding the Sisters of the Blessed Sacrament.",
"03-15|C|w|Louise de Marillac|Co-foundress with St Vincent de Paul of the Daughters of Charity, who served the poor and the sick in France.",
"03-23|C|w|Rafqa (Rebecca)|Lebanese Maronite nun who accepted blindness and great suffering united with Christ's passion; canonized 2001.",
"03-24|C|r|Oscar Romero|Archbishop of San Salvador, shot while celebrating Mass in 1980 after defending the poor; canonized 2018.",
"03-25|C|w|Dismas, the Good Thief|The repentant criminal crucified beside Jesus, to whom Jesus promised paradise (Luke 23:39-43).",
"04-08|C|w|Julie Billiart|French foundress of the Sisters of Notre Dame de Namur, dedicated to teaching poor children (1751\u20131816).",
"04-11|C|w|Gemma Galgani|Italian lay mystic (1878\u20131903) known for her deep prayer, humility and union with the Passion of Christ.",
"04-16|C|w|Bernadette Soubirous|The young French girl to whom Our Lady appeared at Lourdes in 1858; she later became a sister and lived a hidden life of prayer and suffering.",
"04-16|C|w|Benedict Joseph Labre|French pilgrim and beggar (1748\u20131783) who lived in poverty and prayer in the streets of Rome.",
"04-27|C|w|Zita|Italian domestic servant (c. 1212\u20131272) whose faithful, humble work made her a model for ordinary working people.",
"04-28|C|w|Gianna Beretta Molla|Italian paediatrician, wife and mother who chose to continue a risky pregnancy and died in 1962; canonized 2004.",
"05-04|C|r|Florian|Roman officer martyred in 304, remembered as a protector against fire and a patron of firefighters.",
"05-06|C|w|Dominic Savio|Pupil of St John Bosco (1842\u20131857) who pursued holiness in everyday school life.",
"05-10|C|w|Damien of Molokai|Belgian priest (1840\u20131889) who served people with leprosy in Hawaii and died of the disease.",
"05-15|C|w|Isidore the Farmer|Spanish farm labourer (c. 1070\u20131130) known for prayer, charity and faithful work in the fields.",
"05-15|C|r|Dymphna|Young Irish martyr (traditionally seventh century), honoured in Belgium, who is invoked by those with anxiety and mental illness.",
"05-16|C|w|Brendan the Navigator|Irish abbot and monk (c. 484\u2013c. 577) remembered for his legendary sea voyage.",
"05-16|C|w|Simon Stock|English Carmelite prior (c. 1165\u20131265) associated with the Brown Scapular devotion.",
"05-17|C|w|Paschal Baylon|Spanish Franciscan lay brother (1540\u20131592) known for his devotion to the Eucharist.",
"05-19|C|w|Celestine V|Hermit who became pope in 1294 and resigned after a few months; he died in 1296.",
"05-24|C|w|Mary, Help of Christians|A title of Our Lady honoured by Catholics and promoted by St John Bosco.",
"05-29|C|w|Paul VI|Pope (1897\u20131978) who concluded the Second Vatican Council; canonized 2018.",
"05-30|C|w|Joan of Arc|French peasant girl (1412\u20131431) who led armies in obedience to her visions and was burned at the stake; canonized 1920.",
"06-26|C|w|Josemar\u00EDa Escriv\u00E1|Spanish priest (1902\u20131975) who founded Opus Dei and taught that ordinary work can become a path to holiness.",
"07-01|C|w|Jun\u00EDpero Serra|Spanish Franciscan missionary (1713\u20131784) who founded missions in California; canonized 2015.",
"07-04|C|w|Pier Giorgio Frassati|Italian youth (1901\u20131925) who loved the poor, the mountains and the Eucharist; canonized 2025.",
"07-12|C|w|Louis and Z\u00E9lie Martin|Parents of St Th\u00E9r\u00E8se, the first married couple canonized together (2015).",
"07-14|C|w|Kateri Tekakwitha|Mohawk-Algonquin woman (1656\u20131680), the first Native American canonized (2012), who lived a life of prayer and purity.",
"07-27|C|r|Pantaleon|Physician and martyr of Nicomedia (died c. 305), honoured as a patron of physicians.",
"08-18|C|w|Helena|Mother of Emperor Constantine (c. 246\u2013c. 330), associated with the finding of the True Cross in Jerusalem.",
"09-08|L|w|Our Lady of Health, Vailankanni|Famous Marian shrine in Tamil Nadu, honoured by pilgrims of every faith; the main feast is celebrated on 8 September.",
"09-10|C|w|Nicholas of Tolentino|Italian Augustinian friar and preacher (c. 1245\u20131305) known for his care of the souls in purgatory.",
"09-17|C|w|Hildegard of Bingen|German abbess, composer, writer and mystic (1098\u20131179); named a Doctor of the Church in 2012.",
"09-18|C|w|Joseph of Cupertino|Italian Franciscan friar (1603\u20131663) remembered for his childlike simplicity and mystical prayer.",
"10-09|C|w|John Henry Newman|English convert, scholar and cardinal (1801\u20131890) whose writings shaped modern Catholic thought; canonized 2019.",
"10-10|C|w|Francis Borgia|Spanish duke who became a Jesuit and the third superior general of the Society of Jesus (1510\u20131572).",
"10-12|C|w|Carlo Acutis|Italian teenager (1991\u20132006) who used computers to spread devotion to the Eucharist; canonized 2025.",
"10-16|C|w|Gerard Majella|Italian Redemptorist brother (1726\u20131755), invoked by expectant mothers.",
"10-20|C|w|Paul of the Cross|Italian founder of the Passionists (1694\u20131775) who preached devotion to the Passion of Christ.",
"11-05|C|w|Zechariah and Elizabeth|Parents of John the Baptist, models of faith in old age (Luke 1).",
"11-13|C|w|Frances Xavier Cabrini|Italian-born foundress of the Missionary Sisters of the Sacred Heart who served immigrants in the Americas (1850\u20131917).",
"11-13|C|w|Stanislaus Kostka|Polish Jesuit novice (1550\u20131568) who died young; patron of students.",
"11-18|C|w|Rose Philippine Duchesne|French religious who brought education to the American frontier (1769\u20131852).",
"11-26|C|w|John Berchmans|Young Belgian Jesuit (1599\u20131621) who sought holiness in ordinary community life.",
"11-27|C|w|Our Lady of the Miraculous Medal|Commemorates the apparitions of Mary to St Catherine Labour\u00E9 in Paris in 1830.",
"11-28|C|w|Catherine Labour\u00E9|French Daughter of Charity (1806\u20131876) who received the vision of the Miraculous Medal.",
"12-04|C|r|Barbara|Early Christian martyr honoured since ancient times; traditions about her life are legendary.",
"12-14|C|w|Nimatullah Kassab|Lebanese Maronite monk and teacher (1808\u20131858) known for prayer and the formation of priests."
];

/* [key (start or distinctive part of the saint's name), "years", "patronage"] */
window.RWTW_SAINT_INFO = [
  ['Mary, Mother of God', '1st century BC\u20131st century AD', 'Patroness of all Christians'], ['Basil the Great', 'Basil c. 330\u2013379; Gregory c. 329\u2013390', 'Basil: education and hospitals; Gregory: orators'],
  ['St Kuriakose Elias Chavara', '1805\u20131871', 'Remembered as a pioneer of Catholic education in Kerala'], ['Raymond of Pe', 'c. 1175\u20131275', 'Canon lawyers'], ['Hilary of Poitiers', 'c. 310\u2013367', 'Invoked against snake bites'],
  ['St Devasahayam', '1712\u20131752', 'Honoured as the first Indian layman canonized (2022)'], ['St Joseph Vaz', '1651\u20131711', 'Apostle of Sri Lanka'], ['Anthony, Abbot', 'c. 251\u2013356', 'Monks, animals'],
  ['Fabian', 'd. 250', ''], ['Sebastian', 'd. c. 288', 'Athletes, soldiers'], ['Agnes', 'c. 291\u2013c. 304', 'Girls, chastity, engaged couples'], ['Vincent, Deacon', 'd. c. 304', 'Winemakers, Lisbon'],
  ['Francis de Sales', '1567\u20131622', 'Writers, journalists'], ['Conversion of St Paul', '1st century', 'Missionaries, converts'], ['Timothy and Titus', '1st century', ''], ['Angela Merici', '1474\u20131540', 'Educators of girls'],
  ['Thomas Aquinas', '1225\u20131274', 'Students, universities, theologians'], ['John Bosco', '1815\u20131888', 'Youth, apprentices, editors'], ['Blaise', 'd. c. 316', 'Throat ailments'], ['Ansgar', '801\u2013865', 'Scandinavia'],
  ['Agatha', 'd. c. 251', 'Nurses, breast-cancer patients, Catania'], ['Paul Miki', '1562\u20131597', 'Japan'], ['Jerome Emiliani', '1486\u20131537', 'Orphans'], ['Josephine Bakhita', 'c. 1869\u20131947', 'Survivors of slavery and trafficking'],
  ['Scholastica', 'c. 480\u2013543', 'Nuns, schoolchildren'], ['Cyril and Methodius', 'Cyril 826\u2013869; Methodius c. 815\u2013885', 'Europe, Slavic peoples'], ['Peter Damian', '1007\u20131072', ''], ['Polycarp', 'c. 69\u2013155', 'Invoked against earache'],
  ['Casimir', '1458\u20131484', 'Poland, Lithuania'], ['Perpetua', 'd. 203', 'Mothers, martyrs'], ['John of God', '1495\u20131550', 'Hospitals, nurses, the sick'], ['Frances of Rome', '1384\u20131440', 'Widows, motorists'],
  ['Patrick', 'c. 385\u2013461', 'Ireland'], ['Cyril of Jerusalem', 'c. 315\u2013386', 'Catechists'], ['Joseph, Spouse', '1st century', 'The universal Church, fathers, workers, a happy death'], ['Turibius', '1538\u20131606', 'Latin American bishops'],
  ['Francis of Paola', '1416\u20131507', 'Sailors'], ['Isidore of Seville', 'c. 560\u2013636', 'Scholars'], ['Vincent Ferrer', '1350\u20131419', 'Preachers'], ['John Baptist de la Salle', '1651\u20131719', 'Teachers'],
  ['Stanislaus, Bishop', '1030\u20131079', 'Poland'], ['Anselm', '1033\u20131109', 'Theologians'], ['George', 'd. c. 303', 'Soldiers, England, scouts'], ['Adalbert', 'c. 956\u2013997', 'Czechs, Poles'], ['Fidelis', '1577\u20131622', 'Lawyers'],
  ['St Mark', '1st century', 'Notaries, Venice'], ['Peter Chanel', '1803\u20131841', 'Oceania'], ['Louis Grignion', '1673\u20131716', 'Devotees of Mary'], ['Catherine of Siena', '1347\u20131380', 'Italy, Europe, nurses'],
  ['Pius V', '1504\u20131572', ''], ['Athanasius', 'c. 296\u2013373', 'Catechists'], ['Philip and James', '1st century', ''], ['Matthias', '1st century', 'Carpenters, alcoholics (traditional)'],
  ['Rita of Cascia', '1381\u20131457', 'Impossible causes, difficult marriages'], ['Bede', 'c. 673\u2013735', 'Historians'], ['Philip Neri', '1515\u20131595', 'Rome, joy'], ['Justin', 'c. 100\u2013165', 'Philosophers, apologists'],
  ['Charles Lwanga', 'c. 1860\u20131886', 'Uganda, youth'], ['Boniface', 'c. 675\u2013754', 'Germany'], ['Norbert', 'c. 1075\u20131134', ''], ['St Mariam Thresia', '1876\u20131926', 'Honoured as a mystic and foundress in Kerala'],
  ['Ephrem', 'c. 306\u2013373', 'Spiritual directors'], ['Barnabas', '1st century', 'Peacemakers'], ['Anthony of Padua', '1195\u20131231', 'Lost things, the poor, travellers'], ['Aloysius', '1568\u20131591', 'Youth, students'],
  ['John Fisher', 'Fisher 1469\u20131535; More 1478\u20131535', 'Thomas More: lawyers, politicians'], ['Nativity of St John the Baptist', '1st century', 'Forerunner of Christ'], ['Irenaeus', 'c. 130\u2013202', 'Lyons'], ['Saints Peter and Paul', 'd. c. 64\u201367', 'Peter: fishermen; Paul: missionaries'],
  ['St Thomas, Apostle', '1st century', 'India, architects, builders'], ['Maria Goretti', '1890\u20131902', 'Youth, purity'], ['Augustine Zhao', 'd. 1815', 'China'], ['Benedict, Abbot', 'c. 480\u2013547', 'Europe, monks, students'], ['Camillus', '1550\u20131614', 'The sick, nurses, hospitals'],
  ['Bonaventure', '1221\u20131274', ''], ['Mount Carmel', '', 'Carmelites'], ['Lawrence of Brindisi', '1559\u20131619', ''], ['St Mary Magdalene', '1st century', 'Penitents'], ['Bridget', 'c. 1303\u20131373', 'Sweden, Europe, widows'],
  ['Sharbel', '1828\u20131898', 'Lebanon'], ['St James', 'd. AD 44', 'Spain, pilgrims'], ['Joachim and Anne', '1st century BC', 'Grandparents'], ['St Alphonsa', '1910\u20131946', 'Invoked by the sick; first woman of Indian origin canonized'],
  ['Martha, Mary', '1st century', 'Hospitality, cooks'], ['Peter Chrysologus', 'c. 380\u2013450', 'Preachers'], ['Ignatius of Loyola', '1491\u20131556', 'Soldiers, retreats'], ['Alphonsus', '1696\u20131787', 'Confessors, moral theologians'],
  ['John Vianney', '1786\u20131859', 'Parish priests'], ['Dominic, Priest', 'c. 1170\u20131221', 'Astronomers, the Dominicans'], ['Transfiguration', '', ''], ['Teresa Benedicta', '1891\u20131942', 'Co-patroness of Europe'],
  ['St Lawrence', 'd. 258', 'Deacons, cooks, librarians'], ['Clare', '1194\u20131253', 'Television, eye ailments'], ['Maximilian Kolbe', '1894\u20131941', 'Prisoners, journalists, families'], ['Assumption', '', 'Patronal feast of many churches'],
  ['Stephen of Hungary', 'c. 975\u20131038', 'Hungary'], ['Bernard of Clairvaux', '1090\u20131153', 'Beekeepers'], ['Pius X', '1835\u20131914', 'First communicants'], ['Rose of Lima', '1586\u20131617', 'Peru, the Americas'],
  ['St Bartholomew', '1st century', 'Armenia'], ['Louis of France', '1214\u20131270', 'France'], ['Monica', 'c. 332\u2013387', 'Mothers, wives'], ['Augustine, Bishop', '354\u2013430', 'Theologians, printers'],
  ['Passion of St John', '1st century', ''], ['St Euphrasia', '1877\u20131952', 'Known as the \u201CPraying Mother\u201D'], ['Gregory the Great', 'c. 540\u2013604', 'Musicians, teachers'], ['St Teresa of Calcutta', '1910\u20131997', 'Missionaries of Charity, Kolkata'],
  ['Peter Claver', '1580\u20131654', 'Colombia, racial justice'], ['John Chrysostom', 'c. 347\u2013407', 'Preachers'], ['Exaltation', '', ''], ['Cornelius and Cyprian', 'Cornelius d. 253; Cyprian d. 258', ''],
  ['Robert Bellarmine', '1542\u20131621', 'Catechists'], ['Andrew Kim', 'Kim 1821\u20131846', 'Korea'], ['St Matthew', '1st century', 'Accountants, tax collectors'], ['Pio of Pietrelcina', '1887\u20131968', 'Civil-defence volunteers'],
  ['Cosmas and Damian', 'd. c. 287', 'Physicians'], ['Vincent de Paul', '1581\u20131660', 'Charitable societies'], ['Wenceslaus', 'c. 907\u2013935', 'Czech lands'], ['Michael, Gabriel', '', 'Michael: police, soldiers; Gabriel: messengers; Raphael: travellers, the sick'],
  ['Jerome, Priest', 'c. 347\u2013420', 'Translators, librarians'], ['Th\u00E9r\u00E8se', '1873\u20131897', 'Missions, florists'], ['Francis of Assisi', '1181\u20131226', 'Animals, ecology, Italy'], ['Faustina', '1905\u20131938', 'Divine Mercy devotees'],
  ['Bruno', 'c. 1030\u20131101', 'Carthusians'], ['Teresa of Jesus', '1515\u20131582', 'Spain, writers'], ['Margaret Mary', '1647\u20131690', 'Devotees of the Sacred Heart'], ['Ignatius of Antioch', 'd. c. 107', 'Church in Syria'],
  ['St Luke', '1st century', 'Physicians, artists'], ['John Paul II', '1920\u20132005', 'World Youth Day, families'], ['Simon and Jude', '1st century', 'Jude: hopeless causes'], ['Martin de Porres', '1579\u20131639', 'Social justice, barbers'],
  ['Charles Borromeo', '1538\u20131584', 'Seminarians, catechists'], ['Leo the Great', 'c. 400\u2013461', ''], ['Martin of Tours', 'c. 316\u2013397', 'Soldiers, France'], ['Josaphat', 'c. 1580\u20131623', 'Ukrainian Catholics'],
  ['Albert the Great', 'c. 1200\u20131280', 'Scientists'], ['Elizabeth of Hungary', '1207\u20131231', 'Charities, widows'], ['Cecilia', 'd. c. 230', 'Musicians'], ['Catherine of Alexandria', 'd. c. 305', 'Students, philosophers'],
  ['St Andrew', '1st century', 'Scotland, Russia, fishermen'], ['Francis Xavier', '1506\u20131552', 'Missions, India, Goa'], ['Nicholas, Bishop', '4th century', 'Children, sailors'], ['Ambrose', 'c. 340\u2013397', 'Milan, beekeepers'],
  ['Immaculate Conception', '', 'Patronal feast of the United States'], ['Juan Diego', '1474\u20131548', 'Indigenous peoples'], ['Guadalupe', '', 'Patroness of the Americas'], ['Lucy', 'd. 304', 'Eyes, the blind'],
  ['John of the Cross', '1542\u20131591', 'Mystics'], ['St Stephen', 'd. c. 36', 'Deacons, altar servers'], ['St John, Apostle', '1st century', 'Theologians, writers'], ['Thomas Becket', '1118\u20131170', ''],
  ['Dominic Savio', '1842\u20131857', 'Boys, choirboys'], ['Bernardine of Siena', '1380\u20131444', 'Public speakers, advertisers (traditional)'], ['Benedict Joseph Labre', '1748\u20131783', 'The homeless'], ['Joseph of Cupertino', '1603\u20131663', 'Students, air travellers'],
  ['Brendan', 'c. 484\u2013c. 577', 'Sailors, travellers'], ['Simon Stock', 'c. 1165\u20131265', 'Carmelites'], ['Paschal Baylon', '1540\u20131592', 'Eucharistic congresses'], ['Celestine V', '1215\u20131296', ''], ['Dismas', '1st century', 'Prisoners'],
  ['Gemma Galgani', '1878\u20131903', 'Students, pharmacists'], ['Rafqa', '1832\u20131914', 'Invoked by the sick'], ['Nimatullah', '1808\u20131858', 'Lebanon'], ['Gabriel of Our Lady', '1838\u20131862', 'Students, youth'], ['Marguerite Bourgeoys', '1620\u20131700', 'Educators'],
  ['Andr\u00E9 Bessette', '1845\u20131937', 'The sick, doorkeepers'], ['Julie Billiart', '1751\u20131816', 'Teachers'], ['Paul of the Cross', '1694\u20131775', 'Passionists'], ['Rose Philippine', '1769\u20131852', 'Educators'], ['Marianne Cope', '1838\u20131918', 'People with leprosy'],
  ['Zechariah and Elizabeth', '1st century BC', 'Parents of John the Baptist'], ['Valentine', 'd. c. 269', 'Engaged couples'], ['Gregory of Narek', 'c. 950\u20131003', 'Armenia'], ['Gregory of Nyssa', 'c. 335\u2013c. 395', ''], ['John Berchmans', '1599\u20131621', 'Altar servers'], ['Francis Borgia', '1510\u20131572', ''],
  ['Catherine Labour', '1806\u20131876', 'Devotees of the Miraculous Medal'], ['Junípero', '1713\u20131784', 'California'], ['Louis and Z', '1823\u20131894; 1831\u20131877', 'Married couples, parents']  ,['Elizabeth Ann Seton', '1774\u20131821', 'Catholic schools'], ['John Neumann', '1811\u20131860', ''], ['Gianna Beretta', '1922\u20131962', 'Mothers, physicians'], ['Joan of Arc', '1412\u20131431', 'France, soldiers'],
  ['Bernadette', '1844\u20131879', 'The sick, Lourdes'], ['Katharine Drexel', '1858\u20131955', 'Racial justice, philanthropists'], ['Damien', '1840\u20131889', 'People with leprosy, outcasts'], ['Isidore the Farmer', 'c. 1070\u20131130', 'Farmers'],
  ['Dymphna', 'traditionally 7th century', 'Mental illness, anxiety'], ['Carlo Acutis', '1991\u20132006', 'Internet users and young people'], ['Pier Giorgio', '1901\u20131925', 'Youth, mountaineers'], ['Frances Xavier Cabrini', '1850\u20131917', 'Immigrants'],
  ['John Henry Newman', '1801\u20131890', 'Converts, scholars'], ['Oscar Romero', '1917\u20131980', 'El Salvador, the poor'], ['Hildegard', '1098\u20131179', 'Scholars, musicians'], ['Pantaleon', 'd. c. 305', 'Physicians'],
  ['Apollonia', 'd. c. 249', 'Dentists'], ['Barbara', 'traditionally 3rd century', 'Miners, artillery'], ['Helena', 'c. 246\u2013c. 330', 'Archaeologists'], ['Gerard Majella', '1726\u20131755', 'Expectant mothers'],
  ['Josemar', '1902\u20131975', 'Ordinary work and holiness'], ['Paul VI', '1897\u20131978', ''], ['Zita', 'c. 1212\u20131272', 'Domestic workers'], ['Florian', 'd. 304', 'Firefighters'],
  ['Louise de Marillac', '1591\u20131660', 'Social workers'], ['Stanislaus Kostka', '1550\u20131568', 'Students'], ['Kateri', '1656\u20131680', 'Ecology, Native Americans'], ['Blessed Rani Maria', '1954\u20131995', 'Martyr for justice and service to the poor'], ['Our Lady of Health', '', 'Pilgrims and the sick']
];
(function () {
  var W = window;
  // add the extra saints, then compute details; runs before liturgy.js reads RWTW_SAINTS_RAW
  W.RWTW_SAINTS_RAW = (W.RWTW_SAINTS_RAW || []).concat(W.RWTW_SAINTS_MORE);
  var CAT = [[/Martyr|Martyrs|Passion of St John|Holy Innocents|First Martyr/i, 'Martyr'], [/Doctor/i, 'Doctor of the Church'], [/Pope/i, 'Pope'], [/Apostle|Evangelist|St Mark|St Luke|St Matthew/i, 'Apostle / Evangelist'],
    [/Archangel|Guardian Angels/i, 'Angels'], [/Our Lady|Mary,|Immaculate|Assumption|Queenship|Rosary|Visitation|Nativity of the Blessed|Mother of the Church|Presentation of the Blessed|Most Holy Name of Mary|Annunciation|Mount Carmel|Sorrows|Lourdes|Fatima|Guadalupe|Help of Christians|Miraculous Medal/i, 'Marian'],
    [/Virgin/i, 'Virgin'], [/Abbot|Monk|Abbess|Hermit/i, 'Monastic'], [/Bishop/i, 'Bishop'], [/Priest/i, 'Priest']];
  var DOCTORS = ['Basil the Great', 'Hilary of Poitiers', 'Francis de Sales', 'Thomas Aquinas', 'Peter Damian', 'Cyril of Jerusalem', 'Isidore of Seville', 'Anselm', 'Catherine of Siena', 'Athanasius', 'Bede', 'John of Avila', 'Ephrem', 'Anthony of Padua', 'Bonaventure', 'Lawrence of Brindisi', 'Alphonsus', 'Bernard of Clairvaux', 'Cyril of Alexandria', 'Peter Chrysologus', 'Gregory the Great', 'John Chrysostom', 'Robert Bellarmine', 'Jerome, Priest', 'Th\u00E9r\u00E8se', 'Teresa of Jesus', 'Ambrose', 'Augustine, Bishop', 'Leo the Great', 'John Damascene', 'Albert the Great', 'John of the Cross', 'Peter Canisius', 'Irenaeus', 'Hildegard', 'Gregory of Narek'];
  W.RWTW_SAINT_DETAILS = function (rec) {
    var info = null; for (var i = 0; i < W.RWTW_SAINT_INFO.length; i++) { if (rec.name.indexOf(W.RWTW_SAINT_INFO[i][0]) >= 0) { info = W.RWTW_SAINT_INFO[i]; break; } }
    var cats = []; if (rec.rank === 'L') cats.push('India / Kerala');
    var nm = rec.name;
    CAT.forEach(function (c) { if (nm.indexOf('Joseph, Spouse') === 0 && c[1] === 'Virgin') return; if (c[0].test(nm) && cats.indexOf(c[1]) < 0) cats.push(c[1]); });
    if (DOCTORS.some(function (d) { return nm.indexOf(d) >= 0; }) && cats.indexOf('Doctor of the Church') < 0) cats.push('Doctor of the Church');
    if (/Paul VI|Celestine V|John XXIII|John Paul II/.test(nm) && cats.indexOf('Pope') < 0) cats.push('Pope');
    if (/Blessed/i.test(rec.name)) cats.push('Blessed');
    if (!cats.length) cats.push('Saint');
    return { years: info ? info[1] : '', patron: info ? info[2] : '', cats: cats };
  };
})();
