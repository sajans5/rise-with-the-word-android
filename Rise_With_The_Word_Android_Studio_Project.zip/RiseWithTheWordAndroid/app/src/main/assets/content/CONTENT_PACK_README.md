# Rise With The Word — Editorial Content Pack

This pack contains reusable home-screen copy, a daily Gospel screen structure, ten short reflections, four prayer cards, and editorial guidelines.

`editorial-content-pack.json` is a content source/reference. It is not automatically rendered by the current app yet; the screen components must be wired to these fields before they appear in the UI.

## Visual reference
See `design-reference/rise-with-the-word-ui-visual-reference.png` for a generated concept reference for a cohesive navy/purple/gold app style. It is a design mockup, not a screenshot of the running app.

## Long-form story standard
Build each story as a substantial, original, carefully edited chapter rather than padding a summary. Use scene headings and short paragraphs, keep the biblical text distinct from the retelling, include historical context, reflection, questions, and prayer. Verify each reference before release.
