plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.risewiththeword.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.risewiththeword.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
