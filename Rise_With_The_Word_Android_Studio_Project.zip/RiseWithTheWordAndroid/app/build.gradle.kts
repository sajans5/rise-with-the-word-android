plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.risewiththeword.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.risewiththeword.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 6
        versionName = "1.5.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
