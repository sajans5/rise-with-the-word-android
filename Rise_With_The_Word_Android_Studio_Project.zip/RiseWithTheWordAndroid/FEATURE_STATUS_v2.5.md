# v2.5 — Starter content feed

Included a populated `content-feed-template` compatible with the app's ContentSync.kt manifest schema:
- 28 original Bible story introductions with Scripture references, lessons and prayers
- 20 saint/feast starter entries
- 25 quiz questions with answer indices and explanations
- 20 trivia facts
- sample reading-reference metadata, explicitly marked for verification
- manifest includes pack versions and SHA-256 hashes

Publish the feed separately using GitHub Pages, then enter the URL in Me > Settings > Content feed. The URL is not preconfigured because the user's GitHub Pages address is not known.

Limits: this is a starter pack, not a complete liturgical calendar, not a complete daily readings feed, and not the requested 3,500-word story library. Check local lectionary and saint observances before public release.
