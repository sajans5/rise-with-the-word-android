# Version 4.8 — Accessibility and Offline Image Packs

## Implemented in this upgrade bundle
- Adds an Image Packs screen reachable from Discover and Me.
- Browses currently bundled feature art, portrait wallpapers and style-reference images with category filters.
- Uses local image paths only; image browsing does not require network access.
- Adds descriptive alt text, lazy-loaded thumbnails and responsive two/three-column layouts.
- Adds a structured `image-packs.json` catalog with category, source/licence notes, dimensions and alt text.
- Improves keyboard focus visibility, touch target sizing, checkbox/radio sizing, high-contrast styling hooks, and reduced-motion behavior.
- Retains the existing Easy Mode, font-size, bold-text, spacing and read-aloud settings.

## Planned pack categories
Bible stories; Jesus’ parables and miracles; Old Testament; New Testament; saints and feast days; prayer and Rosary; liturgical seasons; phone wallpapers; app feature artwork; kids’ learning; Scripture-card backgrounds.

## Asset rights
The catalog flags the two legacy `images/refs/` assets as unknown-license and review-required. Do not redistribute those files externally until their provenance and licence are confirmed. New packs must include creator/source, licence, dimensions, checksum and meaningful alt text. Avoid putting Bible verse text inside raster images so it stays selectable and accessible.

## Validation status
- JSON catalog parse: validated when packaged.
- JavaScript syntax: validated when packaged.
- ZIP integrity: validated when packaged.
- Android Gradle build, TalkBack testing, Malayalam screen-reader verification and real-device font-scale checks: still required before release.

## GitHub status
This is a locally prepared upgrade bundle. The connected GitHub integration returned HTTP 403 for write operations, so these changes have **not** been committed to the live repository by this action.
