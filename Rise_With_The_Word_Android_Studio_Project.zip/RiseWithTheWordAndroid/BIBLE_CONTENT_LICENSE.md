# Bible content note

The full offline Bible generated for this app uses the Original Douay–Rheims text, an historic public-domain Catholic translation. The source repository releases its structured text/data under CC0 1.0 Universal: https://github.com/janvier-s/original-douay-rheims

Build commit pinned for reproducibility: `cd4439a1b5bbf2abe253d68b0896c3c60e8f27bc`. The app includes the 73 books of the Catholic canon and omits three books printed in the source's appendix (3 Esdras, 4 Esdras, Prayer of Manasses). Some modern book names are shown alongside the source names, and Douay–Rheims Psalm/chapter numbering can differ from modern editions.
