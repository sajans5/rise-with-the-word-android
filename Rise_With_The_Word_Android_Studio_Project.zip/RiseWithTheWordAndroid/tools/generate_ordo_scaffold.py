#!/usr/bin/env python3
"""Create a date-complete but explicitly unverified India Roman Rite reading-reference scaffold.
This generates no liturgical claims and copies no Ordo text.
"""
import argparse, json
from datetime import date, timedelta
from pathlib import Path

DEFAULT_START = date(2026, 11, 29)
DEFAULT_END = date(2027, 11, 27)
FIELDS = ("celebration", "season", "colour", "rank", "cycle", "first", "psalm", "second", "gospelAcclamation", "gospel")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default=DEFAULT_START.isoformat())
    ap.add_argument("--end", default=DEFAULT_END.isoformat())
    ap.add_argument("--output", type=Path, default=Path("content-feed-template/readings-india-2026-2027.json"))
    args = ap.parse_args()
    start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
    if end < start:
        ap.error("end date must not precede start date")
    dates = {}
    day = start
    while day <= end:
        dates[day.isoformat()] = {
            "celebration": "", "season": "", "colour": "", "rank": "", "cycle": "",
            "first": "", "psalm": "", "second": "", "gospelAcclamation": "", "gospel": "",
            "alternatives": [], "massOptions": [], "verified": False,
            "status": "awaiting_ordo_review", "sourceName": "", "sourceUrl": "", "sourceNote": "",
            "notes": "Blank scaffold only. Do not display as verified liturgical data."
        }
        day += timedelta(days=1)
    pack = {
        "schemaVersion": 2,
        "region": "India",
        "rite": "Roman Rite (Latin Church)",
        "liturgicalYear": "2026-2027",
        "coverageStart": start.isoformat(),
        "coverageEnd": end.isoformat(),
        "sourceName": "CCBI Commission for Liturgy — Liturgical Calendar (ORDO) 2026-2027",
        "sourceUrl": "https://www.ccbi.in/post/liturgical-calendar-ordo-for-the-year-2026-2027",
        "sourceNote": "Scaffold only. Verify every date against the official Ordo and record page/section before marking verified.",
        "licence": "Do not redistribute copied Ordo pages or lectionary text without confirming applicable rights. Scripture references only may still require source verification.",
        "dataStatus": "scaffold_only_no_readings_verified",
        "dates": dates
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(pack, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    verified = sum(1 for r in dates.values() if r["verified"] is True)
    print(f"Wrote {len(dates)} date records to {args.output}")
    print(f"Verified records: {verified}; pending review: {len(dates)-verified}")
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
