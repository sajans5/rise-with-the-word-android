#!/usr/bin/env python3
"""Audit lectionary reference completeness and source metadata without reproducing Bible text."""
import argparse, json, sys
from datetime import date, timedelta
from pathlib import Path
FIELDS=('first','psalm','second','gospelAcclamation','gospel')
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('pack',type=Path)
    ap.add_argument('--start',required=True); ap.add_argument('--end',required=True)
    args=ap.parse_args()
    try:
        start,end=date.fromisoformat(args.start),date.fromisoformat(args.end)
        data=json.loads(args.pack.read_text(encoding='utf-8'))
    except Exception as e: print('ERROR:',e); return 2
    dates=data.get('dates',{}) if isinstance(data,dict) else {}
    expected=[]; d=start
    while d<=end: expected.append(d.isoformat()); d+=timedelta(days=1)
    missing_dates=[k for k in expected if k not in dates]
    present=[k for k in expected if k in dates]
    gospel=sum(bool(dates[k].get('gospel')) for k in present if isinstance(dates[k],dict))
    all_fields=sum(all(bool(dates[k].get(f)) for f in FIELDS) for k in present if isinstance(dates[k],dict))
    verified=sum(dates[k].get('verified') is True and bool(dates[k].get('sourceName')) and bool(dates[k].get('sourceUrl')) and bool(dates[k].get('sourceNote')) for k in present if isinstance(dates[k],dict))
    print(f'Window: {start} to {end} ({len(expected)} dates)')
    print(f'Date rows: {len(present)}/{len(expected)}; missing date rows: {len(missing_dates)}')
    print(f'Rows with Gospel reference: {gospel}/{len(expected)}')
    print(f'Rows with all five reading fields: {all_fields}/{len(expected)}')
    print(f'Rows marked verified with source metadata: {verified}/{len(expected)}')
    if missing_dates: print('Missing dates:', ', '.join(missing_dates[:40]))
    print('Note: this checks data coverage and metadata only. It cannot determine whether a reference is the correct Indian lectionary for a date, nor whether a Bible translation is licensed for redistribution.')
    return 0
if __name__=='__main__': sys.exit(main())
