#!/usr/bin/env node
/* Load the exact in-app saint registry and report data-quality gaps. It deliberately does not
   change feast dates automatically; those must be checked against the approved India Ordo. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.resolve(__dirname, '..');
const assets = path.join(root, 'app', 'src', 'main', 'assets', 'js');
const window = {};
const ctx = { window, console };
vm.createContext(ctx);
for (const f of ['saints.js', 'saints2.js', 'saints3.js', 'saints4.js', 'liturgy.js']) {
  vm.runInContext(fs.readFileSync(path.join(assets, f), 'utf8'), ctx, { filename: f });
}
const saints = window.Liturgy.allSaints();
const validRanks = new Set(['S','F','M','O','L','C','T','U','D']);
const validColors = new Set(['w','r','g','v','p']);
const issues = [];
const seen = new Map();
const dateSet = new Set();
for (const s of saints) {
  const md = String(s.md || '');
  const match = md.match(/^(\d{2})-(\d{2})$/);
  let validDate = false;
  if (match) {
    const month = +match[1], day = +match[2];
    const days = [31,29,31,30,31,30,31,31,30,31,30,31];
    validDate = month >= 1 && month <= 12 && day >= 1 && day <= days[month-1];
  }
  if (!validDate) issues.push({type:'invalid_date', name:s.name || '', md});
  else dateSet.add(md);
  if (!String(s.name || '').trim()) issues.push({type:'missing_name', md});
  if (!String(s.bio || '').trim()) issues.push({type:'missing_biography', md, name:s.name || ''});
  if (s.rank && !validRanks.has(s.rank)) issues.push({type:'unknown_rank', md, name:s.name || '', rank:s.rank});
  if (s.color && !validColors.has(s.color)) issues.push({type:'unknown_colour', md, name:s.name || '', color:s.color});
  const key = md + '|' + String(s.name || '').trim().toLowerCase();
  seen.set(key, (seen.get(key)||0)+1);
}
for (const [key,count] of seen) if (count > 1) {
  const [md,name] = key.split('|'); issues.push({type:'duplicate_name_date',md,name,count});
}
const yearStart = new Date(2026,10,29,12), yearEnd = new Date(2027,10,27,12);
const dates=[]; let emptyDates=0;
for (let d=new Date(yearStart); d<=yearEnd; d.setDate(d.getDate()+1)) {
  const md=String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  const recs=window.Liturgy.saintsOn(d.getMonth()+1,d.getDate());
  if (!recs.length) emptyDates++;
  dates.push({date:d.getFullYear()+'-'+md, saintCount:recs.length, saints:recs.map(x=>x.name)});
}
const report={schemaVersion:2,recordsInAppRegistry:saints.length,uniqueFeastDates:dateSet.size,issueCount:issues.length,issues,
  liturgicalYear:{start:'2026-11-29',end:'2027-11-27',dateCount:dates.length,datesWithNoFixedSaintRecord:emptyDates},
  dates,
  note:'This is a structural audit of the app registry. Dates with no fixed saint record are not automatically errors: weekdays may be ferias and the Roman Martyrology is broader than the Mass calendar. Rank, precedence, local observance, and transferred feasts still require comparison with the approved India/diocesan Ordo.'};
const out=path.join(root,'content-feed-template','saints-audit-report.json');
fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({recordsInAppRegistry:saints.length,uniqueFeastDates:dateSet.size,issueCount:issues.length,datesWithNoFixedSaintRecord:emptyDates,report:out},null,2));
