#!/usr/bin/env python3
"""Build an offline SQLite Bible DB from a separately licensed normalized JSON file.

This tool intentionally does not read POC Bible APK/XAPK/MSI files or encrypted app databases.
Input format is documented in docs/LAWFUL_OFFLINE_BIBLE_PLAN.md. The source must carry
an explicit licence record before import; this script validates metadata, not legal rights.
"""
import argparse, json, sqlite3, sys
from pathlib import Path

REQUIRED_LICENSE_FIELDS = ('name', 'source', 'rights_holder', 'redistribution', 'attribution')

def fail(message):
    raise SystemExit('ERROR: ' + message)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('input_json', help='normalized Bible JSON with licence metadata')
    ap.add_argument('output_db', help='output SQLite database path')
    args = ap.parse_args()
    src = Path(args.input_json)
    if not src.is_file(): fail(f'input not found: {src}')
    data = json.loads(src.read_text(encoding='utf-8'))
    if not isinstance(data, dict): fail('root must be a JSON object')
    lic = data.get('licenseInfo')
    if not isinstance(lic, dict): fail('licenseInfo object is required; no database written')
    missing = [k for k in REQUIRED_LICENSE_FIELDS if not str(lic.get(k, '')).strip()]
    if missing: fail('missing licenseInfo fields: ' + ', '.join(missing))
    if lic.get('redistribution') not in ('public-domain', 'cc0', 'cc-by', 'cc-by-sa', 'cc-by-nd', 'cc-by-nc', 'gplv3-data', 'permissive-license', 'explicit-permission'):
        fail('redistribution must name a supported licence class; check the exact licence terms separately')
    if lic.get('redistribution') in ('cc-by-nd', 'cc-by-nc'):
        fail('this importer packages and may transform content; no-derivatives and non-commercial licences need a separate manual review and are not accepted automatically')
    if data.get('canon') == 'catholic-73' and len(data.get('books', [])) != 73:
        fail('canon is catholic-73 but dataset does not contain exactly 73 book records')
    books = data.get('books')
    if not isinstance(books, list) or not books: fail('books must be a non-empty list')
    seen_books, total_chapters, total_verses = set(), 0, 0
    for book in books:
        if not all(str(book.get(k, '')).strip() for k in ('id','title')): fail('each book needs id and title')
        if book['id'] in seen_books: fail('duplicate book id: ' + book['id'])
        seen_books.add(book['id'])
        for chapter in book.get('chapters', []):
            if not isinstance(chapter.get('number'), int): fail(f"invalid chapter number in {book['id']}")
            total_chapters += 1
            for verse in chapter.get('verses', []):
                if not isinstance(verse.get('number'), int) or not isinstance(verse.get('text'), str) or not verse['text'].strip():
                    fail(f"invalid verse in {book['id']} chapter {chapter['number']}")
                total_verses += 1
    out = Path(args.output_db); out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists(): out.unlink()
    con = sqlite3.connect(str(out))
    try:
        con.executescript('''
        PRAGMA foreign_keys=ON;
        CREATE TABLE translation (id TEXT PRIMARY KEY, name TEXT NOT NULL, language TEXT NOT NULL, canon TEXT NOT NULL, source TEXT NOT NULL, rights_holder TEXT NOT NULL, licence TEXT NOT NULL, redistribution TEXT NOT NULL, attribution TEXT NOT NULL);
        CREATE TABLE book (id TEXT PRIMARY KEY, translation_id TEXT NOT NULL REFERENCES translation(id), ordinal INTEGER NOT NULL, title TEXT NOT NULL, UNIQUE(translation_id, ordinal));
        CREATE TABLE chapter (id INTEGER PRIMARY KEY, book_id TEXT NOT NULL REFERENCES book(id), number INTEGER NOT NULL, UNIQUE(book_id, number));
        CREATE TABLE verse (chapter_id INTEGER NOT NULL REFERENCES chapter(id), number INTEGER NOT NULL, text TEXT NOT NULL, PRIMARY KEY(chapter_id, number));
        CREATE INDEX verse_text_search ON verse(text);
        ''')
        con.execute('INSERT INTO translation VALUES (?,?,?,?,?,?,?,?,?)', (
            data.get('translationId','unknown'), data.get('displayName','Unnamed translation'), data.get('language','und'), data.get('canon','unspecified'),
            lic['source'], lic['rights_holder'], lic['name'], lic['redistribution'], lic['attribution']))
        for bi, book in enumerate(books, 1):
            con.execute('INSERT INTO book VALUES (?,?,?,?)', (book['id'], data.get('translationId','unknown'), bi, book['title']))
            for ch in book.get('chapters', []):
                cur = con.execute('INSERT INTO chapter(book_id,number) VALUES (?,?)', (book['id'], ch['number']))
                cid = cur.lastrowid
                con.executemany('INSERT INTO verse VALUES (?,?,?)', [(cid,v['number'],v['text']) for v in ch.get('verses',[])])
        con.commit()
    finally: con.close()
    print(json.dumps({'output':str(out),'books':len(books),'chapters':total_chapters,'verses':total_verses,'licenceMetadataPresent':True},ensure_ascii=False))

if __name__ == '__main__': main()
