#!/usr/bin/env python3
"""Read-only integrity audit for Rise With The Word's bundled offline content.
Does not claim theological, copyright, or lectionary correctness; it checks structure and linkage.
"""
import json, re, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
errors=[]; warnings=[]; metrics={}
def load(path):
    try: return json.loads(path.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'JSON invalid: {path.relative_to(ROOT)}: {e}'); return None
# all JSON files
for p in ROOT.rglob('*.json'):
    if 'build' not in p.parts: load(p)
# required visual assets
imgs=sorted((ASSETS/'images/feature').glob('*')) if (ASSETS/'images/feature').exists() else []
metrics['feature_image_assets']=len([p for p in imgs if p.suffix.lower() in ('.jpg','.jpeg','.png','.webp')])
if metrics['feature_image_assets'] < 6: warnings.append('Fewer than six feature image assets found.')
# Catechism guide counts
cat=load(ASSETS/'catechism-guides.json')
if isinstance(cat,dict):
    metrics['catechism_classes']=len(cat.get('grades',[]))
    cat_js=(ASSETS/'js/catechism.js').read_text(encoding='utf-8') if (ASSETS/'js/catechism.js').exists() else ''
    metrics['catechism_topics_in_app_js']=len(re.findall(r'\{\"id\":\"topic-[^\"]+\"', cat_js))
    if metrics['catechism_classes'] != 12: warnings.append(f"Expected 12 class guides, found {metrics['catechism_classes']}.")
# saint database / liturgical date scaffold
for label,path in [('saints','content-feed-template/saints.json'),('calendar','content-feed-template/calendar.json'),('liturgical_readings','content-feed-template/readings-india-2026-2027.json')]:
    obj=load(ROOT/path)
    if isinstance(obj,list): metrics[label+'_records']=len(obj)
    elif isinstance(obj,dict):
        arr=next((obj[k] for k in ('items','saints','days','readings','calendar','records') if isinstance(obj.get(k),list)),None)
        if arr is not None:
            metrics[label+'_records']=len(arr)
        elif isinstance(obj.get('dates'),dict):
            metrics[label+'_records']=len(obj['dates'])
        elif isinstance(obj.get('items'),dict):
            metrics[label+'_records']=len(obj['items'])
        else:
            metrics[label+'_records']=None
            warnings.append(f'{label}: no obvious record collection; inspect schema manually.')
    else: metrics[label+'_records']=None
# reading references: count date records and fields, don't assert source correctness
rd=load(ROOT/'content-feed-template/readings-india-2026-2027.json')
if isinstance(rd,dict):
    arr=next((rd[k] for k in ('items','days','readings','records') if isinstance(rd.get(k),list)),[])
    if not arr and isinstance(rd.get('dates'),dict): arr=list(rd['dates'].values())
    if not arr and isinstance(rd.get('items'),dict): arr=list(rd['items'].values())
elif isinstance(rd,list): arr=rd
else: arr=[]
metrics['reading_date_records']=len(arr)
fields=('firstReading','responsorialPsalm','secondReading','gospelAcclamation','gospel')
metrics['records_with_any_reading_reference']=sum(any(bool(x.get(k)) for k in fields) for x in arr if isinstance(x,dict))
metrics['records_with_source_metadata']=sum(bool(x.get('source') or x.get('sourceUrl') or x.get('verificationSource')) for x in arr if isinstance(x,dict))
# detect all local JS src references in index
index=(ASSETS/'index.html').read_text(encoding='utf-8')
missing=[]
for src in re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index):
    if src.startswith(('http:','https:','//')): continue
    if not (ASSETS/src).exists(): missing.append(src)
metrics['missing_local_script_refs']=len(missing)
if missing: errors.append('Missing local script references: '+', '.join(missing))
# Check images named by gallery code
js=(ASSETS/'js/screens-discover.js').read_text(encoding='utf-8') if (ASSETS/'js/screens-discover.js').exists() else ''
for name in re.findall(r"['\"]([a-zA-Z0-9_-]+\.(?:jpg|jpeg|png|webp))['\"]", js):
    if 'images/feature/'+name in js and not (ASSETS/'images/feature'/name).exists(): errors.append('Gallery image missing: '+name)
report={'audit':'offline-content-structure','version':'4.6.0','scope':'Structural integrity only; not a verification of doctrinal accuracy, licensing, lectionary correctness, or translation quality.','metrics':metrics,'warnings':warnings,'errors':errors,'status':'PASS' if not errors else 'FAIL'}
path=ROOT/'content-feed-template/offline-content-audit.json'; path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
