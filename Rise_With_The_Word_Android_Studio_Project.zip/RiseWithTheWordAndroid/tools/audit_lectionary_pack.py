#!/usr/bin/env python3
"""Audit a date-keyed Catholic Mass-reading reference pack (JSON).
Validates structure/date coverage only; it does not authenticate liturgical correctness or licences.
"""
import argparse, json, re, sys
from datetime import date, timedelta
from pathlib import Path
FIELDS = ("first", "psalm", "second", "gospelAcclamation", "gospel")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
def main():
    p = argparse.ArgumentParser()
    p.add_argument("pack", type=Path)
    p.add_argument("--start", required=True, help="YYYY-MM-DD")
    p.add_argument("--end", required=True, help="YYYY-MM-DD")
    args = p.parse_args()
    try:
        start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
        obj = json.loads(args.pack.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"ERROR: cannot read pack/date: {e}"); return 2
    errors, warnings = [], []
    if end < start: errors.append("end date is before start date")
    if not isinstance(obj, dict): errors.append("top level must be an object"); obj = {}
    for field in ("region", "rite", "sourceName", "sourceUrl", "licence", "dates"):
        if field not in obj: errors.append(f"missing top-level field: {field}")
    dates = obj.get("dates", {})
    if not isinstance(dates, dict): errors.append("dates must be an object keyed by YYYY-MM-DD"); dates = {}
    for key, rec in dates.items():
        if not DATE_RE.match(key): errors.append(f"invalid date key: {key}"); continue
        try: date.fromisoformat(key)
        except ValueError: errors.append(f"impossible date: {key}"); continue
        if not isinstance(rec, dict): errors.append(f"{key}: record must be an object"); continue
        if rec.get("verified") is True:
            if not (rec.get("sourceName") or obj.get("sourceName")): errors.append(f"{key}: verified=true requires sourceName")
            if not (rec.get("sourceUrl") or obj.get("sourceUrl")): errors.append(f"{key}: verified=true requires sourceUrl")
            if not (rec.get("sourceNote") or obj.get("sourceNote")): warnings.append(f"{key}: add a page/section sourceNote for traceability")
        else: warnings.append(f"{key}: not marked verified")
        if not rec.get("gospel"): warnings.append(f"{key}: Gospel reference missing")
        if not (start <= date.fromisoformat(key) <= end): warnings.append(f"{key}: outside requested audit window")
        for fld in FIELDS:
            if fld in rec and rec[fld] is not None and not isinstance(rec[fld], str): errors.append(f"{key}: {fld} must be a string when present")
    expected, present = 0, 0
    d = start
    while d <= end:
        expected += 1
        if d.isoformat() in dates: present += 1
        d += timedelta(days=1)
    print(f"Audit window: {start} through {end} ({expected} dates)")
    print(f"Date records present: {present}/{expected}; missing: {expected-present}")
    print(f"Errors: {len(errors)}; warnings: {len(warnings)}")
    for x in errors: print("ERROR:", x)
    for x in warnings[:100]: print("WARN:", x)
    if len(warnings) > 100: print(f"... {len(warnings)-100} more warnings")
    print("NOTE: structure and coverage only; human review is still required for liturgical accuracy and licence permissions.")
    return 1 if errors else 0
if __name__ == "__main__": sys.exit(main())
