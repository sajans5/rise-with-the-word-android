#!/usr/bin/env python3
"""Convert the CC0 Original Douay-Rheims raw JSON files into a compact offline JS asset."""
import json
import sys
from pathlib import Path

EXTRA_APPENDIX_BOOKS = {"prayer-of-manasses", "3-esdras", "4-esdras"}
DISPLAY_NAMES = {
    "1-kings": "1 Kings (1 Samuel)", "2-kings": "2 Kings (2 Samuel)",
    "3-kings": "3 Kings (1 Kings)", "4-kings": "4 Kings (2 Kings)",
    "1-paralipomenon": "1 Paralipomenon (1 Chronicles)",
    "2-paralipomenon": "2 Paralipomenon (2 Chronicles)",
    "1-esdras": "1 Esdras (Ezra)", "2-esdras": "2 Esdras (Nehemiah)",
    "tobias": "Tobias (Tobit)", "1-machabees": "1 Machabees (1 Maccabees)",
    "2-machabees": "2 Machabees (2 Maccabees)",
    "canticle-of-canticles": "Canticle of Canticles (Song of Songs)",
    "isaie": "Isaiah", "jeremie": "Jeremiah", "ezechiel": "Ezekiel",
    "osee": "Hosea", "abdias": "Obadiah", "jonas": "Jonah",
    "micheas": "Micah", "habacuc": "Habakkuk", "sophonias": "Zephaniah",
    "aggeus": "Haggai", "zacharias": "Zechariah", "malachie": "Malachi",
    "apocalypse": "Apocalypse (Revelation)",
}

def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("Usage: build_bible.py DATASET_ROOT OUTPUT_JS")
    dataset = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    manifest_path = dataset / "manifest.json"
    raw_dir = dataset / "bible" / "raw"
    if not manifest_path.is_file() or not raw_dir.is_dir():
        raise SystemExit(f"Could not find manifest.json and bible/raw under {dataset}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    books = []
    for meta in sorted(manifest.get("books", []), key=lambda item: item.get("ordinal", 999)):
        slug = meta.get("slug", "")
        if slug in EXTRA_APPENDIX_BOOKS:
            continue
        path = raw_dir / f"{slug}.json"
        if not path.is_file():
            raise SystemExit(f"Missing expected book file: {path}")
        source = json.loads(path.read_text(encoding="utf-8"))
        chapters = []
        for ch in source.get("chapters", []):
            verses = []
            for verse in ch.get("verses", []):
                text = " ".join(str(verse.get("text", "")).split())
                if text:
                    verses.append({"n": int(verse["verse"]), "t": text})
            chapters.append({"n": int(ch["chapter"]), "verses": verses})
        title = DISPLAY_NAMES.get(slug, source.get("short_title") or source.get("book_title") or slug.replace("-", " ").title())
        books.append({"slug": slug, "title": title, "chapters": chapters})
    if len(books) != 73:
        raise SystemExit(f"Expected the 73-book Catholic canon, built {len(books)} books")
    verse_count = sum(len(c["verses"]) for b in books for c in b["chapters"])
    payload = {
        "edition": "Original Douay-Rheims (1582 New Testament / 1609–1610 Old Testament)",
        "license": "CC0 1.0 Universal",
        "source": "https://github.com/janvier-s/original-douay-rheims",
        "source_commit": manifest.get("commit", ""),
        "books": books,
        "book_count": len(books),
        "verse_count": verse_count,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    script_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    output.write_text("window.RWTW_FULL_BIBLE = " + script_json + ";\n", encoding="utf-8")
    print(f"Bundled {len(books)} books and {verse_count} verses to {output} ({output.stat().st_size:,} bytes)")

if __name__ == "__main__":
    main()
