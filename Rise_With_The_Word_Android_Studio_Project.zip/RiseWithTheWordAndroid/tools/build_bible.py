#!/usr/bin/env python3
"""Convert the CC0 Original Douay-Rheims raw JSON files into a compact offline JS asset."""
import json
import sys
from pathlib import Path

EXTRA_APPENDIX_BOOKS = {"prayer-of-manasses", "3-esdras", "4-esdras"}
DISPLAY_NAMES = {
    "1-kings": "1 Kings (1 Samuel)", "2-kings": "2 Kings (2 Samuel)",
    "3-kings": "3 Kings (1 Kings)", "4-kings": "4 Kings (2 Kings)",
    "1-paralipomenon": "1 Paralipomenon (1 Chronicles)",
    "2-paralipomenon": "2 Paralipomenon (2 Chronicles)",
    "1-esdras": "1 Esdras (Ezra)", "2-esdras": "2 Esdras (Nehemiah)",
    "tobias": "Tobias (Tobit)", "1-machabees": "1 Machabees (1 Maccabees)",
    "2-machabees": "2 Machabees (2 Maccabees)",
    "canticle-of-canticles": "Canticle of Canticles (Song of Songs)",
    "isaie": "Isaiah", "jeremie": "Jeremiah", "ezechiel": "Ezekiel",
    "osee": "Hosea", "abdias": "Obadiah", "jonas": "Jonah",
    "micheas": "Micah", "habacuc": "Habakkuk", "sophonias": "Zephaniah",
    "aggeus": "Haggai", "zacharias": "Zechariah", "malachie": "Malachi",
    "apocalypse": "Apocalypse (Revelation)",
}

# Canonical order of the 73 Catholic books and the short code the app uses for each.
CANON = ["gn","ex","lv","nm","dt","jos","jgs","ru","1sm","2sm","1kgs","2kgs","1chr","2chr","ezr","neh","tb","jdt","est","jb","ps","prv","eccl","song","wis","sir","is","jer","lam","bar","ez","dn","hos","jl","am","ob","jon","mi","na","hb","zep","hg","zec","mal","1mc","2mc","mt","mk","lk","jn","acts","rom","1cor","2cor","gal","eph","phil","col","1thes","2thes","1tm","2tm","ti","phlm","heb","jas","1pt","2pt","1jn","2jn","3jn","jude","rv"]
SLUG_CODES = {
    "genesis":"gn","exodus":"ex","leviticus":"lv","numbers":"nm","deuteronomy":"dt","josue":"jos","joshua":"jos","judges":"jgs","ruth":"ru",
    "1-kings":"1sm","2-kings":"2sm","3-kings":"1kgs","4-kings":"2kgs","1-paralipomenon":"1chr","2-paralipomenon":"2chr","1-esdras":"ezr","2-esdras":"neh",
    "tobias":"tb","tobit":"tb","judith":"jdt","esther":"est","job":"jb","psalms":"ps","proverbs":"prv","ecclesiastes":"eccl","canticle-of-canticles":"song",
    "wisdom":"wis","ecclesiasticus":"sir","sirach":"sir","isaie":"is","isaias":"is","isaiah":"is","jeremie":"jer","jeremias":"jer","jeremiah":"jer","lamentations":"lam","baruch":"bar",
    "ezechiel":"ez","ezekiel":"ez","daniel":"dn","osee":"hos","hosea":"hos","joel":"jl","amos":"am","abdias":"ob","obadiah":"ob","jonas":"jon","jonah":"jon","micheas":"mi","micah":"mi",
    "nahum":"na","habacuc":"hb","habakkuk":"hb","sophonias":"zep","zephaniah":"zep","aggeus":"hg","haggai":"hg","zacharias":"zec","zechariah":"zec","malachie":"mal","malachias":"mal","malachi":"mal",
    "1-machabees":"1mc","2-machabees":"2mc","1-maccabees":"1mc","2-maccabees":"2mc","matthew":"mt","mark":"mk","luke":"lk","john":"jn","acts":"acts","romans":"rom",
    "1-corinthians":"1cor","2-corinthians":"2cor","galatians":"gal","ephesians":"eph","philippians":"phil","colossians":"col","1-thessalonians":"1thes","2-thessalonians":"2thes",
    "1-timothy":"1tm","2-timothy":"2tm","titus":"ti","philemon":"phlm","hebrews":"heb","james":"jas","1-peter":"1pt","2-peter":"2pt","1-john":"1jn","2-john":"2jn","3-john":"3jn","jude":"jude",
    "apocalypse":"rv","revelation":"rv",
}

def assign_codes(books):
    """Give every book a stable code. Use the slug table; fall back to canonical position."""
    codes = [SLUG_CODES.get(b["slug"]) for b in books]
    if None in codes or len(set(codes)) != len(codes):
        unknown = [b["slug"] for b, c in zip(books, codes) if c is None]
        print("NOTE: using canonical book order for codes. Unknown slugs: %s" % unknown)
        codes = CANON[:len(books)]
    for b, c in zip(books, codes):
        b["code"] = c
    # sanity: canonical order check (warn only)
    if [b["code"] for b in books] != CANON:
        print("WARNING: book order differs from the standard Catholic order; the Bible tab will list books in source order.")

def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("Usage: build_bible.py DATASET_ROOT OUTPUT_JS")
    dataset = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    manifest_path = dataset / "manifest.json"
    raw_dir = dataset / "bible" / "raw"
    if not manifest_path.is_file() or not raw_dir.is_dir():
        raise SystemExit(f"Could not find manifest.json and bible/raw under {dataset}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    books = []
    for meta in sorted(manifest.get("books", []), key=lambda item: item.get("ordinal", 999)):
        slug = meta.get("slug", "")
        if slug in EXTRA_APPENDIX_BOOKS:
            continue
        path = raw_dir / f"{slug}.json"
        if not path.is_file():
            raise SystemExit(f"Missing expected book file: {path}")
        source = json.loads(path.read_text(encoding="utf-8"))
        chapters = []
        for ch in source.get("chapters", []):
            verses = []
            for verse in ch.get("verses", []):
                text = " ".join(str(verse.get("text", "")).split())
                if text:
                    verses.append({"n": int(verse["verse"]), "t": text})
            chapters.append({"n": int(ch["chapter"]), "verses": verses})
        title = DISPLAY_NAMES.get(slug, source.get("short_title") or source.get("book_title") or slug.replace("-", " ").title())
        books.append({"slug": slug, "title": title, "chapters": chapters})
    assign_codes(books)
    if len(books) != 73:
        raise SystemExit(f"Expected the 73-book Catholic canon, built {len(books)} books")
    verse_count = sum(len(c["verses"]) for b in books for c in b["chapters"])
    payload = {
        "edition": "Original Douay-Rheims (1582 New Testament / 1609–1610 Old Testament)",
        "license": "CC0 1.0 Universal",
        "source": "https://github.com/janvier-s/original-douay-rheims",
        "source_commit": manifest.get("commit", ""),
        "books": books,
        "book_count": len(books),
        "verse_count": verse_count,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    script_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    output.write_text("window.RWTW_FULL_BIBLE = " + script_json + ";\n", encoding="utf-8")
    print(f"Bundled {len(books)} books and {verse_count} verses to {output} ({output.stat().st_size:,} bytes)")

if __name__ == "__main__":
    main()
