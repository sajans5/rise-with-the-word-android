#!/usr/bin/env python3
"""Audit a normalized Bible JSON for Catholic-canon coverage without importing text."""
import argparse, json
from pathlib import Path

CANON = [
('GEN','Genesis'),('EXOD','Exodus'),('LEV','Leviticus'),('NUM','Numbers'),('DEUT','Deuteronomy'),('JOSH','Joshua'),('JUDG','Judges'),('RUTH','Ruth'),('1SAM','1 Samuel'),('2SAM','2 Samuel'),('1KGS','1 Kings'),('2KGS','2 Kings'),('1CHR','1 Chronicles'),('2CHR','2 Chronicles'),('EZRA','Ezra'),('NEH','Nehemiah'),('TOB','Tobit'),('JDT','Judith'),('ESTH','Esther'),('JOB','Job'),('PS','Psalms'),('PROV','Proverbs'),('ECCL','Ecclesiastes'),('SONG','Song of Songs'),('WIS','Wisdom'),('SIR','Sirach'),('ISA','Isaiah'),('JER','Jeremiah'),('LAM','Lamentations'),('BAR','Baruch'),('EZEK','Ezekiel'),('DAN','Daniel'),('HOSEA','Hosea'),('JOEL','Joel'),('AMOS','Amos'),('OBAD','Obadiah'),('JONAH','Jonah'),('MIC','Micah'),('NAH','Nahum'),('HAB','Habakkuk'),('ZEPH','Zephaniah'),('HAG','Haggai'),('ZECH','Zechariah'),('MAL','Malachi'),('1MAC','1 Maccabees'),('2MAC','2 Maccabees'),('MATT','Matthew'),('MARK','Mark'),('LUKE','Luke'),('JOHN','John'),('ACTS','Acts'),('ROM','Romans'),('1COR','1 Corinthians'),('2COR','2 Corinthians'),('GAL','Galatians'),('EPH','Ephesians'),('PHIL','Philippians'),('COL','Colossians'),('1THESS','1 Thessalonians'),('2THESS','2 Thessalonians'),('1TIM','1 Timothy'),('2TIM','2 Timothy'),('TITUS','Titus'),('PHLM','Philemon'),('HEB','Hebrews'),('JAS','James'),('1PET','1 Peter'),('2PET','2 Peter'),('1JOHN','1 John'),('2JOHN','2 John'),('3JOHN','3 John'),('JUDE','Jude'),('REV','Revelation')]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('input_json'); ap.add_argument('--output', help='optional Markdown report path'); args=ap.parse_args()
    d=json.loads(Path(args.input_json).read_text(encoding='utf-8'))
    books=d.get('books')
    if not isinstance(books,list): raise SystemExit('Expected normalized JSON with a books array.')
    ids={str(b.get('id','')).upper():b for b in books}
    titles={str(b.get('title','')).strip().casefold():b for b in books}
    aliases={'GEN':'GENESIS','EXOD':'EXODUS','LEV':'LEVITICUS','NUM':'NUMBERS','DEUT':'DEUTERONOMY','JOSH':'JOSHUA','JUDG':'JUDGES','PS':'PSALMS','PROV':'PROVERBS','ECCL':'ECCLESIASTES','SONG':'SONG OF SONGS','SIR':'SIRACH','ISA':'ISAIAH','LAM':'LAMENTATIONS','EZEK':'EZEKIEL','MIC':'MICAH','NAH':'NAHUM','ZEPH':'ZEPHANIAH','HAG':'HAGGAI','ZECH':'ZECHARIAH','1MAC':'1 MACCABEES','2MAC':'2 MACCABEES','MATT':'MATTHEW','MARK':'MARK','LUKE':'LUKE','JOHN':'JOHN','ROM':'ROMANS','1COR':'1 CORINTHIANS','2COR':'2 CORINTHIANS','GAL':'GALATIANS','EPH':'EPHESIANS','PHIL':'PHILIPPIANS','COL':'COLOSSIANS','1THESS':'1 THESSALONIANS','2THESS':'2 THESSALONIANS','1TIM':'1 TIMOTHY','2TIM':'2 TIMOTHY','TITUS':'TITUS','PHLM':'PHILEMON','JAS':'JAMES','1PET':'1 PETER','2PET':'2 PETER','1JOHN':'1 JOHN','2JOHN':'2 JOHN','3JOHN':'3 JOHN','REV':'REVELATION','ESTH':'ESTHER'}
    missing=[]; empty=[]; chapter_count=verse_count=0
    for code,title in CANON:
        b=ids.get(code) or titles.get(title.casefold()) or titles.get(aliases.get(code,'').casefold())
        if not b: missing.append(title); continue
        chapters=b.get('chapters',[])
        if not chapters or not any(ch.get('verses') for ch in chapters): empty.append(title); continue
        chapter_count += len(chapters)
        verse_count += sum(len(ch.get('verses',[])) for ch in chapters)
    report={'translationId':d.get('translationId','unknown'),'displayName':d.get('displayName','Unnamed'),'language':d.get('language','und'),'bookRecords':len(books),'catholicCanonBooksExpected':73,'booksMissing':missing,'booksPresentButEmpty':empty,'chaptersPresent':chapter_count,'versesPresent':verse_count,'completeCatholic73Text':len(missing)==0 and len(empty)==0}
    lines = [
        '# Bible dataset coverage audit', '',
        f"- Translation: {report['displayName']}",
        f"- Language: {report['language']}",
        f"- Book records supplied: {len(books)}",
        '- Catholic canon books expected: 73',
        f"- Chapters present: {chapter_count}",
        f"- Verses present: {verse_count}",
        f"- Complete Catholic 73-book text: {'YES' if report['completeCatholic73Text'] else 'NO'}",
        '', '## Missing books'
    ]
    lines.extend(['- ' + x for x in missing] if missing else ['- None'])
    lines.extend(['', '## Present but empty books'])
    lines.extend(['- ' + x for x in empty] if empty else ['- None'])
    lines.extend(['', '> This report checks structure and coverage only. It does not verify textual accuracy, copyright, or licence sufficiency.'])
    md = '\n'.join(lines)

    print(json.dumps(report,ensure_ascii=False,indent=2))
    if args.output: Path(args.output).write_text(md,encoding='utf-8')
if __name__=='__main__': main()
