#!/usr/bin/env python3
"""Import licensed/authorized Ordo reading *references* from a CSV into a date-keyed JSON pack.
Does not import Scripture text or copy Ordo pages. Requires explicit source metadata per row.
"""
import argparse, csv, json, re, sys
from datetime import date
from pathlib import Path
FIELDS = ('celebration','season','colour','rank','cycle','first','psalm','second','gospelAcclamation','gospel','sourceName','sourceUrl','sourceNote')
REF = re.compile(r"^[1-3]?\s*[A-Za-z][A-Za-z .'-]*\s+\d+(?::[0-9a-zA-Z,; .–—-]+)?$")
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('csv_file', type=Path)
    ap.add_argument('pack_file', type=Path)
    ap.add_argument('--output', type=Path)
    ap.add_argument('--mark-verified', action='store_true', help='Use only after a human has checked every row against the approved Ordo.')
    args=ap.parse_args()
    try:
        pack=json.loads(args.pack_file.read_text(encoding='utf-8'))
        rows=list(csv.DictReader(args.csv_file.open(encoding='utf-8-sig', newline='')))
    except Exception as e:
        print(f'ERROR: {e}'); return 2
    if not isinstance(pack,dict) or not isinstance(pack.get('dates'),dict):
        print('ERROR: pack must contain a date-keyed dates object'); return 2
    errors=[]; seen=set(); changed=0
    for i,row in enumerate(rows, start=2):
        key=(row.get('date') or '').strip()
        try: date.fromisoformat(key)
        except Exception: errors.append(f'CSV line {i}: invalid ISO date {key!r}'); continue
        if key in seen: errors.append(f'CSV line {i}: duplicate date {key}'); continue
        seen.add(key)
        if key not in pack['dates']: errors.append(f'CSV line {i}: date {key} is outside the scaffold'); continue
        rec={k:(row.get(k) or '').strip() for k in FIELDS}
        if not rec['sourceName'] or not rec['sourceUrl'] or not rec['sourceNote']:
            errors.append(f'CSV line {i} ({key}): sourceName, sourceUrl, and sourceNote are required'); continue
        for fld in ('first','psalm','second','gospelAcclamation','gospel'):
            if rec[fld] and not REF.match(rec[fld]):
                errors.append(f'CSV line {i} ({key}): suspicious {fld} reference {rec[fld]!r}')
        verified=bool(args.mark_verified)
        pack['dates'][key].update(rec)
        pack['dates'][key]['verified']=verified
        pack['dates'][key]['status']='verified_reference_only' if verified else 'imported_needs_human_verification'
        pack['dates'][key]['notes']='References only; Bible text is resolved separately from the app\'s licensed offline translations.'
        changed+=1
    if errors:
        print(f'ERRORS ({len(errors)}):')
        for e in errors: print('-',e)
        return 1
    out=args.output or args.pack_file
    pack['dataStatus']='references_imported_verified' if args.mark_verified else 'references_imported_unverified'
    pack['importedRows']=changed
    out.write_text(json.dumps(pack,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'Imported {changed} date rows into {out}. verified={args.mark_verified}')
    print('Reminder: --mark-verified records human review status; it does not independently establish liturgical accuracy or redistribution rights.')
    return 0
if __name__=='__main__': sys.exit(main())
