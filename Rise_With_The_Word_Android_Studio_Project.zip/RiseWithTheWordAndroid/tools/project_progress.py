#!/usr/bin/env python3
"""Generate a factual, file-derived project progress snapshot (not a quality score)."""
import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
def load_json(p): return json.loads(p.read_text(encoding='utf-8'))
# Read the bundled Malayalam catalogue JS assignment as JSON.
js=(ASSETS/'malayalam-bible-data.js').read_text(encoding='utf-8')
m=re.search(r'window\.RWTW_MALAYALAM_BIBLE\s*=\s*(\{.*\})\s*;?\s*$',js,re.S)
mal=json.loads(m.group(1)) if m else {}
books=mal.get('books',[])
text_books=0
for b in books:
    chapters=b.get('chapters',[])
    has_text=any(bool(c.get('verses')) for c in chapters)
    if has_text: text_books+=1
readings=load_json(ROOT/'content-feed-template/readings-india-2026-2027.json')
dates=readings.get('dates',{})
fields=('first','psalm','second','gospelAcclamation','gospel')
with_any=sum(any(bool(d.get(k)) for k in fields) for d in dates.values())
with_all=sum(all(bool(d.get(k)) for k in fields) for d in dates.values())
verified=sum(d.get('verified') is True and bool(d.get('sourceName')) for d in dates.values())
saints=load_json(ROOT/'content-feed-template/saints.json')
saint_records=saints.get('items',[]) if isinstance(saints,dict) else saints if isinstance(saints,list) else []
cat=load_json(ASSETS/'catechism-guides.json')
feature_images=[p for p in (ASSETS/'images/feature').glob('*') if p.suffix.lower() in ('.jpg','.jpeg','.png','.webp')]
js_files=list((ASSETS/'js').glob('*.js'))
report={
 'version':'4.6.0',
 'generatedFrom':'current project files',
 'note':'Counts describe bundled data and do not certify theological accuracy, copyright status, translation quality, Android runtime behavior, or release readiness.',
 'malayalamBible':{'catalogueBookRecords':len(books),'booksWithVerseText':text_books,'booksWithoutVerseText':len(books)-text_books,'missingTextBookNames':mal.get('missingTextBooks',[])},
 'liturgicalYear2026_2027':{'dateRecords':len(dates),'datesWithAnyReadingReference':with_any,'datesWithAllFiveReadingFields':with_all,'datesVerifiedWithSource':verified,'dataStatus':readings.get('dataStatus')},
 'saintsFeedTemplate':{'records':len(saint_records)},
 'catechism':{'classGuides':len(cat.get('grades',[])),'language':cat.get('language','not specified')},
 'visualAssets':{'featureImages':len(feature_images),'javascriptFiles':len(js_files)},
 'androidBuild':{'status':'not run in this environment','reason':'Gradle build and physical-device testing have not been performed'}
}
out=ROOT/'content-feed-template/project-progress-v4.6.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
