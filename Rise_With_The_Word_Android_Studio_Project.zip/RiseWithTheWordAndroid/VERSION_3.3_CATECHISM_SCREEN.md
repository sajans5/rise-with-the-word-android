# Version 3.3 — Catechism screen integration

- Added Discover tile for Catechism Classes 1–12.
- Added offline search and class study pages.
- Added locally saved completion status.
- Keeps original study guides distinct from official textbooks.
- Android build/device test remains required.
