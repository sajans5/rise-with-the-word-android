# Version 4.6 — Progress Snapshot and Audit Fix

## What changed
- Fixed the offline content auditor to correctly recognize the 2026–2027 Ordo scaffold's `dates` object (364 keyed dates) instead of miscounting it as an unknown schema.
- Added `tools/project_progress.py`, which generates a file-derived progress snapshot at `content-feed-template/project-progress-v4.6.json`.
- The snapshot distinguishes catalogue entries from actual verse text and blank date scaffolds from populated and verified reading records.

## Important current data status
- Malayalam catalogue: 73 book records, but only 66 books contain bundled verse text; seven deuterocanonical books remain metadata-only.
- 2026–2027 Ordo file: 364 date records; the scaffold is not a completed daily lectionary. Readings must be verified against an approved source before being marked verified.
- The saints feed count describes only the feed template and is not proof that every calendar day has a saint or that every feast has been locally verified.
- Catechism class guides are original supplementary content, not official textbook reproductions.

## Validation
Run from the project root:

```bash
python3 tools/project_progress.py
python3 tools/audit_offline_content.py
python3 tools/audit_bible_coverage.py
```

These checks validate structure and counts only. They do not establish theological correctness, licensing, liturgical accuracy, or successful Android runtime behavior. Gradle build and device testing remain pending.
