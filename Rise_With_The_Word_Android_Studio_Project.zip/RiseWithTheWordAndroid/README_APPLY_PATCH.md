# Apply the v4.8 accessibility/image-pack patch

Extract this patch over a copy of the matching `RiseWithTheWordAndroid/` project, preserving the relative paths. The changed `index.html` loads two new scripts; the new Image Packs tile appears in Discover and Me. Review the image licence notes before redistributing the legacy reference assets. Run the GitHub Actions Android build and test TalkBack, font scaling and Malayalam before release.

The patch is based on the supplied project archive and has not been pushed to GitHub because the connected integration denied write operations (HTTP 403).
