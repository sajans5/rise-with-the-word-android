# Version 4.0 — Ordo Date Scaffold

## What changed
- Expanded the India Roman Rite 2026–2027 Ordo import pack to include one explicit record for every date from 29 November 2026 through 27 November 2027.
- Each record has fields for celebration, season, liturgical colour/rank, cycle, first reading, responsorial psalm, second reading, Gospel acclamation, Gospel, alternatives, Mass options, and source traceability.
- All fields are intentionally blank and every date is marked `awaiting_ordo_review`; this avoids inventing readings or implying the Ordo has been transcribed.
- Added `tools/generate_ordo_scaffold.py` so the date scaffold can be regenerated reproducibly.

## Source and rights
The CCBI article confirms that its Commission for Liturgy prepared the 2026–2027 Ordo and links a PDF. This project stores the public source URL and does not bundle the PDF or reproduce its text. Every date must be checked against the source, and redistribution terms must be reviewed before adding source-derived content.

Official source: https://www.ccbi.in/post/liturgical-calendar-ordo-for-the-year-2026-2027

## Status
- Date scaffold: 364/364 records present.
- Reading records verified: 0/364.
- This is not yet a complete lectionary and must not be presented to users as one.
- Android build/device test: not performed in this release.
