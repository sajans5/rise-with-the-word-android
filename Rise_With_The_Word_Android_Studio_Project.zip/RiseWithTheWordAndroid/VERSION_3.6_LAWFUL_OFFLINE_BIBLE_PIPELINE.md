# Version 3.6 — Lawful offline Bible pipeline

- No POC Bible database or audio has been copied into this project.
- Added a licence-aware SQLite import helper for independently approved Bible datasets.
- Added a rights checklist and normalized data schema.
- Updated data-source status to distinguish catalogue metadata from actual Bible text and flag outstanding source/licence audits.
- The helper validates metadata and verse structure; it is not legal advice and cannot independently verify ownership or licence claims.

Validation: Python syntax and a temporary test database were checked using a synthetic sample verse, not a copyrighted translation. Android Gradle build/device testing was not performed.
