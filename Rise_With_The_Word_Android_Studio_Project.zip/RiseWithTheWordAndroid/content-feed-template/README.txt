CONTENT FEED TEMPLATE
1. On GitHub create a NEW public repository, e.g. "rise-content".
2. Upload all these files to it.
3. Repository Settings > Pages > Deploy from branch "main" (root). Wait a minute.
4. Your feed address is:  https://YOUR-USERNAME.github.io/rise-content/manifest.json
5. In the app: Me > Settings > Content feed > paste the address > Save.
6. To publish an update: edit a file (for example stories.json) AND raise that pack's "version" number in manifest.json.
   The app checks automatically when opened (at most every 12 hours) and keeps the content offline.
Only the pack names in manifest.json are accepted: stories, saints, readings, calendar, quiz, trivia.
Official daily readings: fill readings.json with one entry per date (YYYY-MM-DD). Use a licensed/approved source.

7. `catechism.json` is an optional supplementary study-guide file (Classes 1-12). It is not an accepted automatic-sync pack in the current app version; do not add it to manifest until app support is implemented.
