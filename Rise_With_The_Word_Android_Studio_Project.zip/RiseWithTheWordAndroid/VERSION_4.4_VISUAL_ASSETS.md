# Version 4.4 — Visual Assets and Feature Gallery

## Changes
- Added six original generated devotional feature-art assets under `app/src/main/assets/images/feature/` for Home, Bible, Liturgical Calendar, Saints, Catechism, and Prayer.
- Added a responsive, offline feature-art gallery at the top of Discover, with buttons that navigate to the corresponding app sections.
- Added lazy image loading, descriptive accessible labels, caption overlays, and subtle image zoom/press motion.
- Respects `prefers-reduced-motion` so motion-sensitive users are not forced to see transitions.
- No external image requests are required for these six assets.

## Verification
- These images were cropped from a newly generated six-panel artwork sheet; they are original generated assets, not downloaded publisher images.
- The gallery's destination names are `home`, `bible`, `calendar`, `saints`, `catechism`, and `pray` and should be checked in a device build.
- JavaScript syntax, JSON parsing, and ZIP integrity are checked for this release.
- Android Gradle build and physical-device verification remain pending.

## Known content limitations unchanged
- The complete Malayalam 73-book Catholic Bible text is not yet included.
- The 2026–2027 daily lectionary references are not yet fully populated and verified against the Indian Ordo.
- Saint feast ranks and local transferred observances still require full Ordo audit.
