# Version 4.1 — Bilingual reading references and saint audit

## Implemented
- Liturgical reading reference cards now render English and Malayalam headings.
- Each reading citation is resolved against the locally bundled English Bible when available and the existing Malayalam Bible catalogue/text when present.
- Missing text is labelled explicitly rather than replaced with invented text.
- Date-page saint entries include a button to open the full saint profile.
- Added `node tools/audit_saints_calendar.js` and `content-feed-template/saints-audit-report.json` to flag malformed dates, duplicate name/date pairs, missing biographies, and invalid rank/colour values.
- Fixed the literal `\\n` between script tags in `index.html` if present.

## Important coverage limitations
- The current Malayalam Bible asset explicitly contains text for 66 books; Tobit, Judith, Wisdom, Sirach, Baruch, 1 Maccabees and 2 Maccabees are catalogue-only placeholders. It is not a complete Malayalam Catholic 73-book Bible.
- English reading text appears only when `RWTW_FULL_BIBLE` is bundled by the existing build workflow. This change does not invent or download English Bible text.
- Reading citations still come from the existing built-in/synced readings logic. The India 2026–2027 Ordo template remains unpopulated until references are transcribed and verified against the official source.
- Saint audit checks data quality, not liturgical correctness. Local feast ranks, transfers, and optional memorials must be checked against the CCBI/diocesan Ordo. A date without a saint entry is not automatically an error: many dates are weekdays/ferias, and the Martyrology includes more saints than the Mass calendar.
- No POC Bible database or audio was copied.

## Source basis
The CCBI announced the 2026–2027 Ordo prepared by its Commission for Liturgy: https://www.ccbi.in/post/liturgical-calendar-ordo-for-the-year-2026-2027
The General Roman Calendar API can calculate dates and precedence but is not itself a complete lectionary: https://github.com/Liturgical-Calendar/LiturgicalCalendarAPI

## Validation
Run JavaScript syntax checks, parse all JSON files, run `python tools/audit_saints_calendar.py`, and check ZIP integrity. Android Gradle build/device test remains separate and must be run before release.
