# Version 4.2 — Liturgical Reference Import Pipeline

## What changed
- Added `tools/import_ordo_references.py` to import date-specific Scripture references from a human-reviewed CSV into `content-feed-template/readings-india-2026-2027.json`.
- Added `tools/audit_bilingual_reading_refs.py` to report date coverage, reading-field completeness, and verification metadata.
- Updated the 2026–2027 source metadata to point to the official CCBI Ordo announcement: https://www.ccbi.in/post/liturgical-calendar-ordo-for-the-year-2026-2027
- Updated `app/src/main/assets/data-source-status.json` with honest completion status.

## CSV columns
`date,celebration,season,colour,rank,cycle,first,psalm,second,gospelAcclamation,gospel,sourceName,sourceUrl,sourceNote`

Example import (use references you have checked against the Ordo):
```bash
python tools/import_ordo_references.py verified_readings.csv content-feed-template/readings-india-2026-2027.json --output /tmp/readings-imported.json
python tools/audit_bilingual_reading_refs.py /tmp/readings-imported.json --start 2026-11-29 --end 2027-11-27
```

Only add `--mark-verified` after a person has checked every imported row against the appropriate approved Ordo/lectionary. The flag records the human review status; it is not a legal or theological certification.

## Honest status
The 2026–2027 calendar scaffold has 364 date keys but has **0 verified date rows** and **0 imported reading rows**. This release does not invent readings, copy the Ordo PDF, or bundle POC Bible text/audio. Reading references are separate from the Scripture text displayed by the app. The bilingual reader can resolve references only where the relevant licensed English/Malayalam text is actually present in the app.

## Source note
The CCBI announcement states that the 2026–2027 Ordo was prepared by the CCBI Commission for Liturgy and provides an electronic PDF. This project links to the announcement rather than redistributing the PDF. Verify the applicable rights before redistributing source-derived calendar data beyond what the licence permits.
