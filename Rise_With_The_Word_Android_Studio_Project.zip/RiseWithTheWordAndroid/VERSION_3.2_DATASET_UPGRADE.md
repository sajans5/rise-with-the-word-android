# Version 3.2 — Offline Saints & Catechesis Dataset

- Expanded saints content feed to 50 curated saint summaries.
- Added original supplementary Catholic catechesis study guides for Classes 1–12.
- Added source and licensing notes for official KRLCBC textbooks and Vatican Catechism.
- Kept full official textbook PDFs out of the APK pending redistribution permission.
- This is a dataset groundwork release: catechism browsing UI is not yet integrated; Android APK build has not been run here.
