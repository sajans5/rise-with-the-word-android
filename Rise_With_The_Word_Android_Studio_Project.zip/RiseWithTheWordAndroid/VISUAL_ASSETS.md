# Rise With The Word — Visual Assets

The `app/src/main/assets/images/` folder contains illustrations integrated into the app. `app/src/main/assets/images/icons/` contains the category icons used on the home screen. Android launcher icons are in `app/src/main/res/mipmap-*`. The generated reference sheet is included as `reference-art-sheet.png`.
