# Rise With The Word v1.8 — story reader and navigation update

## Included
- Reorganized bottom navigation to five primary tabs: Home, Gospel, Bible, Stories, More.
- Added a More hub for Prayer Corner, Saved, Saint of the Day, Liturgical Calendar, and Content Sync.
- Replaced the non-opening story cards with a searchable 15-story library.
- Added an in-app story reader with Scripture references, narrative summaries, reflection/lesson, and short prayer.
- Added Save and Share actions for each story.
- Removed unrelated stock illustrations from story cards. Story cards now use story-specific symbols and Scripture references instead of mismatched pictures.
- Existing Bible, saved items, saint/calendar/sync screens and assets are retained.

## Limitations
- These are concise retellings and reflections, not the full biblical text; use the linked Scripture references to read the passages in the Bible.
- This is a starter library, not yet every Bible story from Genesis through Revelation.
- Story illustrations are intentionally omitted rather than showing unrelated images. A later release can add accurate, story-specific artwork.
- The Saint of the Day and calendar data remain starter/planning data, and content sync still requires a real trusted HTTPS feed.
- APK build and device testing have not been run as part of this packaging step.
