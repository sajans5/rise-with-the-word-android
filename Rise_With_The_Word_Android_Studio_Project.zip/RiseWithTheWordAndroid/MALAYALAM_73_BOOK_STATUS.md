# Malayalam Catholic Bible — Version 3.0 status

The app now displays a 73-book Catholic canon index. Existing Malayalam text is available offline for 66 books. The seven added catalogue-only entries are Tobit, Judith, Wisdom, Sirach, Baruch, 1 Maccabees, and 2 Maccabees. They intentionally contain no invented or copied text.

Thiruvachanam documents a Malayalam Bible API with 73 books, but API access requires a key. Before bundling its text offline, obtain written permission/licence terms from the rights holder and verify the translation is the desired Catholic edition. API access alone is not permission to redistribute the full text.

Existing 66-book dataset source: godlytalias/Bible-Database; README states GPL-3.0 and credits Wordproject. Follow GPL terms when distributing the combined app.
