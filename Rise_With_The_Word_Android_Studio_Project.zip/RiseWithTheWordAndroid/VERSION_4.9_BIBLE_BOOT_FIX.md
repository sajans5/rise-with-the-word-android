# Version 4.9 — Bible loading and coverage clarity

## Fixes
- Load the generated `bible-full-data.js` before `js/bible.js`, because `Bible.init()` is called during boot and otherwise the English reader reports the full-text placeholder even though CI generated the 73-book asset.
- In the Malayalam catalogue, display `വാചകം ലഭ്യമല്ല` (text unavailable) for books with no bundled chapters, rather than implying that a zero-chapter count is normal. The entry remains openable to the existing licence/coverage explanation.

## Verified data
- The current CI APK artifact contains Original Douay-Rheims, marked CC0 1.0, with 73 book records and 35,809 verses. Wisdom (19 chapters), Sirach (51), Baruch (6), Tobit (15), Judith (16), 1 Maccabees (16), and 2 Maccabees (15) are present in the generated English data.
- The seven missing Malayalam books remain unavailable. No text was fabricated or copied without verified redistribution rights.
- The readings dataset remains a scaffold; do not label its fallback as official Indian Catholic Mass readings until verified with the approved Ordo.

## Validation
- All 30 shipped JavaScript modules pass `node --check`.
- HTML order check passes: `bible-full-data.js` appears before `js/bible.js`.
- `tools/project_progress.py` executed; it reports the known Malayalam and lectionary coverage gaps.
- A physical Android runtime test and APK rebuild with this exact patched ZIP are still required.
