# Malayalam Bible dataset integration (2.9.0)

## Included data
- File in app assets: `malayalam-bible-data.js`
- Input file: user-supplied `bible.json`
- Shape: 66 books, 1,189 chapters, 31,105 non-empty verses.
- Reader: book list, chapter grid, chapter navigation, local Malayalam substring search.

## Source and license
The supplied data corresponds to the Malayalam JSON format in https://github.com/godlytalias/Bible-Database . The repository README declares GNU General Public License v3 and credits Wordproject for the extracted databases. Preserve the upstream attribution and comply with GPL-3.0 distribution/source obligations before public release. This note is not legal advice.

## Important limitations
- The source has 66 books, not the full 73-book Catholic canon. The existing English Douay–Rheims reader is separate; this Malayalam dataset does not replace it.
- Upstream issue tracking includes reports of Malayalam verse typos and translation mistakes. No verse-by-verse proofreading was performed during integration.
- The database does not include a translation/version label for every verse; do not describe it as an approved Catholic lectionary text.
- All reading and searching in this module work offline after installation.
