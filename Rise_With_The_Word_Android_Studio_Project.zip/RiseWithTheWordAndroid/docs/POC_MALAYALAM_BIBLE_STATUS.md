# POC Malayalam Bible — integration status (3.1.0)

## Current status: not bundled

The app does **not** contain the full POC (Pastoral Orientation Centre) Malayalam Bible text in this release. The POC translation is a distinct edition and should not be silently merged with the 66-book Malayalam text already in the app.

Before adding POC text for offline use, the project needs an authorized copy and explicit terms permitting redistribution inside an APK. An online API or a website that displays the text is not, by itself, permission to package and redistribute it. No missing Bible verses have been invented.

## Integration contract

When a licensed dataset is supplied, add it as a separate translation identifier, e.g. `ml_poc`, rather than overwriting `malayalam-bible-data.js`. Preserve book order, chapter numbers, verse numbers, edition title, source attribution, licence text, and any required copyright notice. Validate that the dataset contains the full 73-book Catholic canon before advertising it as complete.

Suggested normalized JSON shape:

```json
{
  "translationId": "ml_poc",
  "displayName": "POC Malayalam Bible",
  "language": "ml",
  "canon": "catholic-73",
  "source": "rights-holder-supplied dataset",
  "license": "record the exact permission/licence here",
  "books": [
    {"id": "GEN", "title": "ഉല്പത്തി", "chapters": [
      {"number": 1, "verses": [{"number": 1, "text": "..."}]}
    ]}
  ]
}
```

The ellipsis is a schema placeholder, not Bible text. The sample is not a usable translation dataset.
