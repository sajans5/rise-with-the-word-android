# Bible source review — 21 October 2026

This record is a pre-integration checklist. Availability online or an API endpoint does not automatically grant rights to bundle a translation for offline redistribution.

## YouVersion Platform API

- Documentation: https://developers.youversion.com/
- API usage: https://developers.youversion.com/api-usage
- Licences endpoint: https://developers.youversion.com/api/licenses
- The platform requires an app key in the `X-YVP-App-Key` header. Developers must accept the licence terms applicable to the requested Bible versions and must preserve publisher attribution/display requirements. Review the actual licence metadata for every version before enabling it.
- Treat API passage calls as online access unless the specific agreement explicitly permits the intended caching/offline use. Do not embed an API key in a public repository or the APK.

## godlytalias/Bible-Database

- Repository: https://github.com/godlytalias/Bible-Database
- Malayalam JSON: https://github.com/godlytalias/Bible-Database/blob/master/Malayalam/bible.json
- The existing project notes that the checked-in Malayalam dataset supplies 66 books and carries upstream licensing/attribution obligations. Keep the attribution and review applicable GPL-3.0 obligations before distribution. Do not label the 66-book file as a complete 73-book Catholic Bible.

## jjkavalam/holy_bible

- Repository: https://github.com/jjkavalam/holy_bible
- Its README says the Malayalam text was scraped from https://thiruvachanam.in/. The README/source provenance alone does not confirm permission to redistribute the scraped text in an offline app. Do not copy it into the app until the rights holder's licence/permission and 73-book coverage are verified.

## manuni/BibleDatabases

- Repository: https://github.com/manuni/BibleDatabases
- Before using a file from this repository, inspect the repository and individual dataset licence, attribution, translation label, Catholic-canon coverage, and redistribution permission. Do not infer that every contained translation is freely redistributable from the repository name alone.

## Required acceptance criteria for any new offline translation

1. Identify the translation name, rights holder, version/date, and source commit or release.
2. Record an explicit redistribution licence that permits distribution inside an Android app, including offline use.
3. Confirm all 73 Catholic books and every chapter/verse; run coverage and duplicate checks.
4. Store attribution and licence notices in the app and repository.
5. Validate references against the selected Roman Rite India lectionary separately; Bible availability does not verify Mass readings.

This is an engineering diligence record, not legal advice. When licence wording is unclear, obtain permission from the rights holder before including the text.
