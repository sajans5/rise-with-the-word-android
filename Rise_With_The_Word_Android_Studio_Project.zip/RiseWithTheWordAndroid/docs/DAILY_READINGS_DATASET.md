# Daily Mass readings dataset

## Required behavior
For each civil date, show the liturgical celebration and the readings that apply to that celebration in the Roman Rite for India. The screen supports:

- `first`: first reading reference
- `psalm`: responsorial psalm reference (the app can display the Bible passage)
- `second`: second reading reference when prescribed
- `alleluia` or `gospelAcclamation`: Gospel acclamation reference/text
- `gospel`: Gospel reference
- `alternatives`: approved alternatives, each with a `label` and any of `first`, `psalm`, `second`, `alleluia`, `gospelAcclamation`, `gospel`
- `massOptions`: separate formularies such as Vigil, Night, Dawn, Day, or a permitted votive/ritual Mass
- `celebration`, `season`, `colour`, `rank`, `cycle`
- `sourceName`, `sourceUrl`, `verified`

## Trust and verification
`verified: true` is accepted only when `sourceName` is also present. Do not mark a record verified merely because a Gospel citation exists. Verify the correct India/diocese date, weekday and Sunday cycles, solemnity transfers, local observances, optional readings, and each citation against the current approved CCBI/diocesan Ordo and lectionary. Do not assume US, Canadian, or other national calendars match India.

## Copyright
Prefer citations and references. Include full lectionary text only when the project has permission or a suitable license to redistribute it. The app can resolve references against its bundled Bible edition where that edition's license permits.

## Offline coverage
Keep one record per date in the `readings` pack, keyed `YYYY-MM-DD`. Bundle the approved calendar dataset with the APK for fully offline date lookup. Content Sync is an optional update mechanism, not a substitute for bundling the baseline calendar if the app must work without internet.
