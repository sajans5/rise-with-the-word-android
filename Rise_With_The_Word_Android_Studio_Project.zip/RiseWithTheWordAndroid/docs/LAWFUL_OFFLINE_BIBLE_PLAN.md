# Lawful offline Bible data plan — v3.6

## Scope

This release does **not** integrate the POC Bible APK/XAPK/MSI, its encrypted database, or audio. The app package is not a licence to reproduce the text or recordings. The import tooling is for a separate dataset whose licence permits offline copying and redistribution.

## Rights checklist before bundling a translation

- Record the exact translation/edition, language, copyright holder, source URL, licence text/version, and required attribution.
- Confirm that the licence permits reproduction, electronic storage, modification/conversion, and redistribution inside an Android APK or downloadable offline pack.
- Check the rights to the translation separately from the database schema/software and audio recording.
- Verify that all 73 Catholic books are actually present before describing a Malayalam edition as complete. A 73-book catalogue with seven empty entries is not a complete Bible.
- Preserve notices and source files required by the licence. For GPL-licensed source software/data, review the exact obligations and the rights in the underlying translated text separately.
- Do not treat API access, app installation, public web access, or a public Git repository as automatic permission to redistribute its contents.

## SQLite import format

The helper `tools/build_offline_bible_db.py` accepts normalized JSON with this shape:

```json
{
  "translationId": "sample_translation",
  "displayName": "Translation display name",
  "language": "ml",
  "canon": "catholic-73",
  "licenseInfo": {
    "name": "Exact licence name/version",
    "source": "Source URL",
    "rights_holder": "Rights holder or public-domain status explanation",
    "redistribution": "public-domain | cc0 | permissive-license | explicit-permission",
    "attribution": "Required attribution text"
  },
  "books": [
    {"id":"GEN", "title":"Genesis", "chapters":[
      {"number":1,"verses":[{"number":1,"text":"Verse text supplied by an approved source"}]}
    ]}
  ]
}
```

The sample is a schema example, not Bible content. The script checks for licence metadata and data structure; it cannot determine whether a licence claim is truthful or legally sufficient. It refuses inputs without the required metadata.

## Current project status

- POC Bible text/audio: not bundled.
- Existing Malayalam dataset: separate source/licence audit required; this project does not claim that its existing 66-book text is a complete, fully cleared 73-book Catholic edition.
- Catholic canon catalogue: 73 entries; catalogue metadata does not supply missing text.
- Public-domain English option: the project documentation references the CC0 Original Douay-Rheims source, but the raw source dataset is not present in this project archive. This release therefore does not claim a complete English Bible database has been bundled by this import step.
- Liturgical readings: full official lectionary text and India-specific Ordo remain unverified.

## Build an approved database

Run from the project root:

```bash
python tools/build_offline_bible_db.py path/to/approved-translation.json app/src/main/assets/bible-offline.db
```

Only run this with content you have the right to redistribute. Do not supply the POC app's encrypted database or extracted text unless its rights are independently cleared.
