# Liturgical Calendar data integration notes (3.1.0)

The project uses its bundled JavaScript calendar engine for offline date calculations and includes a daily-readings data module. The public Liturgical-Calendar/LiturgicalCalendarAPI project can supply Roman Rite calendar metadata (dates, celebrations, ranks and liturgical seasons) in JSON. Its repository documents national and diocesan calendar support where those calendars have been configured.

Repository: https://github.com/Liturgical-Calendar/LiturgicalCalendarAPI

Important boundaries:
- The upstream project calculates calendar events; it is not a complete database of the Mass Lectionary text.
- Do not label generic Roman-calendar results as the approved India/diocesan Ordo without verification.
- Fetching calendar metadata needs an internet connection. To make dates available offline, a verified JSON snapshot must be bundled and dated, or saved to local storage after a successful sync.
- Readings and the calendar metadata are different datasets; each reading needs a reference, source, verification state, and correct date.
- The app should continue to use bundled data when offline and show a clear warning when an entry is unverified.

No new official India lectionary readings are claimed to have been added in this release.
