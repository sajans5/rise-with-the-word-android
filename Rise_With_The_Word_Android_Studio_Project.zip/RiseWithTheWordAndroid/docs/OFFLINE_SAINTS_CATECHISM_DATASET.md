# Offline saints and catechesis dataset — v3.2

## Included
- `content-feed-template/saints.json`: 50 editorial saint summaries, feast dates, Scripture references, themes, and historical-caution notes.
- `app/src/main/assets/catechism-guides.json`: original supplementary learning guides for Classes 1–12, with summaries, review questions, key terms, activities, and Scripture/Catechism references.
- `content-feed-template/catechism.json`: same study-guide data for optional publishing through a content feed.

## Important scope
These are **study guides, not complete 3,500-word scholarly biographies** and not replacements for the official class textbooks. The saint texts are short editorial summaries and should be reviewed against diocesan sources before publication. The feast date and rank may differ in local calendars.

## Official catechism textbook sources
The Kerala Regional Latin Catholic Bishops Council (KRLCC/KRLCBC) publishes Class 1–12 catechism books in Malayalam and English:
https://krlcc.org/downloads/catechism-books/
Download and bundle the official PDFs only after confirming permission/licence for offline redistribution. The fact that a PDF is publicly downloadable does not by itself grant redistribution rights.

The Catechism of the Catholic Church is available online from the Vatican:
https://www.vatican.va/content/catechism/en.html
The Vatican-hosted Catechism text carries copyright notices; this project therefore includes references and original summaries rather than copying the full text.

For saint and canonisation facts, consult:
https://www.vatican.va/roman_curia/congregations/csaints/index.htm
https://www.causesanti.va/it.html

## Integration status
The data files are bundled in the project. The existing content-feed implementation accepts only its predefined pack names; `catechism` is supplied as a bundled asset and feed template, but it is not yet a full browsable in-app catechism screen. That UI and Kotlin bridge integration must be implemented and tested in a subsequent code pass. The saints feed is compatible with the existing `saints` pack format, but the app must be configured to read/display the added optional fields (`subtitle`, `scripture`, `virtues`, `sourceNote`) to show them all.

## v3.3 UI integration
- Added an offline Catechism Classes 1–12 screen to Discover.
- Added topic search, class detail pages, review questions, activities, Scripture/Catechism references, and locally saved completion flags.
- The app bundles original study-guide data; official textbook PDFs remain excluded pending redistribution permission.
- The screen has not been verified in an Android APK build in this environment.
