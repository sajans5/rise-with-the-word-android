# Bible data source and licence plan — v3.7

## Candidate: Malayalam Indian Revised Version (IRV)

- Source/licence page: https://ebible.org/mal/copyright.htm
- The page identifies the Malayalam IRV (BCS 2025) as copyright © 2017, 2019 Bridge Communication Systems and states that the text is available under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0).
- That licence allows sharing and adaptation subject to attribution, indicating modifications, and ShareAlike terms.
- This is a candidate source for a Malayalam offline edition, but it must **not** be labelled a complete Catholic Bible unless the actual dataset contains the seven deuterocanonical books as well. Verify the source files and coverage before bundling. Do not assume the translation's Protestant canon includes those books.
- Required attribution should preserve the source's wording: “Indian Revised Version Holy Bible in the Malayalam language of India (BCS 2025), copyright © 2017, 2019 Bridge Communication Systems. Contributor: Bridge Connectivity Solutions Pvt. Ltd. Licensed under CC BY-SA 4.0.” Recheck the live source page before release.

## English Catholic text candidate

The project’s existing `tools/build_bible.py` expects the Original Douay–Rheims dataset from https://github.com/janvier-s/original-douay-rheims and marks it CC0. The raw source files are not included in this archive, so no complete English text is claimed as added by this release. Before use, retrieve the upstream licence and manifest, pin a commit, preserve provenance, and audit all 73 books.

## Do not use

- POC Bible APK/XAPK/MSI internal databases or audio without redistribution rights.
- The current bundled Malayalam 66-book dataset as proof of a complete Catholic Bible; the underlying translation/licence chain needs review.
- Any source merely because it is downloadable or has an API.

## Import process

1. Obtain the complete source dataset and its exact licence.
2. Convert to the normalized JSON schema documented in `LAWFUL_OFFLINE_BIBLE_PLAN.md`.
3. Run `python tools/audit_bible_coverage.py normalized.json --output coverage.md`.
4. Review all missing/empty books and attribution manually.
5. Run `python tools/build_offline_bible_db.py normalized.json app/src/main/assets/bible-offline.db`.
6. Keep required licence notices in the app and comply with any ShareAlike obligations for adapted content.

Automated checks are not legal advice and cannot prove that a source is correctly licensed.
