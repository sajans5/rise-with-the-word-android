# Version 4.5 — Offline Content Integrity Audit

## Changes
- Added a read-only audit script for local JSON validity, image assets, catechism guide counts, content-feed record counts, reading-field coverage, source metadata, and local script references.
- Added a generated audit report at `content-feed-template/offline-content-audit.json`.
- Updated Android version metadata to 4.5.0 (versionCode 33).
- Kept the existing six bundled devotional image assets and reduced-motion styling.

## Important limitation
The audit checks file structure and linkage only. It does **not** certify Bible translation rights, theological correctness, exact feast dates, or whether daily Mass readings match the Indian Ordo. Empty reading scaffolds are reported as incomplete rather than filled with guesses.

## Run it
From the project root: `python3 tools/audit_offline_content.py`
