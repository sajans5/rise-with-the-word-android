# Rise With The Word v2.1 — usability fixes

## Included
- Fixed the story-card Read story handler: inline button quoting no longer breaks the click handler.
- Made page navigation reset the WebView scroll position immediately and on the next animation frame.
- Added compact top spacing for the More screen.
- Changed the Daily Gospel reading button to open an in-app reading overlay with an embedded official USCCB reading page and a fallback link.

## Limitations
- The USCCB page may refuse iframe embedding due to its website security headers. If so, the in-app overlay will show the explanatory text and the official-link fallback; it cannot guarantee that the full reading content stays embedded.
- Current official readings require internet. Full offline liturgical readings and a verified five-year Catholic calendar are not included in this patch.
- The package has not been compiled as an APK or tested on the user's device. Run GitHub Actions and verify the story buttons and More navigation.
