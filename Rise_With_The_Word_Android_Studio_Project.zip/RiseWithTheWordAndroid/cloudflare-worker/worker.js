/**
 * Rise With The Word AI Worker — Gemini-only edition.
 * Required production secret: GEMINI_API_KEY.
 * Required binding: AI_RATE_LIMIT (namespace ID 1001, 5 requests / 60 seconds).
 *
 * POST /story JSON:
 * { topic, context, instructions, language: "English"|"Malayalam", wordCount }
 *
 * Keep GEMINI_API_KEY only in Cloudflare Worker secrets. Never embed it in Android.
 */
export default {
  async fetch(request, env) {
    const headers = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
      "Access-Control-Allow-Headers": "Content-Type",
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    };
    const reply = (data, status = 200) =>
      new Response(JSON.stringify(data), { status, headers });

    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });

    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/") {
      return reply({
        service: "Rise With The Word AI",
        ready: true,
        endpoint: "/story",
        providers: ["Google Gemini"],
        rateLimit: "5 requests per 60 seconds"
      });
    }
    if (url.pathname !== "/story" || request.method !== "POST") {
      return reply({ error: "Not found. Use POST /story." }, 404);
    }

    // Enforce request protection before reading the body or contacting Gemini.
    if (!env.AI_RATE_LIMIT || typeof env.AI_RATE_LIMIT.limit !== "function") {
      return reply({ error: "Request protection is not configured." }, 503);
    }
    const clientIp = request.headers.get("CF-Connecting-IP");
    if (!clientIp) return reply({ error: "Unable to identify request source." }, 400);
    try {
      const { success } = await env.AI_RATE_LIMIT.limit({ key: `ip:${clientIp}:story` });
      if (!success) return reply({ error: "Too many requests. Please wait a minute and try again." }, 429);
    } catch (_) {
      return reply({ error: "Request protection is temporarily unavailable." }, 503);
    }

    if (!env.GEMINI_API_KEY) {
      return reply({ error: "GEMINI_API_KEY is missing from Cloudflare Worker secrets." }, 503);
    }

    let body;
    try { body = await request.json(); }
    catch (_) { return reply({ error: "Request body must be valid JSON." }, 400); }

    const topic = String(body.topic || "").trim();
    const context = String(body.context || "").trim();
    const instructions = String(body.instructions || "").trim();
    const language = body.language === "Malayalam" ? "Malayalam" : "English";
    const requestedWords = Number(body.wordCount);
    const wordCount = [700, 1200, 1500, 2200, 3500].includes(requestedWords) ? requestedWords : 1500;

    if (!topic || topic.length > 300) return reply({ error: "Enter a topic of up to 300 characters." }, 400);
    if (context.length > 16000 || instructions.length > 6000) {
      return reply({ error: "The supplied context is too long. Please shorten the request." }, 413);
    }

    const defaultInstructions = `You are the Catholic content research assistant for Rise With The Word.
Use reliable sources: the Bible, Vatican and official Catholic Church sources, dioceses, the Catechism, and reputable historical references.
Never invent quotations, miracles, dates, places, sources, or Church teaching. Clearly label pious tradition and legend. Keep Scripture separate from commentary. Do not reproduce copyrighted modern Bible translations or copyrighted lectionary text. Distinguish established fact from interpretation.
Write engaging, reverent, readable ${language} prose, approximately ${wordCount} words. Use Markdown headings and short paragraphs. End with a short prayer where appropriate.`;
    const prompt = `${instructions || defaultInstructions}

TOPIC: ${topic}
LANGUAGE: ${language}
TARGET LENGTH: approximately ${wordCount} words.

APP-SUPPLIED CONTEXT (preserve the given Scripture references, liturgical facts and summary; do not contradict them):
${context || "(No additional context supplied.)"}

Research factual claims where possible. Return the finished content only, with useful headings.`;

    try {
      const response = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
        {
          method: "POST",
          headers: {
            "x-goog-api-key": env.GEMINI_API_KEY,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            contents: [{ role: "user", parts: [{ text: prompt }] }],
            tools: [{ google_search: {} }],
            generationConfig: {
              maxOutputTokens: Math.min(10000, Math.round(wordCount * 2.2) + 1200),
              temperature: 0.5
            }
          })
        }
      );
      const result = await response.json();
      if (!response.ok) {
        return reply({
          error: "Gemini request failed. Check Gemini API access, quota, and billing.",
          providerStatus: response.status
        }, 502);
      }
      const candidate = result.candidates?.[0];
      const content = (candidate?.content?.parts || []).map(p => p.text || "").join("\n").trim();
      if (!content) {
        return reply({
          error: "Gemini returned no usable text. Check the API response and Worker logs."
        }, 502);
      }
      const sources = [];
      for (const chunk of candidate?.groundingMetadata?.groundingChunks || []) {
        if (chunk.web?.uri) sources.push({ title: chunk.web.title || "Source", url: chunk.web.uri });
      }
      return reply({
        title: topic,
        content,
        wordCount: content.split(/\s+/).length,
        language,
        provider: "gemini",
        sources: uniqueSources(sources)
      });
    } catch (_) {
      return reply({ error: "Gemini request failed. Check the API key and Worker logs." }, 502);
    }
  }
};

function uniqueSources(items) {
  const seen = new Set();
  return items.filter(item => item.url && !seen.has(item.url) && seen.add(item.url));
}
