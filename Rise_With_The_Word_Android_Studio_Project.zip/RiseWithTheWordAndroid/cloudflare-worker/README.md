# Rise With The Word AI Worker (Gemini only)

## Required Cloudflare configuration

1. Keep the production secret `GEMINI_API_KEY` configured in Cloudflare. Never put the key in Android code, a repository, or a message.
2. Keep the `AI_RATE_LIMIT` binding configured (namespace ID `1001`, 5 requests per 60 seconds).
3. Deploy `worker.js` to the `rise-word-ai` Worker.
4. After confirming this Gemini-only Worker is deployed and working, you may delete the old `OPENAI_API_KEY` secret from Cloudflare because this code never calls OpenAI.

## Endpoints

- `GET /` is a health check and does not generate AI content.
- `POST /story` accepts JSON fields: `topic`, `context`, `instructions`, `language` (`English` or `Malayalam`), and `wordCount`.

The Worker calls Google Gemini 2.5 Flash with Google Search grounding. API availability depends on the Gemini API key, model access, quotas, and billing. The rate limiter is a burst-control measure, not a strict global spending cap.
