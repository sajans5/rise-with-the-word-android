# Rise With The Word v2.0 — expanded Bible story library

## Included
- Expanded the selected story collection to 58 entries.
- Each new entry includes a Scripture reference, summary, retelling, lesson, and prayer.
- Preserves the existing story reader and search/save/share functionality from v1.8/v1.9.
- Uses topic symbols for stories without matching illustrations; Daniel's featured image uses a lion symbol.

## Limitations
- These are selected retellings, not every story in the Bible and not the complete biblical text.
- Biblical references and retellings require editorial review before public release.
- Daily saint entries, authoritative Catholic liturgical calendars, a live publishing feed, and cloud sync remain separate unfinished tasks.
- This package has not been compiled as an APK; run GitHub Actions and test on a device.
