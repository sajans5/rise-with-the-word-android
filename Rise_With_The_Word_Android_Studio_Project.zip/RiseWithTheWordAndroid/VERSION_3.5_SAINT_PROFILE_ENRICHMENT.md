# Version 3.5 — Saint Profile Enrichment

- Expanded saint detail pages to show the editorial subtitle, Scripture references for reflection, virtues, and source/verification notes when the profile includes them.
- Scripture references are clearly described as aids for prayer and reflection, not automatically as direct historical biographies.
- Retains offline availability and the existing saint registry, search, feast-day listing, and patron-saint finder.

Content and liturgical caveats:
- Added profiles are editorial summaries, not official liturgical texts. Verify feast rank and local observance against the applicable diocesan Ordo.
- Patronages are traditional devotions, not doctrines.
- This update does not add a complete official lectionary or the missing Malayalam Bible texts.

Validation: run JavaScript syntax checks, JSON parsing, and ZIP integrity checks. Android Gradle/device testing is still required.
